---
name: manager-performance-cli
description: Use for the 管理者绩效 CLI automation project: SmartBI CLI export, report merge, final workbook update, first-time setup, path replacement, and handoff guidance.
---

# Manager Performance CLI

Use this skill when working on the 管理者绩效 CLI automation in `test_week`.

## When to use

- Running the end-to-end manager performance flow
- Exporting BI reports through SmartBI CLI
- Merging exported reports into the processed workbook
- Updating the final performance workbook
- Preparing a handoff package for another machine
- Replacing fixed local paths for a new user's environment

## Core workflow

1. Prefer the one-step entry script:
   `管理者绩效完整流程_CLI版.py`
2. If needed, run stages separately:
   `管理者绩效_BI批量导出合并_CLI版.py`
   `管理者绩效_明细加工_CLI版.py`
   `管理者绩效_最终输出.py`
3. Always verify the target machine has:
   - the `test_week` folder structure
   - `input/`, `output/`, `downloads/`
   - a valid `.env`
   - a working SmartBI CLI path

## Important setup rules

- The scripts currently contain hard-coded absolute paths.
- Before first use on another machine, update:
  - `SMARTBI_CLI_SCRIPT`
  - project directory paths
  - `DOWNLOAD_DIR`
  - `OUTPUT_DIR`
  - `INPUT_FILE`
  - `PROCESSED_FILE`
- Keep the folder layout unchanged if possible.
- The `.env` file must contain:
  - `SMARTBI_USERNAME`
  - `SMARTBI_PASSWORD`
  - `SMARTBI_BASE_URL`

## Handoff checklist

- Package the CLI scripts, `input/`, `需求说明/`, and the two CLI docs.
- Tell the next user to change the SmartBI CLI path first.
- Then change the project path values in the scripts.
- Then add `.env`.
- First test with the one-step script.
- If it fails, split into stage 1, stage 2, and stage 3.

## Behavior notes

- Use the CLI version guidance instead of the older browser-export flow.
- Treat `downloads/cli_exports/` as the export cache for reruns.
- The final output should keep versioned filenames instead of overwriting.
