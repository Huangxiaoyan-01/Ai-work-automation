﻿import asyncio
import calendar
import datetime
import os
import re
import json
import subprocess
import sys
import tempfile
from copy import copy
from pathlib import Path
from getpass import getpass

from openpyxl import Workbook, load_workbook

DOWNLOAD_DIR = Path(r"C:\Users\huangxiaoyan\Documents\trae_projects\test_week\downloads")
OUTPUT_DIR = Path(r"C:\Users\huangxiaoyan\Documents\trae_projects\test_week\output")
DOWNLOAD_DIR.mkdir(parents=True, exist_ok=True)
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
BASE_DIR = Path(__file__).resolve().parent
SMARTBI_CLI_SCRIPT = Path(r"C:\Users\huangxiaoyan\Documents\Codex\smartBICLI_code_only_20260603_104613\smartBICLI\active\python-cli\scripts\smartbi_cli.py")

# 报表配置清单，按需求说明更新为11张报表
REPORTS = [
    # 3.1 AI-海外转介绍业绩达成_月趋势
    {
        "name": "AI-海外转介绍业绩达成_月趋势",
        "url": "https://bi.61info.cn/smartbi/vision/openresource.jsp?resid=I2c928087019e186e186e355a019e3a1373905f08",
        "mode": "no_filters",
        "export_type": "B",
        "merge": {"source_sheet": "思维", "target_sheet": "非手推GMV"},
    },
    # 3.2 港澳商务-链路达成数据
    {
        "name": "港澳商务-链路达成数据",
        "url": "https://bi.61info.cn/smartbi/vision/openresource.jsp?resid=I2c928087019e3c7a3c7aba9e019e4a021d3c753b",
        "mode": "date_only",
        "export_type": "B",
        "merge": {"source_sheet": "Sheet1", "target_sheet": "港澳商务GMV|ROI"},
    },
    # 3.3 AI-海外漏斗达成情况-月趋势-台湾
    {
        "name": "AI-海外漏斗达成情况-月趋势-台湾",
        "url": "https://bi.61info.cn/smartbi/vision/openresource.jsp?resid=I2c928087019e3c7a3c7aba9e019e4a40141e4c03",
        "mode": "no_filters",
        "export_type": "B",
        "merge": {"source_sheet": "思维", "target_sheet": "台湾 滚转|例子到课率"},
    },
    # 3.4 AI-海外漏斗达成情况-月趋势-整体
    {
        "name": "AI-海外漏斗达成情况-月趋势-整体",
        "url": "https://bi.61info.cn/smartbi/vision/openresource.jsp?resid=I2c928087019e186e186e355a019e1f2b6636131d",
        "mode": "no_filters",
        "export_type": "B",
        "merge": {"source_sheet": "思维", "target_sheet": "思维整体GMV"},
    },
    # 3.5 一续-升舱期-分课包续费率
    {
        "name": "一续-升舱期-分课包续费率",
        "url": "https://bi.61info.cn/smartbi/vision/openresource.jsp?resid=I2c928087019b47734773e654019b49cadf583c27",
        "mode": "date_and_refund",
        "export_type": "B",
        "merge": {"source_sheet": "Sheet1", "target_sheet": "一续升舱"},
    },
    # 3.6 统合-升舱期-分课包续费率
    {
        "name": "统合-升舱期-分课包续费率",
        "url": "https://bi.61info.cn/smartbi/vision/openresource.jsp?resid=I2c928087019b8f918f91e2fa019b9cff6d373f6f",
        "mode": "date_and_refund",
        "export_type": "B",
        "merge": {"source_sheet": "Sheet1", "target_sheet": "统合升舱"},
    },
    # 3.7 统合早鸟期-分课包续费率
    {
        "name": "统合早鸟期-分课包续费率",
        "url": "https://bi.61info.cn/smartbi/vision/openresource.jsp?resid=I2c928087019b47734773e654019b4a3a61a6355e",
        "mode": "date_and_refund",
        "export_type": "B",
        "merge": {"source_sheet": "Sheet1", "target_sheet": "统合早鸟"},
    },
    # 3.8 近三月结课续费率-一续
    {
        "name": "近三月结课续费率-一续",
        "url": "https://bi.61info.cn/smartbi/vision/openresource.jsp?resid=I2c9280870193d0dcd0dc8f480193ed733b606832",
        "mode": "date_and_refund",
        "export_type": "B",
        "merge": {"source_sheet": "Sheet1", "target_sheet": "一续结课"},
    },
    # 3.9 近三月结课续费率-统合
    {
        "name": "近三月结课续费率-统合",
        "url": "https://bi.61info.cn/smartbi/vision/openresource.jsp?resid=I2c9280870193d0dcd0dc8f480193ed733b606832",
        "mode": "date_refund_and_pools",
        "pools": ["一续池", "二续池", "三续池", "四续池", "五续池", "六续池"],
        "export_type": "B",
        "merge": {"source_sheet": "Sheet1", "target_sheet": "统合结课"},
    },
    # 3.10 海外思维续费播报
    {
        "name": "海外思维续费播报",
        "url": "https://bi.61info.cn/smartbi/vision/openresource.jsp?resid=I2c9280870193f66cf66ccfe50193f6b40bc66a32",
        "mode": "date_and_refund",
        "export_type": "B",
        "merge": {"source_sheet": "Sheet1", "target_sheet": "续费GMV达成率"},
    },
    # 3.11 转介绍益智业绩播报_LP维度_末次渠道
    {
        "name": "转介绍益智业绩播报_LP维度_末次渠道",
        "url": "https://bi.61info.cn/smartbi/vision/openresource.jsp?resid=I2c928087019033b933b9918901905286967a0d71",
        "mode": "date_single",
        "export_type": "B",
        "merge": {"source_sheet": "Sheet1", "target_sheet": "后端转介绍达成"},
    },
]


def slugify_task_name(value: str) -> str:
    slug = re.sub(r"[^0-9A-Za-z_]+", "_", value).strip("_").lower()
    return slug or "smartbi_report"


def cli_output_dir(task_name: str) -> Path:
    return DOWNLOAD_DIR / "cli_exports" / task_name / "{run_date}" / "{run_id}"


def run_smartbi_cli(args: list[str]) -> dict:
    if not SMARTBI_CLI_SCRIPT.exists():
        raise FileNotFoundError(f"未找到 SmartBI CLI: {SMARTBI_CLI_SCRIPT}")

    cmd = [sys.executable, str(SMARTBI_CLI_SCRIPT), *args, "--json"]
    env = os.environ.copy()
    env["PYTHONIOENCODING"] = "utf-8"
    completed = subprocess.run(
        cmd,
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        env=env,
    )
    stdout = (completed.stdout or "").strip()
    stderr = (completed.stderr or "").strip()
    if completed.returncode != 0:
        raise RuntimeError(
            f"SmartBI CLI 执行失败: {' '.join(cmd)}\n"
            f"stdout:\n{stdout}\n"
            f"stderr:\n{stderr}"
        )
    if not stdout:
        raise RuntimeError(f"SmartBI CLI 未返回 JSON: {' '.join(cmd)}")
    try:
        return json.loads(stdout)
    except Exception as exc:
        raise RuntimeError(
            f"SmartBI CLI JSON 解析失败: {' '.join(cmd)}\nstdout:\n{stdout}\nstderr:\n{stderr}"
        ) from exc


def get_report_id(report: dict) -> str:
    url = report["url"]
    if "resid=" not in url:
        raise RuntimeError(f"报表链接缺少 resid: {url}")
    return url.split("resid=", 1)[1]


def parameter_matches(param: dict, candidate: str) -> bool:
    values = [
        str(param.get("id") or ""),
        str(param.get("name") or ""),
        str(param.get("alias") or ""),
        str(param.get("key") or ""),
    ]
    candidate = candidate.strip()
    if not candidate:
        return False
    lowered = candidate.lower()
    for value in values:
        if not value:
            continue
        if candidate == value:
            return True
        if lowered in value.lower() or value.lower() in lowered:
            return True
    return False


def resolve_cli_param_key(parameters: list[dict], candidates: list[str], fallback: str) -> str:
    for candidate in candidates:
        for param in parameters:
            if parameter_matches(param, candidate):
                return str(param.get("alias") or param.get("name") or param.get("id") or candidate)
    return fallback


def param_value_candidates(param: dict) -> list[str]:
    values = []
    for key in ("value", "displayValue", "alias", "name", "id"):
        value = param.get(key)
        if value is None:
            continue
        text = str(value).strip()
        if text and text not in values:
            values.append(text)
    return values


def find_param_by_candidates(parameters: list[dict], candidates: list[str]) -> dict | None:
    for candidate in candidates:
        for param in parameters:
            if parameter_matches(param, candidate):
                return param
    return None


POOL_VALUE_MAP = {
    "一续池": "1",
    "二续池": "2",
    "三续池": "3",
    "四续池": "4",
    "五续池": "5",
    "六续池": "6",
}


def normalize_pool_values(pool_labels: list[str]) -> tuple[str, str]:
    values: list[str] = []
    labels: list[str] = []
    for label in pool_labels:
        clean = str(label).strip()
        if not clean:
            continue
        labels.append(clean)
        values.append(POOL_VALUE_MAP.get(clean, clean))
    return ",".join(values), ",".join(labels)


def build_cli_overrides(report: dict, parameters: list[dict], start_date: str, end_date: str) -> list[dict]:
    mode = report["mode"]
    if mode == "no_filters":
        return []

    overrides: list[dict] = []
    report_name = report["name"]
    if report_name == "港澳商务-链路达成数据":
        start_key = resolve_cli_param_key(parameters, ["开始日期", "开始日"], "开始日期")
        snapshot_key = resolve_cli_param_key(parameters, ["快照日期", "结束日期", "结束日"], "快照日期")
        overrides.extend(
            [
                {"key": start_key, "value": start_date, "displayValue": start_date},
                {"key": snapshot_key, "value": end_date, "displayValue": end_date},
            ]
        )
    elif report_name == "转介绍益智业绩播报_LP维度_末次渠道":
        date_key = resolve_cli_param_key(parameters, ["q_date_-15min"], "q_date_-15min")
        overrides.append({"key": date_key, "value": end_date, "displayValue": end_date})
    elif report_name == "近三月结课续费率-统合":
        date_key = resolve_cli_param_key(parameters, ["日期", "开始日期", "开始月份"], "日期")
        refund_key = resolve_cli_param_key(parameters, ["退费结束时间", "退款结束时间", "结束日期", "结束月份"], "退费结束时间")
        pool_param = find_param_by_candidates(parameters, ["思维续费池", "续费池", "pools"])
        pool_values, pool_labels = normalize_pool_values(report.get("pools") or [])
        if pool_param is None:
            pool_key = "思维续费池"
        else:
            pool_key = str(pool_param.get("alias") or pool_param.get("name") or pool_param.get("id"))
        overrides.extend(
            [
                {"key": date_key, "value": end_date, "displayValue": end_date},
                {"key": refund_key, "value": start_date, "displayValue": start_date},
                {"key": pool_key, "value": pool_values, "displayValue": pool_labels},
            ]
        )
    elif mode == "date_only":
        end_key = resolve_cli_param_key(parameters, ["结束日期", "结束月份", "end_date", "end_month"], "结束日期")
        start_key = resolve_cli_param_key(parameters, ["开始日期", "开始月份", "start_date", "start_month"], "开始日期")
        overrides.extend(
            [
                {"key": end_key, "value": end_date, "displayValue": end_date},
                {"key": start_key, "value": start_date, "displayValue": start_date},
            ]
        )
    elif mode == "date_and_refund":
        date_key = resolve_cli_param_key(parameters, ["日期", "开始日期", "开始月份"], "日期")
        refund_key = resolve_cli_param_key(parameters, ["退费结束时间", "退款结束时间", "结束日期", "结束月份"], "退费结束时间")
        overrides.extend(
            [
                {"key": date_key, "value": end_date, "displayValue": end_date},
                {"key": refund_key, "value": start_date, "displayValue": start_date},
            ]
        )
    elif mode == "date_single":
        date_key = resolve_cli_param_key(parameters, ["日期", "结束日期", "结束月份"], "日期")
        overrides.append({"key": date_key, "value": end_date, "displayValue": end_date})
    else:
        raise RuntimeError(f"未知报表模式: {mode}")
    return overrides


def build_cli_task(report: dict, start_date: str, end_date: str) -> tuple[str, dict, Path]:
    task_name = slugify_task_name(report["name"])
    report_id = get_report_id(report)
    inspect_result = run_smartbi_cli(
        [
            "inspect-report",
            "--username",
            os.environ["SMARTBI_USERNAME"],
            "--password",
            os.environ["SMARTBI_PASSWORD"],
            "--report-id",
            report_id,
            "--report-path",
            report["url"].split("openresource.jsp?", 1)[-1],
        ]
    )
    parameters = inspect_result.get("parameters") or []
    if not isinstance(parameters, list):
        parameters = []

    overrides = build_cli_overrides(report, parameters, start_date, end_date)
    out_dir = cli_output_dir(task_name)
    task = {
        "version": 1,
        "base_url": "https://bi.61info.cn/smartbi/vision",
        "tasks": {
            task_name: {
                "enabled": True,
                "description": f"{report['name']} CLI 导出任务",
                "report": {
                    "id": report_id,
                    "path": "",
                    "type": "SPREADSHEET_REPORT",
                },
                "filters": {
                    "overrides": overrides,
                },
                "output": {
                    "type": "file",
                    "dir": str(out_dir),
                },
            }
        },
    }
    return task_name, task, out_dir


def run_cli_export(report: dict, perf_month_raw: str, start_date: str, end_date: str) -> Path:
    task_name, task, _ = build_cli_task(report, start_date, end_date)
    with tempfile.TemporaryDirectory(prefix=f"smartbi_{task_name}_", dir=str(DOWNLOAD_DIR)) as tmp_dir:
        config_path = Path(tmp_dir) / "smartbi_tasks.json"
        config_path.write_text(json.dumps(task, ensure_ascii=False, indent=2), encoding="utf-8")
        print(f"\n[CLI] 预演导出: {report['name']}（{perf_month_raw}）")
        dry_run = run_smartbi_cli(
            [
                "run",
                "--config",
                str(config_path),
                "--task",
                task_name,
                "--dry-run",
                "--username",
                os.environ["SMARTBI_USERNAME"],
                "--password",
                os.environ["SMARTBI_PASSWORD"],
            ]
        )
        print(f"[CLI] dry-run 完成: {dry_run.get('status', 'unknown')}")
        result = run_smartbi_cli(
            [
                "run",
                "--config",
                str(config_path),
                "--task",
                task_name,
                "--username",
                os.environ["SMARTBI_USERNAME"],
                "--password",
                os.environ["SMARTBI_PASSWORD"],
            ]
        )
        output = result.get("output")
        if not isinstance(output, str) or not output:
            raise RuntimeError(f"CLI 未返回导出文件路径: {result}")
        path = Path(output)
        if not path.exists():
            raise RuntimeError(f"CLI 返回的导出文件不存在: {path}")
        if report["name"] == "近三月结课续费率-统合":
            renamed = path.with_name(f"{path.stem}-统合{path.suffix}")
            if renamed != path:
                path.rename(renamed)
                path = renamed
        print(f"[SUCCESS] CLI 导出完成: {path.name}")
        return path


def load_env() -> dict:
    env_path = BASE_DIR / ".env"
    if env_path.exists():
        for line in env_path.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                k, v = line.split("=", 1)
                os.environ[k.strip()] = v.strip().strip('"').strip("'")

    username = os.getenv("SMARTBI_USERNAME")
    password = os.getenv("SMARTBI_PASSWORD")
    base_url = os.getenv("SMARTBI_BASE_URL", "https://bi.61info.cn/smartbi/vision/index.jsp")

    if not username:
        username = input("请输入 SmartBI 用户名: ").strip()
    if not password:
        password = getpass("请输入 SmartBI 密码: ").strip()

    if not username or not password:
        raise ValueError("用户名或密码为空")

    return {
        "username": username,
        "password": password,
        "base_url": base_url,
    }


def parse_perf_month() -> tuple[str, str, str, str]:
    raw = input("请输入绩效月份(YYYY-MM): ").strip()
    if not re.fullmatch(r"\d{4}-\d{2}", raw):
        raise ValueError("绩效月份格式错误，应为 YYYY-MM")
    y, m = raw.split("-")
    year, month = int(y), int(m)
    if month < 1 or month > 12:
        raise ValueError("月份范围错误")
    start_date = f"{year:04d}-{month:02d}-01"
    last_day = calendar.monthrange(year, month)[1]
    end_date = f"{year:04d}-{month:02d}-{last_day:02d}"
    month_cn = f"{year:04d}年{month:02d}月"
    return raw, month_cn, start_date, end_date


def choose_reports() -> list[dict]:
    print("\n请选择执行模式：")
    print("  1. 全部报表（默认）")
    print("  2. 单报表调试")
    mode = input("请输入序号（回车默认1）: ").strip()

    if mode != "2":
        return REPORTS.copy()

    print("\n可调试报表：")
    for i, r in enumerate(REPORTS, 1):
        print(f"  {i}. {r['name']}")
    idx_raw = input("请输入报表序号: ").strip()
    if not idx_raw.isdigit():
        raise ValueError("报表序号格式错误")
    idx = int(idx_raw) - 1
    if idx < 0 or idx >= len(REPORTS):
        raise ValueError("报表序号超出范围")
    return [REPORTS[idx]]


def make_export_target(report_name: str) -> Path:
    date_tag = datetime.date.today().strftime("%y%m%d")
    base = DOWNLOAD_DIR / f"{report_name}_{date_tag}.xlsx"
    if not base.exists():
        return base
    i = 1
    while True:
        p = DOWNLOAD_DIR / f"{report_name}_{date_tag}v{i}.xlsx"
        if not p.exists():
            return p
        i += 1


def sanitize_sheet_title(title: str) -> str:
    safe = title.replace("|", "｜")
    safe = re.sub(r"[:\\/?*\[\]]", "_", safe)
    return safe[:31]


def all_frames(page):
    frames = [page.main_frame]
    for f in page.frames:
        if f not in frames:
            frames.append(f)
    return frames


async def login(page, cfg: dict) -> None:
    await page.goto(cfg["base_url"], wait_until="networkidle")
    await page.wait_for_selector('input[bofid="username"]', timeout=20000)
    await page.fill('input[bofid="username"]', cfg["username"])
    await page.fill('input[bofid="password"]', cfg["password"])
    await page.click('input[bofid="login"]')
    await page.wait_for_load_state("networkidle", timeout=40000)


async def open_report(page, url: str, name: str) -> None:
    print(f"\n[INFO] 打开报表: {name}")
    await page.goto(url, wait_until="domcontentloaded", timeout=90000)
    try:
        await page.wait_for_load_state("load", timeout=30000)
    except Exception:
        pass
    await asyncio.sleep(3)
    await wait_month_inputs_ready(page)


async def set_input_by_row_label(page, label: str, value: str) -> bool:
    for fr in all_frames(page):
        label_cell = fr.locator(f'td:has-text("{label}")').first
        if await label_cell.count() == 0:
            continue
        tr = label_cell.locator("xpath=ancestor::tr[1]")
        inputs = tr.locator("input.combobox-edit, input.multicalendar-nobackground-edit, input[type='text']")
        count = await inputs.count()
        for i in range(count):
            inp = inputs.nth(i)
            if not await inp.is_visible():
                continue
            try:
                await inp.evaluate("el => el.removeAttribute('readonly')")
            except Exception:
                pass
            await inp.click(timeout=4000, force=True)
            try:
                await inp.fill("")
            except Exception:
                await inp.press("Control+a")
                await inp.press("Backspace")
            await inp.fill(value)
            await inp.dispatch_event("change")
            await inp.dispatch_event("blur")
            await inp.press("Enter")
            await asyncio.sleep(0.2)
            return True
    return False


async def get_input_value_by_row_label(page, label: str) -> str:
    for fr in all_frames(page):
        label_cell = fr.locator(f'td:has-text("{label}")').first
        if await label_cell.count() == 0:
            continue
        tr = label_cell.locator("xpath=ancestor::tr[1]")
        inputs = tr.locator("input.combobox-edit, input.multicalendar-nobackground-edit, input[type='text']")
        count = await inputs.count()
        for i in range(count):
            inp = inputs.nth(i)
            if not await inp.is_visible():
                continue
            try:
                return (await inp.input_value()).strip()
            except Exception:
                continue
    return ""


async def get_month_inputs_values(page) -> tuple[str, str]:
    vals = []
    for fr in all_frames(page):
        month_inputs = fr.locator("input.multicalendar-nobackground-edit")
        cnt = await month_inputs.count()
        for i in range(cnt):
            inp = month_inputs.nth(i)
            try:
                vals.append((await inp.input_value()).strip())
            except Exception:
                vals.append("")
    if len(vals) >= 2:
        return vals[0], vals[1]
    return "", ""


async def wait_month_values(page, timeout_ms: int = 8000) -> tuple[str, str]:
    start = asyncio.get_event_loop().time()
    last_s, last_e = "", ""
    while True:
        s, e = await get_month_inputs_values(page)
        last_s, last_e = s, e
        if s and e:
            return s, e
        if (asyncio.get_event_loop().time() - start) * 1000 > timeout_ms:
            return last_s, last_e
        await asyncio.sleep(0.3)


async def wait_month_inputs_ready(page, timeout_ms: int = 30000) -> None:
    start = asyncio.get_event_loop().time()
    while True:
        s, e = await get_month_inputs_values(page)
        if s and e:
            print(f"[DEBUG] 月份控件就绪: 开始='{s}' 结束='{e}'")
            return
        if (asyncio.get_event_loop().time() - start) * 1000 > timeout_ms:
            print(f"[WARNING] 等待月份控件超时，当前值: 开始='{s}' 结束='{e}'")
            return
        await asyncio.sleep(0.5)


async def wait_until_month_in_table(page, month_token: str, timeout_ms: int = 45000) -> bool:
    start = asyncio.get_event_loop().time()
    while True:
        try:
            for fr in all_frames(page):
                try:
                    txt = await fr.locator("body").inner_text(timeout=2000)
                except Exception:
                    continue
                if month_token in txt:
                    print(f"[DEBUG] 检测到目标月份已出现在报表中: {month_token}")
                    return True
        except Exception:
            pass
        if (asyncio.get_event_loop().time() - start) * 1000 > timeout_ms:
            print(f"[WARNING] 等待报表出现目标月份超时: {month_token}")
            return False
        await asyncio.sleep(1.0)


async def ensure_month_ready_with_retry(page, month_token: str) -> None:
    ok = await wait_until_month_in_table(page, month_token, timeout_ms=45000)
    if ok:
        return
    print(f"[INFO] 第一次未检测到目标月份 {month_token}，执行二次刷新")
    await refresh_report(page)
    ok2 = await wait_until_month_in_table(page, month_token, timeout_ms=45000)
    if not ok2:
        raise RuntimeError(f"刷新两次后仍未检测到目标月份: {month_token}")


async def wait_refresh_visual_cycle(page, timeout_ms: int = 45000) -> None:
    start = asyncio.get_event_loop().time()
    seen_loading = False
    while True:
        txt_all = ""
        for fr in all_frames(page):
            try:
                txt_all += " " + (await fr.locator("body").inner_text(timeout=1200))
            except Exception:
                continue
        if ("点击图标取消查询" in txt_all) or ("取消查询" in txt_all):
            seen_loading = True
        if seen_loading and ("点击图标取消查询" not in txt_all) and ("取消查询" not in txt_all):
            return
        if (asyncio.get_event_loop().time() - start) * 1000 > timeout_ms:
            return
        await asyncio.sleep(0.8)


async def force_set_month_inputs(page, start_value: str, end_value: str) -> bool:
    for fr in all_frames(page):
        try:
            ok = await fr.evaluate(
                """([startValue, endValue]) => {
                    const nodes = Array.from(document.querySelectorAll('input.multicalendar-nobackground-edit'));
                    if (nodes.length < 2) return false;
                    const start = nodes[0];
                    const end = nodes[1];
                    for (const el of [start, end]) {
                        el.removeAttribute('readonly');
                        el.readOnly = false;
                    }
                    start.value = startValue;
                    end.value = endValue;
                    for (const el of [start, end]) {
                        el.dispatchEvent(new Event('input', { bubbles: true }));
                        el.dispatchEvent(new Event('change', { bubbles: true }));
                        el.dispatchEvent(new Event('blur', { bubbles: true }));
                    }
                    return true;
                }""",
                [start_value, end_value],
            )
            if ok:
                return True
        except Exception:
            pass

    all_month_inputs = []
    for fr in all_frames(page):
        month_inputs = fr.locator("input.multicalendar-nobackground-edit")
        cnt = await month_inputs.count()
        for i in range(cnt):
            all_month_inputs.append(month_inputs.nth(i))
    if len(all_month_inputs) < 2:
        return False
    edited = 0
    for inp, val in [(all_month_inputs[0], start_value), (all_month_inputs[1], end_value)]:
        try:
            await inp.evaluate("el => { el.removeAttribute('readonly'); el.readOnly = false; }")
            await inp.click(timeout=4000, force=True)
            await inp.fill("")
            await inp.type(val, delay=20)
            await inp.dispatch_event("change")
            await inp.dispatch_event("blur")
            edited += 1
        except Exception:
            pass
    if edited >= 2:
        return True
    return False


async def set_and_verify(page, label: str, value: str, required: bool = True) -> None:
    ok = await set_input_by_row_label(page, label, value)
    actual = await get_input_value_by_row_label(page, label)
    print(f"[DEBUG] 参数[{label}] 目标='{value}' 设置结果={ok} 回读='{actual}'")
    if required and (not ok or value not in actual):
        raise RuntimeError(f"参数未生效: {label} 期望包含 '{value}'，实际 '{actual}'")


async def set_date_range_like_roi(page, start_date: str, end_date: str) -> None:
    """根据索引定位日期输入框：输入框0=结束日期，输入框1=开始日期。"""
    print(f"[INFO] 设置日期筛选: {start_date} 至 {end_date}")
    
    inputs = page.locator('input.combobox-edit')
    input_count = await inputs.count()
    print(f"[DEBUG] 找到 {input_count} 个 combobox-edit 输入框")
    
    if input_count >= 2:
        end_input = inputs.nth(0)
        start_input = inputs.nth(1)
        
        await end_input.evaluate('el => { el.removeAttribute("readonly"); el.readOnly = false; }')
        await end_input.fill(end_date)
        await end_input.dispatch_event("change")
        await end_input.dispatch_event("blur")
        print(f"[DEBUG] 已设置结束日期(输入框0): {end_date}")
        
        await start_input.evaluate('el => { el.removeAttribute("readonly"); el.readOnly = false; }')
        await start_input.fill(start_date)
        await start_input.dispatch_event("change")
        await start_input.dispatch_event("blur")
        print(f"[DEBUG] 已设置开始日期(输入框1): {start_date}")
    else:
        for fr in all_frames(page):
            start_input = fr.locator('td:has-text("开始日期")').locator('xpath=ancestor::tr[1]//input.combobox-edit').first
            if await start_input.count() > 0:
                await start_input.evaluate('el => el.removeAttribute("readonly")')
                await start_input.fill(start_date)
                await start_input.dispatch_event("change")
                await start_input.dispatch_event("blur")
                print(f"[DEBUG] 已设置开始日期: {start_date}")
            
            end_input = fr.locator('td:has-text("结束日期")').locator('xpath=ancestor::tr[1]//input.combobox-edit').first
            if await end_input.count() > 0:
                await end_input.evaluate('el => el.removeAttribute("readonly")')
                await end_input.fill(end_date)
                await end_input.dispatch_event("change")
                await end_input.dispatch_event("blur")
                print(f"[DEBUG] 已设置结束日期: {end_date}")


async def set_subject_like_roi(page, subject: str) -> None:
    """主投学科使用标签同行 combobox 输入。参考外渠报表批量导出脚本的方法。"""
    print(f"[INFO] 设置主投学科: {subject}")
    
    inputs = page.locator('input.combobox-edit')
    input_count = await inputs.count()
    print(f"[DEBUG] 找到 {input_count} 个 combobox-edit 输入框")
    
    target_input = None
    
    for i in range(input_count):
        input_el = inputs.nth(i)
        try:
            value = await input_el.input_value()
            print(f"[DEBUG] 输入框 {i} 值: '{value}'")
            
            if value == '全部':
                target_input = input_el
                print(f"[DEBUG] 找到目标输入框，索引={i}")
                break
        except Exception as e:
            print(f"[DEBUG] 获取输入框 {i} 值失败: {e}")
            continue
    
    if not target_input:
        raise RuntimeError("未找到主投学科输入框（值为'全部'的combobox-edit）")
    
    await target_input.click(timeout=5000, force=True)
    
    try:
        await target_input.fill("")
    except Exception:
        await target_input.press("Control+a")
        await target_input.press("Backspace")
    
    await target_input.type(subject, delay=50)
    await target_input.press("Enter")
    
    await page.click('body', position={'x': 0, 'y': 0})
    
    await asyncio.sleep(1.5)
    
    current_value = (await target_input.input_value() or "").strip()
    print(f"[DEBUG] 主投学科输入框当前值: '{current_value}'")
    
    if subject not in current_value:
        print(f"[WARN] 主投学科未完整回显（可能是展示格式差异）: 当前值='{current_value}'")


async def set_region_like_overseas(page, regions: list[str]) -> None:
    """参考海外组织成本分摊脚本：精确定位“区域等级”输入框并直接输入文本。"""
    print(f"[INFO] 设置区域筛选: {regions}")
    
    print("[DEBUG] 等待页面完全加载...")
    # 等待网络空闲
    await page.wait_for_load_state("networkidle", timeout=30000)
    print("[DEBUG] 网络空闲，等待报表数据加载...")
    # 额外等待报表数据加载完成
    await asyncio.sleep(8)
    
    print("[DEBUG] 等待筛选控件加载...")
    try:
        await page.wait_for_selector('input.combobox-edit', timeout=15000)
    except Exception:
        print("[WARN] 等待输入框超时，继续尝试定位")
        await asyncio.sleep(3)

    target_input = None

    # 方法1（优先）：直接定位到区域等级右边的输入框
    # 使用更精确的XPath，直接定位到区域等级右边相邻td中的输入框
    region_input_xpath = page.locator(
        'xpath=//td[text()="区域等级"]/following-sibling::td[1]//input[contains(@class,"combobox-edit")]'
    )
    xpath_count = await region_input_xpath.count()
    print(f"[DEBUG] 区域等级 XPath(text) 命中输入框数量: {xpath_count}")
    
    if xpath_count == 0:
        region_input_xpath = page.locator(
            'xpath=//td[contains(text(),"区域等级")]/following-sibling::td[1]//input[contains(@class,"combobox-edit")]'
        )
        xpath_count = await region_input_xpath.count()
        print(f"[DEBUG] 区域等级 XPath(contains) 命中输入框数量: {xpath_count}")
    
    for i in range(xpath_count):
        cand = region_input_xpath.nth(i)
        if await cand.is_visible():
            target_input = cand
            print(f"[DEBUG] 命中区域等级输入框(xpath) index={i}")
            break

    # 方法2：按“区域等级”所在行定位（兼容DOM结构变化）
    if not target_input or await target_input.count() == 0:
        region_label = page.locator('td:has-text("区域等级")').first
        if await region_label.count() > 0:
            tr = region_label.locator('xpath=ancestor::tr[1]')
            nearby = tr.locator('input.combobox-edit')
            near_count = await nearby.count()
            print(f"[DEBUG] 区域等级同行找到 {near_count} 个输入框")
            for i in range(near_count):
                cand = nearby.nth(i)
                if await cand.is_visible():
                    target_input = cand
                    print(f"[DEBUG] 命中区域等级输入框(tr) index={i}")
                    break

    # 方法3：遍历所有frames查找
    if not target_input or await target_input.count() == 0:
        for fr in all_frames(page):
            region_input_xpath_fr = fr.locator(
                'xpath=//td[contains(normalize-space(.),"区域等级")]/following-sibling::td//input[contains(@class,"combobox-edit")]'
            )
            xpath_count_fr = await region_input_xpath_fr.count()
            print(f"[DEBUG] 在frame '{fr.name}' 区域等级 XPath 命中输入框数量: {xpath_count_fr}")
            for i in range(xpath_count_fr):
                cand = region_input_xpath_fr.nth(i)
                if await cand.is_visible():
                    target_input = cand
                    print(f"[DEBUG] 在frame '{fr.name}' 命中区域等级输入框 index={i}")
                    break
            if target_input:
                break

    # 方法4：遍历所有frames查找
    if not target_input or await target_input.count() == 0:
        for fr in all_frames(page):
            region_input_xpath_fr = fr.locator(
                'xpath=//td[contains(normalize-space(.),"区域等级")]/following-sibling::td//input[contains(@class,"combobox-edit")]'
            )
            xpath_count_fr = await region_input_xpath_fr.count()
            print(f"[DEBUG] 在frame '{fr.name}' 区域等级 XPath 命中输入框数量: {xpath_count_fr}")
            for i in range(xpath_count_fr):
                cand = region_input_xpath_fr.nth(i)
                if await cand.is_visible():
                    target_input = cand
                    print(f"[DEBUG] 在frame '{fr.name}' 命中区域等级输入框 index={i}")
                    break
            if target_input:
                break

    # 方法4（参考外渠报表批量导出）：遍历所有frames，查找值为"全部"的输入框
    if not target_input or await target_input.count() == 0:
        print("[DEBUG] 尝试方法4：查找值为'全部'的输入框")
        for fr in all_frames(page):
            inputs = fr.locator('input.combobox-edit')
            count = await inputs.count()
            print(f"[DEBUG] 在frame '{fr.name}' 查找值为'全部'的输入框，共 {count} 个")
            for i in range(count):
                cand = inputs.nth(i)
                try:
                    val = await cand.input_value()
                    if val == "全部" and await cand.is_visible():
                        target_input = cand
                        print(f"[DEBUG] 在frame '{fr.name}' 找到值为'全部'的输入框 index={i}")
                        break
                except Exception:
                    pass
            if target_input:
                break

    # 方法5：兜底，仅取第一个可见输入框
    if not target_input or await target_input.count() == 0:
        visible_inputs = page.locator('input.combobox-edit:visible')
        vis_count = await visible_inputs.count()
        print(f"[WARN] 区域等级精确定位失败，兜底可见输入框数量: {vis_count}")
        if vis_count > 0:
            target_input = visible_inputs.first
            print("[WARN] 使用兜底输入框 index=0")

    if not target_input or await target_input.count() == 0:
        raise RuntimeError("未找到区域等级输入框")

    print("[DEBUG] 定位到区域等级输入框")
    regions_text = ",".join(regions)
    await target_input.click(timeout=5000, force=True)
    try:
        await target_input.fill("")
    except Exception:
        await target_input.press("Control+a")
        await target_input.press("Backspace")

    await target_input.type(regions_text, delay=30)
    print(f"[DEBUG] 已输入区域文本: {regions_text}")

    await target_input.press("Enter")
    await page.click("body", position={"x": 50, "y": 50}, timeout=3000)
    await asyncio.sleep(1.5)

    current_value = (await target_input.input_value() or "").strip()
    print(f"[DEBUG] 输入框当前值: {current_value}")
    missing = [r for r in regions if r not in current_value]
    if missing:
        print(f"[WARN] 输入框未完整回显这些区域（可能是展示格式差异）: {missing}")

    # 防止“区域细分”串值：强制重置为“全部”
    try:
        detail_label = page.locator('td:has-text("区域细分")').first
        if await detail_label.count() > 0:
            detail_tr = detail_label.locator('xpath=ancestor::tr[1]')
            detail_inputs = detail_tr.locator('input.combobox-edit')
            detail_input = None
            detail_count = await detail_inputs.count()
            for i in range(detail_count):
                cand = detail_inputs.nth(i)
                if await cand.is_visible():
                    detail_input = cand
                    break
            if detail_input and await detail_input.count() > 0:
                await detail_input.click(timeout=3000, force=True)
                try:
                    await detail_input.fill("")
                except Exception:
                    await detail_input.press("Control+a")
                    await detail_input.press("Backspace")
                await detail_input.type("全部", delay=20)
                await detail_input.press("Enter")
                await page.click("body", position={"x": 60, "y": 60}, timeout=2000)
                await asyncio.sleep(0.5)
                print("[DEBUG] 已将区域细分重置为: 全部")
    except Exception as e:
        print(f"[WARN] 区域细分重置失败(继续): {e}")

    print("[DEBUG] 区域筛选完成")


async def set_single_date(page, date_value: str) -> None:
    """设置单个日期参数（用于报表11）：日期=绩效月份的最后一天。"""
    print(f"[INFO] 设置单个日期参数: {date_value}")
    
    date_input = None
    
    # 优先按索引定位第一个输入框
    inputs = page.locator('input.combobox-edit')
    input_count = await inputs.count()
    print(f"[DEBUG] 找到 {input_count} 个 combobox-edit 输入框")
    
    if input_count >= 1:
        date_input = inputs.nth(0)
        if await date_input.is_visible():
            print(f"[DEBUG] 按索引定位到日期输入框(第1个，索引0)")
        else:
            date_input = None
    
    # 兜底：按标签定位
    if not date_input:
        for fr in all_frames(page):
            date_input = fr.locator('td:has-text("日期")').locator('xpath=ancestor::tr[1]//input.combobox-edit').first
            if await date_input.count() > 0 and await date_input.is_visible():
                print(f"[DEBUG] 按标签定位到日期输入框")
                break
    
    if not date_input:
        raise RuntimeError("未找到日期输入框")
    
    # 移除readonly属性
    await date_input.evaluate('el => { el.removeAttribute("readonly"); el.readOnly = false; }')
    
    await date_input.click(timeout=4000, force=True)
    await date_input.fill(date_value)
    await date_input.dispatch_event("input")
    await date_input.dispatch_event("change")
    await date_input.dispatch_event("blur")
    await date_input.press("Enter")
    
    await asyncio.sleep(1.0)
    
    # 验证设置结果
    actual_date = (await date_input.input_value() or "").strip()
    print(f"[DEBUG] 日期参数设置结果: 日期='{actual_date}'")
    
    if actual_date != date_value:
        print(f"[WARN] 日期设置失败，期望 '{date_value}'，实际 '{actual_date}'")
        # 重试设置
        await date_input.click(timeout=4000, force=True)
        await date_input.fill("")
        await date_input.type(date_value, delay=50)
        await date_input.dispatch_event("change")
        await asyncio.sleep(0.5)
        actual_date = (await date_input.input_value() or "").strip()
        print(f"[DEBUG] 日期重试后: '{actual_date}'")


async def set_date_and_refund(page, date_value: str, refund_start_date: str) -> None:
    """设置【日期】和【退费结束时间】参数。按索引定位：输入框0=日期，输入框1=退费结束时间。"""
    print(f"[INFO] 设置日期参数: 日期={date_value}, 退费结束时间={refund_start_date}")
    
    # 优先遍历所有frames查找输入框（适用于报表5-11）
    date_input = None
    refund_input = None
    
    for fr in all_frames(page):
        inputs = fr.locator('input.combobox-edit')
        input_count = await inputs.count()
        print(f"[DEBUG] 在frame '{fr.name}' 找到 {input_count} 个 combobox-edit 输入框")
        
        if input_count >= 2:
            date_input = inputs.nth(0)
            refund_input = inputs.nth(1)
            print(f"[DEBUG] 在frame '{fr.name}' 定位到日期输入框(0)和退费输入框(1)")
            break
    
    if date_input and refund_input:
        # 设置日期（输入框0）
        await date_input.evaluate('el => { el.removeAttribute("readonly"); el.readOnly = false; }')
        await date_input.click(timeout=4000, force=True)
        await date_input.fill(date_value)
        await date_input.dispatch_event("input")
        await date_input.dispatch_event("change")
        await date_input.dispatch_event("blur")
        await date_input.press("Enter")
        print(f"[DEBUG] 已设置日期(输入框0): {date_value}")
        
        # 设置退费结束时间（输入框1）
        await refund_input.evaluate('el => { el.removeAttribute("readonly"); el.readOnly = false; }')
        await refund_input.click(timeout=4000, force=True)
        await refund_input.fill(refund_start_date)
        await refund_input.dispatch_event("input")
        await refund_input.dispatch_event("change")
        await refund_input.dispatch_event("blur")
        await refund_input.press("Enter")
        print(f"[DEBUG] 已设置退费结束时间(输入框1): {refund_start_date}")
        
        await asyncio.sleep(1.5)
        
        # 验证设置结果
        actual_date = (await date_input.input_value() or "").strip()
        actual_refund = (await refund_input.input_value() or "").strip()
        print(f"[DEBUG] 日期参数设置结果: 日期='{actual_date}', 退费结束时间='{actual_refund}'")
        
        # 验证是否设置成功
        if actual_date != date_value:
            print(f"[WARN] 日期设置失败，期望 '{date_value}'，实际 '{actual_date}'")
            # 重试设置
            await date_input.click(timeout=4000, force=True)
            await date_input.fill("")
            await date_input.type(date_value, delay=50)
            await date_input.dispatch_event("change")
            await asyncio.sleep(0.5)
            actual_date = (await date_input.input_value() or "").strip()
            print(f"[DEBUG] 日期重试后: '{actual_date}'")
        
        if actual_refund != refund_start_date:
            print(f"[WARN] 退费结束时间设置失败，期望 '{refund_start_date}'，实际 '{actual_refund}'")
            # 重试设置
            await refund_input.click(timeout=4000, force=True)
            await refund_input.fill("")
            await refund_input.type(refund_start_date, delay=50)
            await refund_input.dispatch_event("change")
            await asyncio.sleep(0.5)
            actual_refund = (await refund_input.input_value() or "").strip()
            print(f"[DEBUG] 退费结束时间重试后: '{actual_refund}'")
        
        return
    
    # 兜底：按标签查找
    print("[DEBUG] 未按索引找到输入框，尝试按标签查找")
    for fr in all_frames(page):
        date_input = fr.locator('td:has-text("日期")').locator('xpath=ancestor::tr[1]//input.combobox-edit').first
        if await date_input.count() > 0:
            await date_input.evaluate('el => { el.removeAttribute("readonly"); el.readOnly = false; }')
            await date_input.click(timeout=4000, force=True)
            await date_input.fill(date_value)
            await date_input.dispatch_event("change")
            await date_input.dispatch_event("blur")
            print(f"[DEBUG] 已设置日期(按标签): {date_value}")
        
        refund_input = fr.locator('td:has-text("退费结束时间")').locator('xpath=ancestor::tr[1]//input.combobox-edit').first
        if await refund_input.count() > 0:
            await refund_input.evaluate('el => { el.removeAttribute("readonly"); el.readOnly = false; }')
            await refund_input.click(timeout=4000, force=True)
            await refund_input.fill(refund_start_date)
            await refund_input.dispatch_event("change")
            await refund_input.dispatch_event("blur")
            print(f"[DEBUG] 已设置退费结束时间(按标签): {refund_start_date}")
    
    await asyncio.sleep(1.0)
    
    actual_date = await get_input_value_by_row_label(page, "日期")
    actual_refund = await get_input_value_by_row_label(page, "退费结束时间")
    print(f"[DEBUG] 日期参数设置结果: 日期='{actual_date}', 退费结束时间='{actual_refund}'")


async def set_renewal_pools(page, pools: list[str]) -> None:
    """设置【思维续费池】多选参数。按索引定位：从左到右第3个输入框（索引为2）。"""
    print(f"[INFO] 设置思维续费池: {pools}")
    
    pool_input = None
    
    # 按索引定位：第3个输入框（索引为2）
    inputs = page.locator('input.combobox-edit')
    input_count = await inputs.count()
    print(f"[DEBUG] 找到 {input_count} 个 combobox-edit 输入框")
    
    if input_count >= 3:
        pool_input = inputs.nth(2)
        if await pool_input.is_visible():
            print(f"[DEBUG] 按索引定位到思维续费池输入框(第3个，索引2)")
        else:
            pool_input = None
    
    # 兜底：按标签定位
    if not pool_input:
        pool_input_xpath = page.locator(
            'xpath=//td[contains(normalize-space(.),"思维续费池")]/following-sibling::td//input[contains(@class,"combobox-edit")]'
        )
        xpath_count = await pool_input_xpath.count()
        print(f"[DEBUG] 思维续费池 XPath 命中输入框数量: {xpath_count}")
        for i in range(xpath_count):
            cand = pool_input_xpath.nth(i)
            if await cand.is_visible():
                pool_input = cand
                print(f"[DEBUG] 命中思维续费池输入框(xpath) index={i}")
                break
    
    if not pool_input:
        pool_label = page.locator('td:has-text("思维续费池")').first
        if await pool_label.count() > 0:
            tr = pool_label.locator("xpath=ancestor::tr[1]")
            nearby = tr.locator("input.combobox-edit")
            near_count = await nearby.count()
            print(f"[DEBUG] 思维续费池同行找到 {near_count} 个输入框")
            for i in range(near_count):
                cand = nearby.nth(i)
                if await cand.is_visible():
                    pool_input = cand
                    print(f"[DEBUG] 命中思维续费池输入框(tr) index={i}")
                    break
    
    if not pool_input:
        raise RuntimeError("未找到思维续费池输入框")
    
    pools_text = ",".join(pools)
    
    # 移除readonly属性（截图显示输入框有readonly）
    await pool_input.evaluate('el => { el.removeAttribute("readonly"); el.readOnly = false; }')
    
    await pool_input.click(timeout=5000, force=True)
    try:
        await pool_input.fill("")
    except Exception:
        await pool_input.press("Control+a")
        await pool_input.press("Backspace")
    await pool_input.type(pools_text, delay=50)
    await pool_input.press("Enter")
    await page.click("body", position={"x": 50, "y": 50}, timeout=3000)
    await asyncio.sleep(1.5)
    
    current_value = (await pool_input.input_value() or "").strip()
    print(f"[DEBUG] 思维续费池输入框当前值: {current_value}")


def parse_yyyymm(text: str) -> int | None:
    if not text:
        return None
    text = text.strip()
    m = re.search(r"(\d{4})\D?(\d{1,2})", text)
    if not m:
        return None
    y = int(m.group(1))
    mm = int(m.group(2))
    if mm < 1 or mm > 12:
        return None
    return y * 100 + mm


async def ensure_month_range(page, perf_month_raw: str, perf_month_cn: str) -> None:
    await wait_month_inputs_ready(page)
    target = parse_yyyymm(perf_month_raw)
    start_val, end_val = await wait_month_values(page)
    start_m = parse_yyyymm(start_val)
    end_m = parse_yyyymm(end_val)

    print(f"[DEBUG] 月份区间检查: 开始='{start_val}' 结束='{end_val}' 目标='{perf_month_raw}'")

    if target and start_m and end_m and start_m <= target <= end_m:
        print(f"[INFO] 绩效月份 {perf_month_raw} 已在区间内，不调整月份参数")
        return

    print(f"[INFO] 绩效月份 {perf_month_raw} 不在区间内，开始调整月份参数")
    year = int(perf_month_raw.split("-")[0])
    start_cn = f"{year:04d}年01月"
    end_cn = f"{year:04d}年12月"
    start_iso = f"{year:04d}-01"
    end_iso = f"{year:04d}-12"
    ok = await force_set_month_inputs(page, start_iso, end_iso)
    if not ok:
        raise RuntimeError("月份参数未生效：无法定位开始/结束月份输入框")
    await asyncio.sleep(0.6)
    s_chk, e_chk = await wait_month_values(page, timeout_ms=3000)
    if parse_yyyymm(s_chk) != year * 100 + 1 or parse_yyyymm(e_chk) != year * 100 + 12:
        await force_set_month_inputs(page, start_cn, end_cn)
    print(f"[DEBUG] 已写入月份参数: 开始='{start_iso}'(兜底{start_cn}) 结束='{end_iso}'(兜底{end_cn})")
    await refresh_report(page)
    await wait_refresh_visual_cycle(page, timeout_ms=45000)
    await wait_month_inputs_ready(page, timeout_ms=15000)
    await wait_until_month_in_table(page, perf_month_raw, timeout_ms=45000)
    print("[DEBUG] 月份参数写入后已执行刷新")

    await asyncio.sleep(1.0)
    start_val2, end_val2 = await wait_month_values(page, timeout_ms=12000)
    start_m2 = parse_yyyymm(start_val2)
    end_m2 = parse_yyyymm(end_val2)
    if not (target and start_m2 and end_m2 and start_m2 <= target <= end_m2):
        raise RuntimeError(
            f"月份参数未覆盖目标月份: 开始='{start_val2}' 结束='{end_val2}' 目标='{perf_month_raw}'"
        )
    print(f"[INFO] 月份参数已调整为全年区间并覆盖绩效月份: {start_cn} ~ {end_cn}")


async def apply_filters(page, report: dict, perf_month_raw: str, perf_month_cn: str, start_date: str, end_date: str) -> None:
    mode = report["mode"]
    if mode == "no_filters":
        print("[INFO] 当前报表无需调整参数，直接导出")
    elif mode == "month_trend":
        await ensure_month_range(page, perf_month_raw, perf_month_cn)
        await ensure_month_ready_with_retry(page, perf_month_raw)
    elif mode == "region_and_month":
        await set_and_verify(page, "区域等级", report["region"], required=True)
        await ensure_month_range(page, perf_month_raw, perf_month_cn)
        await ensure_month_ready_with_retry(page, perf_month_raw)
    elif mode == "date_only":
        await set_date_range_like_roi(page, start_date, end_date)
        await refresh_report(page)
        await wait_refresh_visual_cycle(page, timeout_ms=45000)
    elif mode == "date_and_subject":
        await set_date_range_like_roi(page, start_date, end_date)
        await set_subject_like_roi(page, "思维")
        await refresh_report(page)
        await wait_refresh_visual_cycle(page, timeout_ms=45000)
    elif mode == "region_only":
        await set_region_like_overseas(page, [report["region"]])
        await refresh_report(page)
        await wait_refresh_visual_cycle(page, timeout_ms=45000)
    elif mode == "date_and_refund":
        await set_date_and_refund(page, end_date, start_date)
        await refresh_report(page)
        await wait_refresh_visual_cycle(page, timeout_ms=45000)
    elif mode == "date_refund_and_pools":
        await set_date_and_refund(page, end_date, start_date)
        if "pools" in report:
            await set_renewal_pools(page, report["pools"])
        await refresh_report(page)
        await wait_refresh_visual_cycle(page, timeout_ms=45000)
    elif mode == "date_single":
        await set_single_date(page, end_date)
        await refresh_report(page)
        await wait_refresh_visual_cycle(page, timeout_ms=45000)
    else:
        raise RuntimeError(f"未知报表模式: {mode}")


async def refresh_report(page) -> None:
    query_selectors = [
        'input[title="查询"]',
        'button:has-text("查询")',
        'span:has-text("查询")',
        '[class*="query"]',
    ]
    for s in query_selectors:
        loc = page.locator(s).first
        if await loc.count() > 0:
            try:
                await loc.click(timeout=3000)
                print(f"[DEBUG] 点击查询按钮: {s}")
                await asyncio.sleep(1.5)
                break
            except Exception:
                continue

    selectors = [
        'input.bof_button.btnRefresh.queryview-toolbar-button.queryview-toolbar-refresh',
        'input[bofid="_btnRefresh"][type="button"]',
        'input.btnRefresh',
        'button.btnRefresh',
        'input[title="刷新"]',
        'span:has-text("刷新")',
        '[class*="refresh"]',
    ]
    for s in selectors:
        loc = page.locator(s).first
        if await loc.count() > 0:
            try:
                await loc.click(timeout=5000)
                print(f"[DEBUG] 点击刷新按钮: {s}")
                try:
                    await loc.dblclick(timeout=3000)
                    print(f"[DEBUG] 对刷新按钮执行双击兜底: {s}")
                except Exception:
                    pass
                await asyncio.sleep(8)
                return
            except Exception:
                continue
    raise RuntimeError("未找到刷新按钮")


async def click_first(page, selectors: list[str], desc: str) -> None:
    for s in selectors:
        loc = page.locator(s)
        if await loc.count() > 0:
            try:
                await loc.first.click(timeout=5000)
                return
            except Exception:
                continue
    raise RuntimeError(f"未找到元素: {desc}")


async def click_export_type_b(page) -> None:
    await click_first(page, ['input[value="导出"]', 'span:has-text("导出")', 'button:has-text("导出")', '[class*="export"]'], "导出按钮")
    await asyncio.sleep(0.5)
    await click_first(page, ['span:has-text("Excel")', 'div[caption="Excel"]', 'div[id^="EXCEL"]'], "Excel选项")
    await asyncio.sleep(0.5)
    await click_first(page, ['input[value="在线导出"]', 'div:has-text("在线导出")', 'text=在线导出'], "在线导出按钮")


async def export_report(page, report: dict) -> Path:
    target_path = make_export_target(report["name"])
    async with page.expect_download(timeout=180000) as dl_info:
        await click_export_type_b(page)
    download = await dl_info.value
    await download.save_as(str(target_path))
    print(f"[SUCCESS] 导出完成: {target_path.name}")
    return target_path


async def assert_month_ready_before_export(page, report: dict, perf_month_raw: str) -> None:
    if report["mode"] in ("month_trend", "region_and_month"):
        ok = await wait_until_month_in_table(page, perf_month_raw, timeout_ms=15000)
        if not ok:
            raise RuntimeError(f"导出前校验失败：正文未出现目标月份 {perf_month_raw}")


def copy_sheet_with_style(src_wb_path: Path, src_sheet_name: str, dst_wb: Workbook, dst_sheet_name: str) -> None:
    src_wb = load_workbook(src_wb_path, data_only=False)
    src_sheet = src_wb[src_sheet_name] if src_sheet_name in src_wb.sheetnames else src_wb[src_wb.sheetnames[0]]

    title = sanitize_sheet_title(dst_sheet_name)
    if title in dst_wb.sheetnames:
        i = 1
        base = title
        while f"{base}_{i}" in dst_wb.sheetnames:
            i += 1
        title = f"{base}_{i}"[:31]

    dst_sheet = dst_wb.create_sheet(title=title)

    for r in range(1, src_sheet.max_row + 1):
        for c in range(1, src_sheet.max_column + 1):
            s = src_sheet.cell(r, c)
            d = dst_sheet.cell(r, c)
            d.value = s.value
            if s.has_style:
                d.font = copy(s.font)
                d.fill = copy(s.fill)
                d.border = copy(s.border)
                d.alignment = copy(s.alignment)
                d.number_format = s.number_format
                d.protection = copy(s.protection)
            if s.comment:
                d.comment = copy(s.comment)
            if s.hyperlink:
                d._hyperlink = copy(s.hyperlink)

    for merged in src_sheet.merged_cells.ranges:
        dst_sheet.merge_cells(str(merged))

    for ridx, rdim in src_sheet.row_dimensions.items():
        dst_sheet.row_dimensions[ridx].height = rdim.height
        dst_sheet.row_dimensions[ridx].hidden = rdim.hidden
        dst_sheet.row_dimensions[ridx].outlineLevel = rdim.outlineLevel

    for ckey, cdim in src_sheet.column_dimensions.items():
        dst = dst_sheet.column_dimensions[ckey]
        dst.width = cdim.width
        dst.hidden = cdim.hidden
        dst.outlineLevel = cdim.outlineLevel
        dst.bestFit = cdim.bestFit

    dst_sheet.freeze_panes = src_sheet.freeze_panes
    try:
        dst_sheet.sheet_view.showGridLines = src_sheet.sheet_view.showGridLines
        dst_sheet.sheet_view.zoomScale = src_sheet.sheet_view.zoomScale
        dst_sheet.sheet_view.zoomScaleNormal = src_sheet.sheet_view.zoomScaleNormal
        dst_sheet.sheet_view.zoomScalePageLayoutView = src_sheet.sheet_view.zoomScalePageLayoutView
        dst_sheet.sheet_view.zoomScaleSheetLayoutView = src_sheet.sheet_view.zoomScaleSheetLayoutView
        dst_sheet.sheet_view.tabSelected = src_sheet.sheet_view.tabSelected
        dst_sheet.sheet_view.topLeftCell = src_sheet.sheet_view.topLeftCell
        dst_sheet.sheet_view.view = src_sheet.sheet_view.view
    except Exception:
        pass
    dst_sheet.page_margins = copy(src_sheet.page_margins)
    dst_sheet.page_setup = copy(src_sheet.page_setup)
    dst_sheet.print_options = copy(src_sheet.print_options)
    try:
        dst_sheet.sheet_properties = copy(src_sheet.sheet_properties)
    except AttributeError:
        pass
    dst_sheet.print_title_cols = src_sheet.print_title_cols
    dst_sheet.print_title_rows = src_sheet.print_title_rows
    if src_sheet.auto_filter and src_sheet.auto_filter.ref:
        dst_sheet.auto_filter.ref = src_sheet.auto_filter.ref


def make_final_output_path(perf_month: str) -> Path:
    dt = datetime.date.today().strftime("%Y%m%d")
    year, month = perf_month.split("-")
    prefix = f"{year[2:]}年{int(month)}月"
    base = OUTPUT_DIR / f"【{prefix}】管理者绩效明细-{dt}.xlsx"
    if not base.exists():
        return base
    i = 1
    while True:
        p = OUTPUT_DIR / f"【{prefix}】管理者绩效明细-{dt}v{i}.xlsx"
        if not p.exists():
            return p
        i += 1


def merge_exports(exported: list[tuple[dict, Path]], perf_month: str) -> Path:
    wb = Workbook()
    wb.remove(wb.active)

    for report, path in exported:
        src_sheet = report["merge"]["source_sheet"]
        dst_sheet = report["merge"]["target_sheet"]
        copy_sheet_with_style(path, src_sheet, wb, dst_sheet)

    out = make_final_output_path(perf_month)
    wb.save(out)
    return out


async def main() -> None:
    print("=" * 70)
    print("管理者绩效明细-批量导出合并脚本")
    print("=" * 70)

    perf_month_raw, perf_month_cn, start_date, end_date = parse_perf_month()
    selected_reports = choose_reports()
    load_env()

    exported: list[tuple[dict, Path]] = []

    for report in selected_reports:
        try:
            path = run_cli_export(report, perf_month_raw, start_date, end_date)
            exported.append((report, path))
        except Exception as e:
            print(f"[ERROR] 报表失败: {report['name']} -> {e}")

    if not exported:
        raise RuntimeError("本次没有任何报表导出成功")

    final_path = merge_exports(exported, perf_month_raw)
    print("\n" + "=" * 70)
    print(f"[SUCCESS] 最终文件生成: {final_path}")
    print("=" * 70)


if __name__ == "__main__":
    asyncio.run(main())
