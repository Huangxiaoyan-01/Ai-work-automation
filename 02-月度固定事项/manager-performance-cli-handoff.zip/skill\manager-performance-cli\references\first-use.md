# First Use Notes

## Main scripts

- `管理者绩效完整流程_CLI版.py`
- `管理者绩效_BI批量导出合并_CLI版.py`
- `管理者绩效_明细加工_CLI版.py`
- `管理者绩效_最终输出.py`

## Key fixed paths to update

- `SMARTBI_CLI_SCRIPT`
- `DOWNLOAD_DIR`
- `OUTPUT_DIR`
- `INPUT_FILE`
- `PROCESSED_FILE`

## Minimum files to provide

- `input/` with the final workbook template
- `output/`
- `downloads/`
- `需求说明/`
- `.env`

## First run order

1. Update paths
2. Configure `.env`
3. Run `管理者绩效完整流程_CLI版.py`
4. If needed, retry by stage

