import os
import re
from datetime import datetime
from pathlib import Path
from copy import copy

from openpyxl import load_workbook
from openpyxl.styles import Font, PatternFill, Border, Side, Alignment
from openpyxl.utils import get_column_letter


def convert_to_number(val):
    """将值转换为数字，支持字符串、数字等类型"""
    if val is None:
        return None
    if isinstance(val, (int, float)):
        return val
    if isinstance(val, str):
        # 移除可能的千分位分隔符和空格
        val = val.replace(',', '').replace(' ', '').strip()
        try:
            # 尝试转换为整数
            return int(val)
        except ValueError:
            try:
                # 尝试转换为浮点数
                return float(val)
            except ValueError:
                return None
    return None


def convert_to_percentage(val):
    """将值转换为百分比格式的数字（0-100范围），支持字符串、数字等类型"""
    if val is None:
        return None
    if isinstance(val, (int, float)):
        # 如果值已经大于1（比如0.85），说明是小数形式，转换为百分比
        if abs(val) < 1:
            return val * 100
        return val
    if isinstance(val, str):
        val = val.strip()
        # 如果是百分比字符串（如"85.00%"），提取数字部分
        if '%' in val:
            try:
                num_part = val.replace('%', '').replace(',', '').strip()
                return float(num_part)
            except ValueError:
                return None
        # 如果是公式字符串，返回None（无法计算）
        if val.startswith('='):
            return None
        # 尝试直接转换数字字符串
        try:
            num = float(val.replace(',', ''))
            if abs(num) < 1:
                return num * 100
            return num
        except ValueError:
            return None
    return None


# 路径配置
MERGED_DIR = Path(r"C:\Users\huangxiaoyan\Documents\trae_projects\test_week\output")  # 导出脚本合并后的文件目录
OUTPUT_DIR = Path(r"C:\Users\huangxiaoyan\Documents\trae_projects\test_week\output")  # 加工后的输出目录
DOWNLOAD_DIR = Path(r"C:\Users\huangxiaoyan\Documents\trae_projects\test_week\downloads")  # CLI导出目录

# 样式定义
RED_BOLD_FONT = Font(bold=True, color="FF0000")  # 红色加粗
YELLOW_FILL = PatternFill(start_color="FFFFFF00", end_color="FFFFFF00", fill_type="solid")  # 黄色高亮
THIN_BORDER = Border(left=Side(style='thin'),
                     right=Side(style='thin'),
                     top=Side(style='thin'),
                     bottom=Side(style='thin'))
MS_YAHEI_FONT = Font(name='微软雅黑', size=11)  # 微软雅黑字体
MS_YAHEI_BOLD_FONT = Font(name='微软雅黑', bold=True, color="FF0000", size=11)  # 微软雅黑红色加粗

# 各报表的保留列配置（根据需求说明5.2）
# 保留列格式: ["A-E", "DJ", "DK", "ED"] 或 ["A-K"]
KEEP_COLUMNS_CONFIG = {
    "非手推GMV": [],  # 默认保留所有列
    "港澳商务GMV|ROI": ["A-E", "DJ", "DK", "ED"],
    "台湾 滚转|例子到课率": [],  # 默认保留所有列（行过滤单独处理）
    "思维整体GMV": ["A-C", "E-Z"],  # 排除D列
    "一续升舱": ["A-K"],
    "统合升舱": ["A-K"],
    "统合早鸟": ["A-K"],
    "一续结课": ["A-M"],
    "统合结课": ["A-M"],
    "续费GMV达成率": ["A-U"],
    "后端转介绍达成": ["A-E", "M-U", "AJ-AL"],
}

# 需要保留行的sheet列表
KEEP_ROWS_CONFIG = {
    "台湾 滚转|例子到课率": "keep_taiwan_rows",  # 保留1-6行及滚动转化率、滚动GMV表格
}

# Sheet名称映射（合并文件中的sheet名 -> 加工后的sheet名）
# 支持两种格式：BI导出原始名称 和 已经重命名的中文名称
SHEET_NAME_MAP = {
    # BI导出原始名称格式
    "BI导出-海外投放ROI系数计算回写-20260430": "非手推GMV",
    "BI导出-港澳商务-链路达成数据-20260430": "港澳商务GMV|ROI",
    "BI导出-AI-海外漏斗达成情况-月趋势-台湾-20260430": "台湾 滚转|例子到课率",
    "BI导出-思维-续费率达成-20260430": "思维整体GMV",
    "BI导出-一续-升舱期-分课包续费率-20260430": "一续升舱",
    "BI导出-统合-升舱期-分课包续费率-20260430": "统合升舱",
    "BI导出-统合-早鸟期-分课包续费率-20260430": "统合早鸟",
    "BI导出-一续-结课期-续费率-20260430": "一续结课",
    "BI导出-近三月结课续费率-统合-20260430": "统合结课",
    "BI导出-续费GMV达成率-20260430": "续费GMV达成率",
    "BI导出-海外组织成本分摊-20260430": "后端转介绍达成",
    # 已重命名的中文名称格式（直接使用，无需转换）
    "非手推GMV": "非手推GMV",
    "港澳商务GMV|ROI": "港澳商务GMV|ROI",
    "台湾 滚转|例子到课率": "台湾 滚转|例子到课率",
    "思维整体GMV": "思维整体GMV",
    "一续升舱": "一续升舱",
    "统合升舱": "统合升舱",
    "统合早鸟": "统合早鸟",
    "一续结课": "一续结课",
    "统合结课": "统合结课",
    "续费GMV达成率": "续费GMV达成率",
    "后端转介绍达成": "后端转介绍达成",
}


def parse_perf_month() -> tuple[str, str, str, str]:
    """解析绩效月份输入"""
    raw = input("请输入绩效月份(YYYY-MM): ").strip()
    if not re.fullmatch(r"\d{4}-\d{2}", raw):
        raise ValueError("绩效月份格式错误，应为 YYYY-MM")
    y, m = raw.split("-")
    year, month = int(y), int(m)
    start_date = f"{year:04d}-{month:02d}-01"
    last_day = __import__('calendar').monthrange(year, month)[1]
    end_date = f"{year:04d}-{month:02d}-{last_day:02d}"
    month_cn = f"{year}年{month:02d}月"
    return raw, month_cn, start_date, end_date


def get_latest_cli_run_time() -> float | None:
    cli_root = DOWNLOAD_DIR / "cli_exports"
    if not cli_root.exists():
        return None
    run_logs = [path for path in cli_root.rglob("run.json") if path.is_file()]
    if not run_logs:
        return None
    run_logs.sort(key=lambda path: path.stat().st_mtime, reverse=True)
    return run_logs[0].stat().st_mtime


def find_merged_report(perf_month_cn: str) -> Path:
    """查找由完整流程合成的最新管理者绩效明细文件。"""
    year_match = re.search(r"(\d{4})", perf_month_cn)
    month_match = re.search(r"(\d{1,2})", perf_month_cn[4:])
    if not year_match or not month_match:
        raise ValueError(f"无法解析绩效月份: {perf_month_cn}")
    year = year_match.group(1)
    month = str(int(month_match.group(1)))
    short_month_cn = f"{year[2:]}年{month}月"

    all_matched_files = []
    patterns = [
        f"【{short_month_cn}】管理者绩效明细-*.xlsx",
        f"【{perf_month_cn}】管理者绩效明细-*.xlsx",
        f"【{short_month_cn}】管理者绩效-*.xlsx",
        f"【{perf_month_cn}】管理者绩效-*.xlsx",
    ]
    for pattern in patterns:
        for file in MERGED_DIR.glob(pattern):
            all_matched_files.append(file)

    if not all_matched_files:
        raise FileNotFoundError(f"未找到管理者绩效明细文件，尝试的格式包含: 【{short_month_cn}】管理者绩效明细-*.xlsx")

    latest_cli_run_mtime = get_latest_cli_run_time()
    if latest_cli_run_mtime is not None:
        aligned_files = [f for f in all_matched_files if f.stat().st_mtime >= latest_cli_run_mtime - 60]
        if aligned_files:
            all_matched_files = aligned_files
            print(f"[INFO] 按最新CLI运行时间筛选合并文件: {datetime.fromtimestamp(latest_cli_run_mtime).strftime('%Y-%m-%d %H:%M:%S')}")

    all_matched_files.sort(key=lambda f: f.stat().st_mtime, reverse=True)

    print("[DEBUG] 找到的合并文件列表（按修改时间排序）:")
    for i, file in enumerate(all_matched_files[:5]):
        mtime = datetime.fromtimestamp(file.stat().st_mtime).strftime("%Y-%m-%d %H:%M:%S")
        print(f"  {i+1}. {file.name} ({mtime})")

    latest_file = all_matched_files[0]
    print(f"[INFO] 选择最新的文件: {latest_file.name}")
    return latest_file

def get_month_column_index(ws, perf_month: str) -> int:
    """获取绩效月份所在的列索引"""
    month_formats = [
        perf_month,  # YYYY-MM
        perf_month.replace("-", ""),  # YYYYMM
        f"{perf_month.split('-')[0]}年{int(perf_month.split('-')[1]):02d}月",  # YYYY年MM月
        f"{int(perf_month.split('-')[1]):02d}月",  # MM月
        perf_month[2:],  # YY-MM
    ]
    
    for col in range(1, ws.max_column + 1):
        for row in range(1, min(30, ws.max_row + 1)):
            cell_value = str(ws.cell(row=row, column=col).value or "")
            for month_format in month_formats:
                if month_format in cell_value:
                    return col
    raise ValueError(f"未找到绩效月份 {perf_month} 所在列")


def mark_cell(ws, row: int, col: int):
    """标记指标单元格：红色加粗"""
    cell = ws.cell(row=row, column=col)
    cell.font = RED_BOLD_FONT


def highlight_row(ws, row: int):
    """整行黄色高亮"""
    # 使用copy确保每个单元格有独立的样式
    yellow_fill_copy = copy(YELLOW_FILL)
    
    # 遍历所有列，包括可能没有数据但存在的列
    for col in range(1, ws.max_column + 1):
        cell = ws.cell(row=row, column=col)
        cell.fill = yellow_fill_copy
    
    # 额外确保遍历列维度中定义的所有列
    for col_letter in ws.column_dimensions:
        col_num = column_letter_to_num(col_letter)
        if col_num <= ws.max_column:
            cell = ws.cell(row=row, column=col_num)
            cell.fill = copy(YELLOW_FILL)


def column_letter_to_num(col_letter):
    """将列字母转换为数字（支持双字母列如AA、AB等）"""
    col_letter = col_letter.upper()
    num = 0
    for char in col_letter:
        num = num * 26 + (ord(char) - ord('A') + 1)
    return num


def parse_column_range(range_str):
    """解析列范围字符串，返回列字母集合"""
    result = set()
    if '-' in range_str:
        start, end = range_str.split('-')
        start_num = column_letter_to_num(start)
        end_num = column_letter_to_num(end)
        for i in range(start_num, end_num + 1):
            result.add(get_column_letter(i))
    else:
        result.add(range_str.upper())
    return result


def hide_columns(ws, sheet_name: str, original_max_col: int = 0):
    """根据配置隐藏列（保留指定列）"""
    # 尝试原始名称查找，失败则尝试转换为半角竖线查找
    keep_columns = KEEP_COLUMNS_CONFIG.get(sheet_name, [])
    
    if not keep_columns:
        # 尝试转换为半角竖线查找
        normalized_name = sheet_name.replace('｜', '|')
        keep_columns = KEEP_COLUMNS_CONFIG.get(normalized_name, [])
    
    if not keep_columns:
        print(f"[DEBUG] {sheet_name} 保留所有列")
        return
    
    # 解析保留列
    keep_set = set()
    for col_spec in keep_columns:
        keep_set.update(parse_column_range(col_spec))
    
    print(f"[DEBUG] {sheet_name} 保留列: {sorted(keep_set)}")
    
    # 隐藏不在保留列表中的列
    # 遍历所有可能的列（从A到最大列）
    max_col_num = ws.max_column
    for col_num in range(1, max_col_num + 1):
        # 如果设置了original_max_col，跳过新增的计算结果列
        if original_max_col > 0 and col_num > original_max_col:
            continue
        col_letter = get_column_letter(col_num)
        if col_letter not in keep_set:
            ws.column_dimensions[col_letter].hidden = True


def filter_taiwan_rows(ws):
    """台湾报表行过滤：保留1-6行及滚动转化率、例子到课率（当月）表格所在行"""
    print("[DEBUG] 台湾报表行过滤")
    
    # 找出需要保留的行
    keep_rows = set(range(1, 7))  # 保留1-6行
    
    # 通过D列文本判断保留整个滚动转化率和例子到课率（当月）表格
    # 同时保留B列=关键词所在的数据行
    in_scroll_table = False
    in_attendance_table = False
    
    for row in range(1, ws.max_row + 1):
        b_value = str(ws.cell(row=row, column=2).value or "")  # B列
        d_value = str(ws.cell(row=row, column=4).value or "")  # D列
        
        # 通过D列判断是否在滚动转化率表格中
        if "滚动转化率" in d_value:
            in_scroll_table = True
            in_attendance_table = False
        # 通过D列判断是否在例子到课率（当月）表格中
        elif "例子到课率" in d_value and "当月" in d_value:
            in_scroll_table = False
            in_attendance_table = True
        # 如果在滚动转化率表格之后，例子到课率表格之前，检查是否应该结束滚动转化率表格
        elif in_scroll_table and "例子到课率" in d_value:
            in_scroll_table = False
        
        # 如果在目标表格中，保留该行
        if in_scroll_table or in_attendance_table:
            keep_rows.add(row)
        
        # 另外，保留B列包含关键词的行（表头行）
        if "滚动转化率" in b_value or ("例子到课率" in b_value and "当月" in b_value):
            keep_rows.add(row)
    
    print(f"[DEBUG] 保留的行数: {len(keep_rows)}")
    
    # 隐藏不保留的行
    for row in range(1, ws.max_row + 1):
        if row not in keep_rows:
            ws.row_dimensions[row].hidden = True


def process_non_hand_push_gmv(ws, perf_month: str):
    """4.1 非手推GMV"""
    print("[INFO] 处理非手推GMV")
    
    table_start = None
    for row in range(1, ws.max_row + 1):
        cell_value = str(ws.cell(row=row, column=2).value or "")  # C列搜索
        if "滚动GMV" in cell_value:
            table_start = row
            break
    
    if not table_start:
        print("[WARN] 未找到'滚动GMV'表格")
        return
    
    # 找到绩效月份对应的列（在表头行中查找）
    perf_month_col = None
    for col in range(1, ws.max_column + 1):
        header_value = str(ws.cell(row=table_start, column=col).value or "")
        if perf_month in header_value:
            perf_month_col = col
            break
    
    if not perf_month_col:
        print(f"[WARN] 未找到绩效月份 '{perf_month}' 对应的列")
        return
    
    target_row = None
    for row in range(table_start, min(table_start + 50, ws.max_row + 1)):
        cell_value = str(ws.cell(row=row, column=2).value or "")  # C列搜索
        if "非手推" in cell_value:
            target_row = row
            break
    
    if not target_row:
        print("[WARN] 未找到'非手推'所在行")
        return
    
    # 标记绩效月份列与目标行交叉的单元格
    mark_cell(ws, target_row, perf_month_col)
    highlight_row(ws, target_row)
    print(f"[DEBUG] 非手推GMV: 行={target_row}, 绩效月份列={perf_month_col}")


def process_hk_macao_gmv_roi(ws, perf_month: str):
    """4.2 港澳商务GMV|ROI"""
    print("[INFO] 处理港澳商务GMV|ROI")
    
    header_row = 5
    main_subject_col = None
    gmv_col = None
    roi_col = None
    
    for col in range(1, ws.max_column + 1):
        cell_value = str(ws.cell(row=header_row, column=col).value or "")
        if "主投" in cell_value and "滚动" not in cell_value and main_subject_col is None:
            main_subject_col = col
        if "主投滚动GMV" in cell_value:
            gmv_col = col
        if "主投滚动ROI" in cell_value:
            roi_col = col
    
    if not main_subject_col:
        print("[WARN] 未找到'主投'列")
        return
    if not gmv_col:
        print("[WARN] 未找到'主投滚动GMV'列")
        return
    if not roi_col:
        print("[WARN] 未找到'主投滚动ROI'列")
        return
    
    target_row = None
    for row in range(header_row + 1, ws.max_row + 1):
        cell_value = str(ws.cell(row=row, column=main_subject_col).value or "")
        if "总计" in cell_value:
            target_row = row
            break
    
    if not target_row:
        print("[WARN] 未找到【主投】='总计'所在行")
        return
    
    mark_cell(ws, target_row, gmv_col)
    mark_cell(ws, target_row, roi_col)
    highlight_row(ws, target_row)
    print(f"[DEBUG] 港澳商务GMV|ROI: 行={target_row}, GMV列={gmv_col}, ROI列={roi_col}")


def process_taiwan_conversion(ws, perf_month: str):
    """4.3 台湾 滚转|例子到课率"""
    print("[INFO] 处理台湾滚转|例子到课率")
    
    # 滚动转化率
    table_start = None
    for row in range(1, ws.max_row + 1):
        cell_value = str(ws.cell(row=row, column=2).value or "")  # B列搜索
        if "滚动转化率" in cell_value:
            table_start = row
            break
    
    if table_start:
        # 找到绩效月份对应的列
        perf_month_col = None
        for col in range(1, ws.max_column + 1):
            header_value = str(ws.cell(row=table_start, column=col).value or "")
            if perf_month in header_value:
                perf_month_col = col
                break
        
        if perf_month_col:
            for row in range(table_start, min(table_start + 30, ws.max_row + 1)):
                col2_value = str(ws.cell(row=row, column=2).value or "")  # B列搜索
                if "汇总" in col2_value:
                    # 标记绩效月份列与目标行交叉的单元格
                    mark_cell(ws, row, perf_month_col)
                    highlight_row(ws, row)
                    print(f"[DEBUG] 滚动转化率汇总: 行={row}, 绩效月份列={perf_month_col}")
                    break
    
    # 例子到课率（当月）
    table_start = None
    for row in range(1, ws.max_row + 1):
        cell_value = str(ws.cell(row=row, column=2).value or "")  # B列搜索
        if "例子到课率" in cell_value and "当月" in cell_value:
            table_start = row
            break
    
    if table_start:
        # 找到绩效月份对应的列
        perf_month_col = None
        for col in range(1, ws.max_column + 1):
            header_value = str(ws.cell(row=table_start, column=col).value or "")
            if perf_month in header_value:
                perf_month_col = col
                break
        
        if perf_month_col:
            # 扩大搜索范围，确保能找到汇总行
            search_end = min(table_start + 50, ws.max_row + 1)
            target_row = None
            for row in range(table_start, search_end):
                col2_value = str(ws.cell(row=row, column=2).value or "")  # B列搜索
                if "汇总" in col2_value:
                    target_row = row
                    break
            
            if target_row:
                # 标记绩效月份列与目标行交叉的单元格
                mark_cell(ws, target_row, perf_month_col)
                highlight_row(ws, target_row)
                print(f"[DEBUG] 例子到课率汇总: 行={target_row}, 绩效月份列={perf_month_col}")
            else:
                print(f"[WARN] 例子到课率（当月）未找到汇总行，搜索范围: {table_start}-{search_end}")


def process_overall_gmv(ws, perf_month: str):
    """4.4 思维整体GMV"""
    print("[INFO] 处理思维整体GMV")
    
    table_start = None
    for row in range(1, ws.max_row + 1):
        cell_value = str(ws.cell(row=row, column=2).value or "")  # C列搜索
        if "滚动GMV" in cell_value:
            table_start = row
            break
    
    if not table_start:
        print("[WARN] 未找到'滚动GMV'表格")
        return
    
    # 找到绩效月份对应的列（在表头行中查找）
    perf_month_col = None
    for col in range(1, ws.max_column + 1):
        header_value = str(ws.cell(row=table_start, column=col).value or "")
        if perf_month in header_value:
            perf_month_col = col
            break
    
    if not perf_month_col:
        print(f"[WARN] 未找到绩效月份 '{perf_month}' 对应的列")
        return
    
    target_row = None
    for row in range(table_start, min(table_start + 30, ws.max_row + 1)):
        col2_value = str(ws.cell(row=row, column=2).value or "")  # C列搜索
        if "汇总" in col2_value:
            target_row = row
            break
    
    if not target_row:
        print("[WARN] 未找到汇总行")
        return
    
    # 标记绩效月份列与目标行交叉的单元格
    mark_cell(ws, target_row, perf_month_col)
    highlight_row(ws, target_row)
    print(f"[DEBUG] 思维整体GMV: 行={target_row}, 绩效月份列={perf_month_col}")


def process_hk_macao_renewal_rate(ws, sheet_name: str, perf_month: str):
    """5.3 后端港澳团队指标加工 - 升舱类（一续升舱、统合升舱、统合早鸟）"""
    print(f"[INFO] 处理{sheet_name} - 港澳团队指标")
    
    pool_total = 0  # 池子数汇总
    renewal_total = 0  # 累计续费人数汇总
    target_rows = []  # 记录涉及的行
    
    # 定位B列【大区】包含"港澳"字样且C列【LP个人】="总计"的行
    for row in range(1, ws.max_row + 1):
        b_value = str(ws.cell(row=row, column=2).value or "")  # B列-大区
        c_value = str(ws.cell(row=row, column=3).value or "")  # C列-LP个人
        
        if "港澳" in b_value and c_value == "总计":
            # 汇总D列【池子数】、F列【累计续费人数】
            d_value = ws.cell(row=row, column=4).value  # D列-池子数
            f_value = ws.cell(row=row, column=6).value  # F列-累计续费人数
            
            if isinstance(d_value, (int, float)):
                pool_total += d_value
            if isinstance(f_value, (int, float)):
                renewal_total += f_value
            
            target_rows.append(row)
            highlight_row(ws, row)  # 黄色高亮涉及的行
    
    # 计算续费率
    if pool_total > 0:
        renewal_rate = (renewal_total / pool_total) * 100
    else:
        renewal_rate = 0
    
    # 在报表最右方写入计算结果
    last_col = ws.max_column
    write_col = last_col + 2  # 空一列后写入
    end_col = write_col + 3  # 最后一列

    # 写入表头（不高亮）
    ws.cell(row=1, column=write_col, value="x月")
    ws.cell(row=1, column=write_col + 1, value="池子数")
    ws.cell(row=1, column=write_col + 2, value="累计续费人数")
    ws.cell(row=1, column=write_col + 3, value="续费率")

    # 写入数据
    data_row = 2
    ws.cell(row=data_row, column=write_col, value="港澳团队")
    ws.cell(row=data_row, column=write_col + 1, value=pool_total)
    ws.cell(row=data_row, column=write_col + 2, value=renewal_total)
    ws.cell(row=data_row, column=write_col + 3, value=f"{renewal_rate:.2f}%")

    # 设置样式：微软雅黑字体
    for row in [1, data_row]:
        for col in range(write_col, end_col + 1):
            cell = ws.cell(row=row, column=col)
            cell.font = MS_YAHEI_FONT

    # 设置续费率单元格样式（红色加粗）
    rate_cell = ws.cell(row=data_row, column=write_col + 3)
    rate_cell.font = MS_YAHEI_BOLD_FONT
    # 黄色高亮数据行
    highlight_row(ws, data_row)

    print(f"[DEBUG] {sheet_name} 港澳团队指标: 池子数={pool_total}, 累计续费人数={renewal_total}, 续费率={renewal_rate:.2f}%")


def process_hk_macao_renewal_rate_class_end(ws, sheet_name: str, perf_month: str):
    """5.3 后端港澳团队指标加工 - 结课类（一续结课、统合结课）"""
    print(f"[INFO] 处理{sheet_name} - 港澳团队指标")
    
    pool_total = 0  # 池子数汇总
    renewal_total = 0  # 累计续费人数汇总
    target_rows = []  # 记录涉及的行
    
    # 定位B列【小组】包含"港澳"字样且D列【LP个人】="总计"的行
    for row in range(1, ws.max_row + 1):
        b_value = str(ws.cell(row=row, column=2).value or "")  # B列-小组
        d_value = str(ws.cell(row=row, column=4).value or "")  # D列-LP个人
        
        if "港澳" in b_value and d_value == "总计":
            # 汇总E列【池子数】、G列【累计续费人数】
            e_value = ws.cell(row=row, column=5).value  # E列-池子数
            g_value = ws.cell(row=row, column=7).value  # G列-累计续费人数
            
            if isinstance(e_value, (int, float)):
                pool_total += e_value
            if isinstance(g_value, (int, float)):
                renewal_total += g_value
            
            target_rows.append(row)
            highlight_row(ws, row)  # 黄色高亮涉及的行
    
    # 计算续费率
    if pool_total > 0:
        renewal_rate = (renewal_total / pool_total) * 100
    else:
        renewal_rate = 0
    
    # 在报表最右方写入计算结果
    last_col = ws.max_column
    write_col = last_col + 2  # 空一列后写入
    end_col = write_col + 3  # 最后一列

    # 写入表头（不高亮）
    ws.cell(row=1, column=write_col, value="x月")
    ws.cell(row=1, column=write_col + 1, value="池子数")
    ws.cell(row=1, column=write_col + 2, value="累计续费人数")
    ws.cell(row=1, column=write_col + 3, value="续费率")

    # 写入数据
    data_row = 2
    ws.cell(row=data_row, column=write_col, value="港澳团队")
    ws.cell(row=data_row, column=write_col + 1, value=pool_total)
    ws.cell(row=data_row, column=write_col + 2, value=renewal_total)
    ws.cell(row=data_row, column=write_col + 3, value=f"{renewal_rate:.2f}%")

    # 设置样式：微软雅黑字体
    for row in [1, data_row]:
        for col in range(write_col, end_col + 1):
            cell = ws.cell(row=row, column=col)
            cell.font = MS_YAHEI_FONT

    # 设置续费率单元格样式（红色加粗）
    rate_cell = ws.cell(row=data_row, column=write_col + 3)
    rate_cell.font = MS_YAHEI_BOLD_FONT
    # 黄色高亮数据行
    highlight_row(ws, data_row)

    print(f"[DEBUG] {sheet_name} 港澳团队指标: 池子数={pool_total}, 累计续费人数={renewal_total}, 续费率={renewal_rate:.2f}%")


def process_hk_macao_gmv_rate(ws, ws_path: str, sheet_name: str, perf_month: str):
    """5.3 后端港澳团队指标加工 - 续费GMV达成率"""
    print(f"[INFO] 处理{sheet_name} - 港澳团队指标")

    # 定位A列【团队】="港澳益智教学服务区"所在行（重点关注前20行）
    target_row = None
    target_col = None
    gmv_rate_value = None

    search_end = min(21, ws.max_row + 1)
    for row in range(1, search_end):
        a_value = str(ws.cell(row=row, column=1).value or "")  # A列-团队
        if "港澳益智教学服务区" in a_value:
            target_row = row
            # 查找【月累计达成率】列（表头在第二行）
            for col in range(1, ws.max_column + 1):
                header_value = str(ws.cell(row=2, column=col).value or "")  # 表头在第二行
                if "月累计达成率" in header_value:
                    target_col = col
                    break
            break

    if target_row and target_col:
        # 尝试获取月累计达成率的值
        raw_value = ws.cell(row=target_row, column=target_col).value
        print(f"[DEBUG] {sheet_name} 港澳益智教学服务区: 行={target_row}, 月累计达成率列={target_col}, 原始值={raw_value}")

        # 尝试解析月累计达成率
        gmv_rate_value = convert_to_percentage(raw_value)

        # 如果无法从O列获取值，尝试从K列（月累计GMV）、U列（退款）、E列（目标）计算
        if gmv_rate_value is None:
            print(f"[DEBUG] 月累计达成率为公式或空，尝试手动计算...")
            # 根据表头结构：
            # 列5=月度目标(E列), 列11=累计流水(K列), 月累计达成率公式=(K-U)/E
            # 查找退款列（通过表头遍历）
            refund_col = None
            for row in range(1, 6):
                for col in range(1, ws.max_column + 1):
                    header = str(ws.cell(row=row, column=col).value or "").strip()
                    if "退款" in header:
                        refund_col = col
                        break

            # 从表头已知：E=5, K=11
            e_col = 5
            k_col = 11

            print(f"[DEBUG] 找到列: K列(累计流水)={k_col}, E列(月度目标)={e_col}, 退款列={refund_col}")

            k_val = convert_to_number(ws.cell(row=target_row, column=k_col).value)
            e_val = convert_to_number(ws.cell(row=target_row, column=e_col).value)
            u_val = None
            if refund_col:
                u_val = convert_to_number(ws.cell(row=target_row, column=refund_col).value)
            print(f"[DEBUG] K(累计流水)={k_val}, E(月度目标)={e_val}, U(退款)={u_val}")

            if k_val is not None and e_val is not None and e_val != 0:
                gmv_rate_value = ((k_val - (u_val or 0)) / e_val) * 100
                print(f"[DEBUG] 手动计算达成率: {gmv_rate_value:.2f}%")

        # 黄色高亮该行
        highlight_row(ws, target_row)
        # 红色加粗标取值的单元格
        mark_cell(ws, target_row, target_col)
        print(f"[DEBUG] {sheet_name} 港澳益智教学服务区: 行={target_row}, 月累计达成率列={target_col}, 值={gmv_rate_value}")
        
        # 在报表最右方写入计算结果
        last_col = ws.max_column
        write_col = last_col + 2  # 空一列后写入

        # 写入表头（不高亮）
        header_cell1 = ws.cell(row=1, column=write_col, value="港澳")
        header_cell2 = ws.cell(row=1, column=write_col + 1, value="月累计达成率")

        # 写入数据
        data_row = 2
        data_cell1 = ws.cell(row=data_row, column=write_col, value="港澳益智教学服务区")
        # 月累计达成率用百分比展示，保留两位小数
        rate_value = convert_to_number(gmv_rate_value)
        if rate_value is not None:
            rate_display = f"{rate_value:.2f}%"
        else:
            rate_display = gmv_rate_value
        data_cell2 = ws.cell(row=data_row, column=write_col + 1, value=rate_display)

        # 设置样式：微软雅黑字体
        for row in [1, data_row]:
            for col in [write_col, write_col + 1]:
                cell = ws.cell(row=row, column=col)
                cell.font = MS_YAHEI_FONT

        # 设置月累计达成率值单元格样式（红色加粗）
        data_cell2.font = MS_YAHEI_BOLD_FONT
    else:
        print(f"[WARN] {sheet_name} 未找到港澳益智教学服务区或月累计达成率列")


def process_hk_macao_conversion(ws, sheet_name: str, perf_month: str):
    """5.3 后端港澳团队指标加工 - 后端转介绍达成"""
    print(f"[INFO] 处理{sheet_name} - 港澳团队指标")
    
    total_cases = 0  # 全体带海外例子数
    total_target = 0  # 海外转介绍例子目标
    total_gmv = 0  # 滚动GMV
    total_gmv_target = 0  # 滚动GMV目标
    target_rows = []  # 记录涉及的行
    
    # 先全局查找列位置（在表头行中查找，通常是第4-6行）
    cases_col = None
    target_col = None
    gmv_col = None
    gmv_target_col = None
    
    # 在多个可能的表头行中查找
    for header_row in range(4, 7):
        for col in range(1, ws.max_column + 1):
            header_value = str(ws.cell(row=header_row, column=col).value or "")
            if cases_col is None and "全体带海外例子数" in header_value:
                cases_col = col
                print(f"[DEBUG] 找到列: 全体带海外例子数 = {col} (表头行{header_row})")
            if target_col is None and "海外转介绍例子目标" in header_value:
                target_col = col
                print(f"[DEBUG] 找到列: 海外转介绍例子目标 = {col} (表头行{header_row})")
            if gmv_col is None and "滚动GMV" in header_value and "目标" not in header_value and "完成率" not in header_value:
                gmv_col = col
                print(f"[DEBUG] 找到列: 滚动GMV = {col} (表头行{header_row})")
            if gmv_target_col is None and "滚动GMV目标" in header_value:
                gmv_target_col = col
                print(f"[DEBUG] 找到列: 滚动GMV目标 = {col} (表头行{header_row})")
    
    # 打印最终找到的列位置
    print(f"[DEBUG] 列位置汇总: cases_col={cases_col}, target_col={target_col}, gmv_col={gmv_col}, gmv_target_col={gmv_target_col}")
    
    # 定位"海外-小组"区域（通过查找"海外-小组"行，然后找到下一个同级别或更高级别的区域作为结束）
    overseas_start = None
    overseas_end = None
    
    for row in range(1, ws.max_row + 1):
        b_value = str(ws.cell(row=row, column=2).value or "")
        # 查找"海外-小组"或包含"海外-小组"的单元格
        if "海外-小组" in b_value:
            overseas_start = row
            # 查找区域结束：下一个B列非空的行（即下一个区域开始）
            for next_row in range(row + 1, ws.max_row + 1):
                next_b_value = str(ws.cell(row=next_row, column=2).value or "")
                # 如果B列有值且不是子层级（如"港澳1组"这种属于子层级，B列为空）
                if next_b_value and next_b_value != "None":
                    overseas_end = next_row - 1
                    break
            if overseas_end is None:
                overseas_end = ws.max_row
            break
    
    print(f"[DEBUG] 海外-小组区域: 起始行={overseas_start}, 结束行={overseas_end}")
    
    # 在"海外-小组"区域内查找C列包含"港澳"的行
    if overseas_start and overseas_end:
        for row in range(overseas_start, overseas_end + 1):
            c_value = str(ws.cell(row=row, column=3).value or "")  # C列-团队/小组
            
            if "港澳" in c_value:
                print(f"[DEBUG] 找到港澳行: row={row}, c_value={c_value}")
                
                # 汇总数据
                if cases_col:
                    val = ws.cell(row=row, column=cases_col).value
                    val_num = convert_to_number(val)
                    print(f"[DEBUG]   全体带海外例子数 (列{cases_col}): {val} -> {val_num}")
                    if val_num is not None:
                        total_cases += val_num
                if target_col:
                    val = ws.cell(row=row, column=target_col).value
                    val_num = convert_to_number(val)
                    print(f"[DEBUG]   海外转介绍例子目标 (列{target_col}): {val} -> {val_num}")
                    if val_num is not None:
                        total_target += val_num
                if gmv_col:
                    val = ws.cell(row=row, column=gmv_col).value
                    val_num = convert_to_number(val)
                    print(f"[DEBUG]   滚动GMV (列{gmv_col}): {val} -> {val_num}")
                    if val_num is not None:
                        total_gmv += val_num
                if gmv_target_col:
                    val = ws.cell(row=row, column=gmv_target_col).value
                    val_num = convert_to_number(val)
                    print(f"[DEBUG]   滚动GMV目标 (列{gmv_target_col}): {val} -> {val_num}")
                    if val_num is not None:
                        total_gmv_target += val_num
                
                target_rows.append(row)
                highlight_row(ws, row)  # 黄色高亮涉及的行
    
    # 计算达成率
    if total_target > 0:
        case_rate = (total_cases / total_target) * 100
    else:
        case_rate = 0
    
    if total_gmv_target > 0:
        gmv_rate = (total_gmv / total_gmv_target) * 100
    else:
        gmv_rate = 0
    
    # 转介绍综合达成率 = 例子达成率*0.6 + 滚动GMV完成率*0.4
    combined_rate = case_rate * 0.6 + gmv_rate * 0.4
    
    # 在报表最右方写入计算结果
    last_col = ws.max_column
    write_col = last_col + 2  # 空一列后写入
    end_col = write_col + 7  # 最后一列
    
    # 写入表头（不高亮）
    ws.cell(row=1, column=write_col, value="港澳")
    ws.cell(row=1, column=write_col + 1, value="全体带海外例子数")
    ws.cell(row=1, column=write_col + 2, value="海外转介绍例子目标")
    ws.cell(row=1, column=write_col + 3, value="例子达成率-月度")
    ws.cell(row=1, column=write_col + 4, value="滚动GMV")
    ws.cell(row=1, column=write_col + 5, value="滚动GMV目标")
    ws.cell(row=1, column=write_col + 6, value="滚动GMV完成率")
    ws.cell(row=1, column=write_col + 7, value="转介绍综合达成率")
    
    # 写入数据
    data_row = 2
    ws.cell(row=data_row, column=write_col, value="港澳")
    ws.cell(row=data_row, column=write_col + 1, value=total_cases)
    ws.cell(row=data_row, column=write_col + 2, value=total_target)
    ws.cell(row=data_row, column=write_col + 3, value=f"{case_rate:.2f}%")
    ws.cell(row=data_row, column=write_col + 4, value=total_gmv)
    ws.cell(row=data_row, column=write_col + 5, value=total_gmv_target)
    ws.cell(row=data_row, column=write_col + 6, value=f"{gmv_rate:.2f}%")
    ws.cell(row=data_row, column=write_col + 7, value=f"{combined_rate:.2f}%")
    
    # 设置样式：微软雅黑字体
    for row in [1, data_row]:
        for col in range(write_col, end_col + 1):
            cell = ws.cell(row=row, column=col)
            cell.font = MS_YAHEI_FONT

    # 设置转介绍综合达成率单元格样式（红色加粗）
    combined_cell = ws.cell(row=data_row, column=write_col + 7)
    combined_cell.font = MS_YAHEI_BOLD_FONT
    # 黄色高亮数据行
    highlight_row(ws, data_row)
    
    print(f"[DEBUG] {sheet_name} 港澳团队指标: 例子数={total_cases}, 例子目标={total_target}, 例子达成率={case_rate:.2f}%, GMV={total_gmv}, GMV目标={total_gmv_target}, GMV完成率={gmv_rate:.2f}%, 综合达成率={combined_rate:.2f}%")


def process_renewal_metrics(ws, sheet_name: str, perf_month: str):
    """4.5-4.11 后端指标（续费相关）"""
    print(f"[INFO] 处理{sheet_name}")
    
    if "升舱" in sheet_name:
        for row in range(1, ws.max_row + 1):
            cell_value = str(ws.cell(row=row, column=1).value or "")
            if "汇总" in cell_value:
                # 标记最后一个有数据的列
                last_col = ws.max_column
                while last_col > 1:
                    if ws.cell(row=row, column=last_col).value:
                        break
                    last_col -= 1
                mark_cell(ws, row, last_col)
                highlight_row(ws, row)
                print(f"[DEBUG] {sheet_name}汇总: 行={row}, 列={last_col}")
                break
    elif "结课" in sheet_name:
        for row in range(1, ws.max_row + 1):
            for col in range(1, min(10, ws.max_column + 1)):
                cell_value = str(ws.cell(row=row, column=col).value or "")
                if "近三月续费率涨幅" in cell_value:
                    # 标记目标行的关键列（最后3列）
                    last_col = ws.max_column
                    for mark_col in range(max(1, last_col - 2), last_col + 1):
                        mark_cell(ws, row + 1, mark_col)
                    highlight_row(ws, row + 1)
                    print(f"[DEBUG] {sheet_name}近三月续费率涨幅: 行={row+1}")
                    break
    elif "续费GMV" in sheet_name:
        for row in range(1, ws.max_row + 1):
            cell_value = str(ws.cell(row=row, column=1).value or "")
            if "汇总" in cell_value or "总计" in cell_value:
                # 标记最后3列
                last_col = ws.max_column
                for mark_col in range(max(1, last_col - 2), last_col + 1):
                    mark_cell(ws, row, mark_col)
                highlight_row(ws, row)
                print(f"[DEBUG] {sheet_name}汇总: 行={row}")
                break


def process_backend_conversion(ws, perf_month: str):
    """4.5-4.11 后端转介绍达成"""
    print("[INFO] 处理后端转介绍达成")
    
    for row in range(1, ws.max_row + 1):
        cell_value = str(ws.cell(row=row, column=1).value or "")
        if "海外-整体" in cell_value:
            # 标记最后5列
            last_col = ws.max_column
            for col in range(max(1, last_col - 4), last_col + 1):
                mark_cell(ws, row, col)
            highlight_row(ws, row)
            print(f"[DEBUG] 后端转介绍达成整体: 行={row}")
            break


def auto_adjust_column_width(ws):
    """自动调整列宽以适应内容"""
    print("[DEBUG] 自动调整列宽")
    
    for col in range(1, ws.max_column + 1):
        max_length = 0
        col_letter = get_column_letter(col)
        has_number = False
        
        # 遍历该列的所有单元格，找到最长的内容
        for row in range(1, ws.max_row + 1):
            cell = ws.cell(row=row, column=col)
            cell_value = str(cell.value) if cell.value else ""
            # 判断是否包含数字
            if any(char.isdigit() for char in cell_value):
                has_number = True
            # 计算字符长度（中文字符算1个，英文字符和数字算0.5个）
            length = sum(1 if '\u4e00' <= char <= '\u9fff' else 0.5 for char in cell_value)
            max_length = max(max_length, length)
        
        # 设置列宽，留一些余量
        # 对于包含数字的列，设置最小宽度为14，确保能显示较长的数字（如大金额）
        min_width = 14 if has_number else 8
        if max_length > 0:
            ws.column_dimensions[col_letter].width = max(min_width, min(max_length + 2, 50))  # 最大宽度限制为50，最小宽度根据是否有数字调整
        else:
            ws.column_dimensions[col_letter].width = min_width


def process_sheet(ws, merged_path: str, sheet_name: str, perf_month: str):
    """处理单个sheet"""
    print(f"\n[INFO] 处理Sheet: {sheet_name}")
    
    # 记录原始最大列数（用于保护新增的计算结果列不被隐藏）
    original_max_col = ws.max_column
    
    # 统一转换为半角竖线进行比较（处理可能的全角/半角问题）
    normalized_name = sheet_name.replace('｜', '|')
    
    # 根据sheet名称选择处理函数
    if normalized_name == "非手推GMV":
        process_non_hand_push_gmv(ws, perf_month)
        # 非手推GMV: 自动调整列宽
        auto_adjust_column_width(ws)
    elif normalized_name == "港澳商务GMV|ROI":
        process_hk_macao_gmv_roi(ws, perf_month)
    elif normalized_name == "台湾 滚转|例子到课率":
        process_taiwan_conversion(ws, perf_month)
        # 台湾报表特殊处理：过滤行
        filter_taiwan_rows(ws)
        # 台湾报表: 自动调整列宽
        auto_adjust_column_width(ws)
    elif normalized_name == "思维整体GMV":
        process_overall_gmv(ws, perf_month)
        # 思维整体GMV: 自动调整列宽
        auto_adjust_column_width(ws)
    elif normalized_name in ["一续升舱", "统合升舱", "统合早鸟"]:
        process_renewal_metrics(ws, normalized_name, perf_month)
        # 5.3 后端港澳团队指标加工 - 升舱类
        process_hk_macao_renewal_rate(ws, normalized_name, perf_month)
    elif normalized_name in ["一续结课", "统合结课"]:
        process_renewal_metrics(ws, normalized_name, perf_month)
        # 5.3 后端港澳团队指标加工 - 结课类
        process_hk_macao_renewal_rate_class_end(ws, normalized_name, perf_month)
    elif normalized_name == "续费GMV达成率":
        process_renewal_metrics(ws, normalized_name, perf_month)
        # 5.3 后端港澳团队指标加工 - 续费GMV达成率
        process_hk_macao_gmv_rate(ws, merged_path, normalized_name, perf_month)
    elif normalized_name == "后端转介绍达成":
        process_backend_conversion(ws, perf_month)
        # 5.3 后端港澳团队指标加工 - 后端转介绍达成
        process_hk_macao_conversion(ws, normalized_name, perf_month)
    
    # 隐藏不需要的列（使用原始名称查找配置），传递原始最大列数保护计算结果列
    hide_columns(ws, sheet_name, original_max_col)


def main():
    # 获取绩效月份
    perf_month_raw, perf_month_cn, start_date, end_date = parse_perf_month()
    print(f"[INFO] 绩效月份: {perf_month_raw} ({perf_month_cn})")
    
    # 查找合并后的报表文件
    try:
        merged_path = find_merged_report(perf_month_cn)
        print(f"[INFO] 找到合并后的报表: {merged_path}")
    except FileNotFoundError as e:
        print(f"[ERROR] {e}")
        return
    
    # 加载合并后的报表（不使用data_only，确保公式和值都被正确读取）
    wb = load_workbook(merged_path, data_only=False)
    
    # 处理每个sheet
    sheets_to_process = []
    for original_sheet_name in wb.sheetnames:
        # 确定目标sheet名称
        target_sheet_name = SHEET_NAME_MAP.get(original_sheet_name, original_sheet_name)
        
        # 获取sheet并处理
        ws = wb[original_sheet_name]
        process_sheet(ws, merged_path, target_sheet_name, perf_month_raw)
        
        # 如果需要重命名
        if original_sheet_name != target_sheet_name:
            ws.title = target_sheet_name
        
        sheets_to_process.append(target_sheet_name)
    
    # 保存加工后的文件
    date_tag = datetime.today().strftime("%y%m%d")
    output_path = OUTPUT_DIR / f"【{perf_month_cn}】管理者绩效明细_加工版-{date_tag}.xlsx"
    
    version = 1
    while output_path.exists():
        output_path = OUTPUT_DIR / f"【{perf_month_cn}】管理者绩效明细_加工版-{date_tag}v{version}.xlsx"
        version += 1
    
    wb.save(output_path)
    print(f"\n[INFO] 加工完成，输出文件: {output_path}")
    print(f"[INFO] 处理的Sheet: {sheets_to_process}")


if __name__ == "__main__":
    main()
