from openpyxl import load_workbook
from pathlib import Path
from datetime import datetime

# ==================== 配置参数 ====================
# 询问用户输入绩效月份
PERF_MONTH = input("请输入绩效月份(YYYY-MM): ").strip()
if not PERF_MONTH:
    PERF_MONTH = "2026-05"  # 默认值

# 根据绩效月份生成文件名
year = PERF_MONTH[:4]
month = PERF_MONTH[-2:]
month_cn = f"{int(year[-2:])}年{int(month)}月"
month_short = f"{int(year[-2:])}年{int(month)}月"

INPUT_FILE = rf'C:\Users\huangxiaoyan\Documents\trae_projects\test_week\input\【{month_short}】管理者绩效 -*.xlsx'
PROCESSED_FILE = rf'C:\Users\huangxiaoyan\Documents\trae_projects\test_week\output\【{year}年{month}月】管理者绩效明细_加工版-*.xlsx'
OUTPUT_DIR = r'C:\Users\huangxiaoyan\Documents\trae_projects\test_week\output'

# 获取当前日期作为更新日期
UPDATE_DATE = datetime.now().strftime("%Y%m%d")

# 区间配置 (从终版绩效文档G-N列读取，此处预设为标准区间)
RATE_INTERVALS = [
    {"range": (-float('inf'), 0.5), "value": 0.60},    # <50%
    {"range": (0.5, 0.65), "value": 0.70},             # 50-65%
    {"range": (0.65, 0.8), "value": 0.80},             # 65-80%
    {"range": (0.8, 0.95), "value": 0.90},             # 80-95%
    {"range": (0.95, 1.05), "value": 1.00},            # 95-105%
    {"range": (1.05, 1.1), "value": 1.05},             # 105-110%
    {"range": (1.1, 1.2), "value": 1.20},              # 110-120%
    {"range": (1.2, float('inf')), "value": 1.50},     # >120%
]

# ==================== 辅助函数 ====================
def get_output_filename(base_name, date_str):
    """生成带版本号的输出文件名"""
    output_dir = Path(OUTPUT_DIR)
    output_dir.mkdir(exist_ok=True)
    base_filename = f'{base_name}-{date_str}'
    full_path = output_dir / f'{base_filename}.xlsx'
    if not full_path.exists():
        return full_path
    version = 1
    while True:
        versioned_path = output_dir / f'{base_filename}v{version}.xlsx'
        if not versioned_path.exists():
            return versioned_path
        version += 1

def get_rate_value(score):
    """根据得分返回对应区间的绩效系数"""
    if score is None:
        return None
    for interval in RATE_INTERVALS:
        low, high = interval["range"]
        if low <= score < high:
            return interval["value"]
    return None

def find_month_col(ws, month_str, header_rows=15):
    """查找绩效月份对应的列"""
    year = month_str[:4]
    month = month_str[-2:]
    month_patterns = [
        month_str, 
        month_str.replace('-', ''), 
        f"{year}年{month}月", 
        f"{month}月",
        f"20{month}",
        f"{year}.{month}",
        month
    ]
    
    for row in range(1, header_rows + 1):
        for col in range(1, ws.max_column + 1):
            val = str(ws.cell(row=row, column=col).value or "")
            for pattern in month_patterns:
                if pattern in val:
                    return col
    return None

def convert_to_number(val):
    """将值转换为数字"""
    if val is None:
        return None
    if isinstance(val, (int, float)):
        return float(val)
    if isinstance(val, str):
        try:
            return float(val.strip().replace(',', ''))
        except ValueError:
            return None
    return None

# ==================== 数据更新函数 ====================
def update_manager_kpi(wb_out, wb_processed):
    """更新管理者绩效考核方案 sheet"""
    ws_kh = wb_out["管理者绩效考核方案"]
    
    # ========== 行10列4: 非手推GMV（新带新+前端转介绍+后端非手推） ==========
    ws_fst = wb_processed["非手推GMV"]
    month_col = find_month_col(ws_fst, PERF_MONTH)
    fst_value = None
    if month_col:
        total = 0
        for row in range(6, 25):
            b_val = str(ws_fst.cell(row=row, column=2).value or "")
            if "新带新" in b_val or "前端转介绍" in b_val or "后端非手推" in b_val:
                cell_val = ws_fst.cell(row=row, column=month_col).value
                num_val = convert_to_number(cell_val)
                if num_val is not None:
                    total += num_val
        if total > 0:
            fst_value = total
            ws_kh.cell(row=10, column=4, value=fst_value)
            print(f"✓ 行10列4 - 非手推GMV: {fst_value:,.0f}")
    
    # ========== 行11列4: 主投滚动GMV 和 行11列7: 主投滚动ROI2达成 ==========
    # 与完整流程脚本一致：遍历sheet名称，支持中英文竖线
    ws_gmv_roi = None
    for sheet_name in wb_processed.sheetnames:
        normalized = sheet_name.replace('｜', '|')
        if "港澳商务GMV|ROI" in normalized:
            ws_gmv_roi = wb_processed[sheet_name]
            break
    
    if ws_gmv_roi:
        gmv_value = None
        roi_value = None
        # 表头在第5行，查找列2="总计"的行
        for row in range(1, ws_gmv_roi.max_row + 1):
            val = str(ws_gmv_roi.cell(row=row, column=2).value or "")
            if "总计" in val:
                for col in range(1, ws_gmv_roi.max_column + 1):
                    header = str(ws_gmv_roi.cell(row=5, column=col).value or "")
                    if "主投滚动GMV" in header:
                        gmv_value = ws_gmv_roi.cell(row=row, column=col).value
                    if "主投滚动ROI2达成" in header:
                        roi_value = ws_gmv_roi.cell(row=row, column=col).value
                break
        if gmv_value:
            ws_kh.cell(row=11, column=4, value=gmv_value)
            print(f"✓ 行11列4 - 主投滚动GMV: {gmv_value:,.0f}")
        if roi_value:
            ws_kh.cell(row=11, column=7, value=roi_value)
            print(f"✓ 行11列7 - 主投滚动ROI2达成: {roi_value:.4f}")
    else:
        print("[WARN] 未找到港澳商务GMV|ROI sheet")
    
    # ========== 行23列4: 例子到课率（当月）- 从台湾sheet读取 ==========
    # 与完整流程脚本一致：遍历sheet名称，支持滚转/滚轉
    ws_tw = None
    for sheet_name in wb_processed.sheetnames:
        normalized = sheet_name.replace('｜', '|')
        if "台湾" in normalized and ("滚转" in normalized or "滚轉" in normalized):
            ws_tw = wb_processed[sheet_name]
            break
    
    dk_rate = None
    month_col_tw = None
    if ws_tw:
        month_col_tw = find_month_col(ws_tw, PERF_MONTH)
        if month_col_tw:
            # 在例子到课率（当月）表格中查找汇总行
            for row in range(180, 220):
                b_val = str(ws_tw.cell(row=row, column=2).value or "")
                if b_val == "汇总" and str(ws_tw.cell(row=row-1, column=2).value or "") == "例子到课率（当月）":
                    dk_rate = ws_tw.cell(row=row, column=month_col_tw).value
                    break
    if dk_rate:
        ws_kh.cell(row=23, column=4, value=dk_rate)
        print(f"✓ 行23列4 - 例子到课率: {dk_rate:.4f}")
    
    # ========== 行24列4: 滚动转化率 ==========
    gd_rate = None
    if ws_tw and month_col_tw:
        for row in range(70, 100):
            val = str(ws_tw.cell(row=row, column=4).value or "")
            if val == "滚动转化率":
                for r in range(row, min(row+10, ws_tw.max_row + 1)):
                    b_val = str(ws_tw.cell(row=r, column=2).value or "")
                    c_val = str(ws_tw.cell(row=r, column=3).value or "")
                    if b_val == "汇总" and c_val == "汇总":
                        gd_rate = ws_tw.cell(row=r, column=month_col_tw).value
                        break
                break
    if gd_rate:
        ws_kh.cell(row=24, column=4, value=gd_rate)
        print(f"✓ 行24列4 - 滚动转化率: {gd_rate:.6f}")
    
    # ========== 行25列4: 思维整体GMV（从思维整体GMV sheet读取） ==========
    ws_siwei = wb_processed["思维整体GMV"]
    siwei_value = None
    month_col_sw = find_month_col(ws_siwei, PERF_MONTH)
    if month_col_sw:
        for row in range(1, ws_siwei.max_row + 1):
            col2_val = str(ws_siwei.cell(row=row, column=2).value or "")
            col3_val = str(ws_siwei.cell(row=row, column=3).value or "")
            if col2_val == "汇总" and col3_val == "汇总":
                siwei_value = ws_siwei.cell(row=row, column=month_col_sw).value
                break
    if siwei_value:
        ws_kh.cell(row=25, column=4, value=siwei_value)
        print(f"✓ 行25列4 - 思维整体GMV: {siwei_value:,.0f}")

def update_col6_rates(wb_out):
    """更新管理者绩效考核方案 sheet 的列6绩效系数"""
    ws_kh = wb_out["管理者绩效考核方案"]

    def read_number(cell_ref: str):
        return convert_to_number(ws_kh[cell_ref].value)

    c52 = read_number("C52")
    c50 = read_number("C50")
    c51 = read_number("C51")
    discount = c52 if c52 is not None else ((c51 / c50) if (c50 and c51) else None)

    c10_base = read_number("N10")
    c11_base = read_number("K10")
    c25_base = read_number("K24")
    c10_formula = c10_base * discount if (c10_base is not None and discount is not None) else None
    c11_formula = c11_base * discount if (c11_base is not None and discount is not None) else None
    c25_formula = c25_base * discount if (c25_base is not None and discount is not None) else None

    d10 = read_number("D10")
    c10 = c10_formula if c10_formula is not None else read_number("C10")
    val_row4 = d10 / c10 if (d10 and c10) else None

    d11 = read_number("D11")
    c11 = c11_formula if c11_formula is not None else read_number("C11")
    g11 = read_number("G11")
    f11 = read_number("F11")
    val_row5 = (d11 / c11) * (g11 / f11) if (d11 and c11 and g11 and f11) else None

    d23 = read_number("D23")
    c23 = read_number("C23")
    val_row16 = d23 / c23 if (d23 and c23) else None

    d24 = read_number("D24")
    c24 = read_number("C24")
    val_row17 = d24 / c24 if (d24 and c24) else None

    d25 = read_number("D25")
    c25 = c25_formula if c25_formula is not None else read_number("C25")
    val_row18 = d25 / c25 if (d25 and c25) else None

    rate_row4 = get_rate_value(val_row4)
    rate_row5 = get_rate_value(val_row5)
    rate_row16 = get_rate_value(val_row16)
    rate_row17 = get_rate_value(val_row17)
    rate_row18 = get_rate_value(val_row18)

    ws_kh.cell(row=4, column=6, value=rate_row4)
    ws_kh.cell(row=5, column=6, value=rate_row5)
    ws_kh.cell(row=16, column=6, value=rate_row16)
    ws_kh.cell(row=17, column=6, value=rate_row17)
    ws_kh.cell(row=18, column=6, value=rate_row18)

    print(f"\n【绩效系数更新】")
    print(f"  行4列6 - 非手推GMV: {val_row4:.2%} → {rate_row4}" if val_row4 else f"  行4列6 - 非手推GMV: None → {rate_row4}")
    print(f"  行5列6 - 主投GMV: {val_row5:.2%} → {rate_row5}" if val_row5 else f"  行5列6 - 主投GMV: None → {rate_row5}")
    print(f"  行6列6 - 例子到课率: {val_row16:.2%} → {rate_row16}" if val_row16 else f"  行6列6 - 例子到课率: None → {rate_row16}")
    print(f"  行7列6 - 滚动转化率: {val_row17:.2%} → {rate_row17}" if val_row17 else f"  行7列6 - 滚动转化率: None → {rate_row17}")
    print(f"  行8列6 - 思维整体GMV: {val_row18:.2%} → {rate_row18}" if val_row18 else f"  行8列6 - 思维整体GMV: None → {rate_row18}")

def update_operation_director(wb_out, wb_processed):
    """更新运营总监-孙昊天 sheet"""
    ws_director = wb_out["运营总监-孙昊天"]
    
    # ========== 从二次加工好的结果中读取（各sheet最右方） ==========
    
    # 一续升舱续费率：sheet最右方，第2行，续费率列
    ws_yixu_shengcang = wb_processed["一续升舱"]
    yixu_shengcang_rate = None
    last_col = ws_yixu_shengcang.max_column
    for col in range(last_col, 0, -1):
        header_val = str(ws_yixu_shengcang.cell(row=1, column=col).value or "")
        if "续费率" in header_val:
            rate_str = str(ws_yixu_shengcang.cell(row=2, column=col).value or "")
            if "%" in rate_str:
                yixu_shengcang_rate = float(rate_str.strip("%")) / 100
            else:
                yixu_shengcang_rate = convert_to_number(ws_yixu_shengcang.cell(row=2, column=col).value)
            break
    
    # 统合早鸟续费率：sheet最右方，第2行，续费率列
    ws_tonghe_zaoniao = wb_processed["统合早鸟"]
    tonghe_zaoniao_rate = None
    last_col = ws_tonghe_zaoniao.max_column
    for col in range(last_col, 0, -1):
        header_val = str(ws_tonghe_zaoniao.cell(row=1, column=col).value or "")
        if "续费率" in header_val:
            rate_str = str(ws_tonghe_zaoniao.cell(row=2, column=col).value or "")
            if "%" in rate_str:
                tonghe_zaoniao_rate = float(rate_str.strip("%")) / 100
            else:
                tonghe_zaoniao_rate = convert_to_number(ws_tonghe_zaoniao.cell(row=2, column=col).value)
            break
    
    # 一续结课续费率：sheet最右方，第2行，续费率列
    ws_yixu_jieke = wb_processed["一续结课"]
    yixu_jieke_rate = None
    last_col = ws_yixu_jieke.max_column
    for col in range(last_col, 0, -1):
        header_val = str(ws_yixu_jieke.cell(row=1, column=col).value or "")
        if "续费率" in header_val:
            rate_str = str(ws_yixu_jieke.cell(row=2, column=col).value or "")
            if "%" in rate_str:
                yixu_jieke_rate = float(rate_str.strip("%")) / 100
            else:
                yixu_jieke_rate = convert_to_number(ws_yixu_jieke.cell(row=2, column=col).value)
            break
    
    # 统合结课续费率：sheet最右方，第2行，续费率列
    ws_tonghe_jieke = wb_processed["统合结课"]
    tonghe_jieke_rate = None
    last_col = ws_tonghe_jieke.max_column
    for col in range(last_col, 0, -1):
        header_val = str(ws_tonghe_jieke.cell(row=1, column=col).value or "")
        if "续费率" in header_val:
            rate_str = str(ws_tonghe_jieke.cell(row=2, column=col).value or "")
            if "%" in rate_str:
                tonghe_jieke_rate = float(rate_str.strip("%")) / 100
            else:
                tonghe_jieke_rate = convert_to_number(ws_tonghe_jieke.cell(row=2, column=col).value)
            break
    
    # 续费GMV达成率：从sheet最右方查找港澳益智教学服务区对应的达成率值（二次加工结果）
    # 港澳益智教学服务区的汇总在第2行，第56列是标签'港澳益智教学服务区'，第57列是值'113.12%'
    ws_xufei_gmv = wb_processed["续费GMV达成率"]
    xufei_gmv_rate = None
    last_col = ws_xufei_gmv.max_column
    for col in range(last_col, 0, -1):
        val = str(ws_xufei_gmv.cell(row=2, column=col).value or "")
        if "港澳益智教学服务区" in val:
            rate_val = ws_xufei_gmv.cell(row=2, column=col + 1).value
            if rate_val:
                rate_str = str(rate_val)
                if "%" in rate_str:
                    xufei_gmv_rate = float(rate_str.strip("%")) / 100
                else:
                    xufei_gmv_rate = convert_to_number(rate_val)
            break
    
    # 转介绍综合达成率：sheet最右方，第2行，转介绍综合达成率列
    ws_zhuanjieshao = wb_processed["后端转介绍达成"]
    zhuanjieshao_rate = None
    last_col = ws_zhuanjieshao.max_column
    for col in range(last_col, 0, -1):
        header_val = str(ws_zhuanjieshao.cell(row=1, column=col).value or "")
        if "转介绍综合达成率" in header_val:
            rate_str = str(ws_zhuanjieshao.cell(row=2, column=col).value or "")
            if "%" in rate_str:
                zhuanjieshao_rate = float(rate_str.strip("%")) / 100
            else:
                zhuanjieshao_rate = convert_to_number(ws_zhuanjieshao.cell(row=2, column=col).value)
            break
    
    # ========== 更新运营总监sheet（列8是指标达成列） ==========
    ws_director.cell(row=4, column=8, value=yixu_shengcang_rate)
    ws_director.cell(row=5, column=8, value=tonghe_zaoniao_rate)
    ws_director.cell(row=6, column=8, value=yixu_jieke_rate)
    ws_director.cell(row=7, column=8, value=tonghe_jieke_rate)
    ws_director.cell(row=8, column=8, value=xufei_gmv_rate)
    ws_director.cell(row=9, column=8, value=zhuanjieshao_rate)
    
    # 设置百分比格式（保留两位小数）
    for row in range(4, 10):
        ws_director.cell(row=row, column=8).number_format = '0.00%'
    
    print(f"\n【运营总监-孙昊天更新】")
    print(f"  行4列8 - 一续升舱续费率: {yixu_shengcang_rate:.2%}" if yixu_shengcang_rate else "  行4列8 - 一续升舱续费率: None")
    print(f"  行5列8 - 统合早鸟续费率: {tonghe_zaoniao_rate:.2%}" if tonghe_zaoniao_rate else "  行5列8 - 统合早鸟续费率: None")
    print(f"  行6列8 - 一续结课续费率: {yixu_jieke_rate:.2%}" if yixu_jieke_rate else "  行6列8 - 一续结课续费率: None")
    print(f"  行7列8 - 统合结课续费率: {tonghe_jieke_rate:.2%}" if tonghe_jieke_rate else "  行7列8 - 统合结课续费率: None")
    print(f"  行8列8 - 续费GMV达成率: {xufei_gmv_rate:.2%}" if xufei_gmv_rate else "  行8列8 - 续费GMV达成率: None")
    print(f"  行9列8 - 转介绍综合达成率: {zhuanjieshao_rate:.2%}" if zhuanjieshao_rate else "  行9列8 - 转介绍综合达成率: None")

# ==================== 辅助函数 ====================
def find_matching_file(pattern):
    """查找匹配通配符模式的文件"""
    import glob
    files = glob.glob(pattern)
    if files:
        # 返回最新的文件
        return max(files, key=lambda x: Path(x).stat().st_mtime)
    return None

# ==================== 主函数 ====================
def main():
    print("=" * 70)
    print("管理者绩效考核方案更新脚本 v1.0")
    print("=" * 70)
    print(f"绩效月份: {PERF_MONTH}")
    print(f"更新日期: {UPDATE_DATE}")
    print("-" * 70)
    
    # 查找输入文件
    print("\n[步骤1] 查找输入文件...")
    input_file = find_matching_file(INPUT_FILE)
    if not input_file:
        print(f"[ERROR] 未找到输入文件: {INPUT_FILE}")
        return
    print(f"  找到: {input_file}")
    wb_out = load_workbook(input_file)
    
    # 查找加工版文件
    print("\n[步骤2] 查找加工版文件...")
    processed_file = find_matching_file(PROCESSED_FILE)
    if not processed_file:
        print(f"[ERROR] 未找到加工版文件: {PROCESSED_FILE}")
        return
    print(f"  找到: {processed_file}")
    wb_processed = load_workbook(processed_file, data_only=True)
    
    # 更新管理者绩效考核方案
    print("\n[步骤3] 更新管理者绩效考核方案 sheet...")
    update_manager_kpi(wb_out, wb_processed)
    
    # 更新列6绩效系数
    print("\n[步骤4] 更新绩效系数...")
    update_col6_rates(wb_out)
    
    # 更新运营总监-孙昊天
    print("\n[步骤5] 更新运营总监-孙昊天 sheet...")
    update_operation_director(wb_out, wb_processed)
    
    # 保存输出文件
    print("\n[步骤6] 保存输出文件...")
    output_file = get_output_filename(f"【{month_short}】管理者绩效", UPDATE_DATE)
    wb_out.save(output_file)
    
    print("\n" + "=" * 70)
    print(f"✅ 更新完成！")
    print(f"输出文件: {output_file}")
    print("=" * 70)

if __name__ == "__main__":
    main()