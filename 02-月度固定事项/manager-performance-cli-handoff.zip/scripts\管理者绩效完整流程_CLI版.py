"""
管理者绩效完整流程脚本
========================
从BI导出报表 → 生成管理者绩效明细加工版 → 更新终版绩效文档

流程：
1. BI登录并导出11张报表
2. 合并报表生成管理者绩效明细_加工版（包含二次加工）
3. 从加工版读取数据更新到终版绩效文档

使用方式：
    python 管理者绩效完整流程.py
"""
import asyncio
import calendar
import datetime
import glob
import json
import os
import subprocess
import re
import sys
import tempfile
from copy import copy
from pathlib import Path
from getpass import getpass

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Font, PatternFill, Border, Side, Alignment
from openpyxl.utils import get_column_letter
from playwright.async_api import async_playwright

SMARTBI_CLI_SCRIPT = Path(r"C:\Users\huangxiaoyan\Documents\Codex\smartBICLI_code_only_20260603_104613\smartBICLI\active\python-cli\scripts\smartbi_cli.py")

# ==================== 路径配置 ====================
BASE_DIR = Path(__file__).resolve().parent
DOWNLOAD_DIR = BASE_DIR / "downloads"
OUTPUT_DIR = BASE_DIR / "output"
INPUT_DIR = BASE_DIR / "input"
DOWNLOAD_DIR.mkdir(parents=True, exist_ok=True)
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
INPUT_DIR.mkdir(parents=True, exist_ok=True)

# ==================== 报表配置清单 ====================
REPORTS = [
    {"name": "AI-海外转介绍业绩达成_月趋势", "url": "https://bi.61info.cn/smartbi/vision/openresource.jsp?resid=I2c928087019e186e186e355a019e3a1373905f08", "mode": "no_filters", "merge": {"source_sheet": "思维", "target_sheet": "非手推GMV"}},
    {"name": "港澳商务-链路达成数据", "url": "https://bi.61info.cn/smartbi/vision/openresource.jsp?resid=I2c928087019e3c7a3c7aba9e019e4a021d3c753b", "mode": "date_only", "merge": {"source_sheet": "Sheet1", "target_sheet": "港澳商务GMV｜ROI"}},
    {"name": "AI-海外漏斗达成情况-月趋势-台湾", "url": "https://bi.61info.cn/smartbi/vision/openresource.jsp?resid=I2c928087019e3c7a3c7aba9e019e4a40141e4c03", "mode": "no_filters", "merge": {"source_sheet": "思维", "target_sheet": "台湾 滚转｜例子到课率"}},
    {"name": "AI-海外漏斗达成情况-月趋势-整体", "url": "https://bi.61info.cn/smartbi/vision/openresource.jsp?resid=I2c928087019e186e186e355a019e1f2b6636131d", "mode": "no_filters", "merge": {"source_sheet": "思维", "target_sheet": "思维整体GMV"}},
    {"name": "一续-升舱期-分课包续费率", "url": "https://bi.61info.cn/smartbi/vision/openresource.jsp?resid=I2c928087019b47734773e654019b49cadf583c27", "mode": "date_and_refund", "merge": {"source_sheet": "Sheet1", "target_sheet": "一续升舱"}},
    {"name": "统合-升舱期-分课包续费率", "url": "https://bi.61info.cn/smartbi/vision/openresource.jsp?resid=I2c928087019b8f918f91e2fa019b9cff6d373f6f", "mode": "date_and_refund", "merge": {"source_sheet": "Sheet1", "target_sheet": "统合升舱"}},
    {"name": "统合早鸟期-分课包续费率", "url": "https://bi.61info.cn/smartbi/vision/openresource.jsp?resid=I2c928087019b47734773e654019b4a3a61a6355e", "mode": "date_and_refund", "merge": {"source_sheet": "Sheet1", "target_sheet": "统合早鸟"}},
    {"name": "近三月结课续费率-一续", "url": "https://bi.61info.cn/smartbi/vision/openresource.jsp?resid=I2c9280870193d0dcd0dc8f480193ed733b606832", "mode": "date_and_refund", "merge": {"source_sheet": "Sheet1", "target_sheet": "一续结课"}},
    {"name": "近三月结课续费率-统合", "url": "https://bi.61info.cn/smartbi/vision/openresource.jsp?resid=I2c9280870193d0dcd0dc8f480193ed733b606832", "mode": "date_refund_and_pools", "pools": ["一续池", "二续池", "三续池", "四续池", "五续池", "六续池"], "merge": {"source_sheet": "Sheet1", "target_sheet": "统合结课"}},
    {"name": "海外思维续费播报", "url": "https://bi.61info.cn/smartbi/vision/openresource.jsp?resid=I2c9280870193f66cf66ccfe50193f6b40bc66a32", "mode": "date_and_refund", "merge": {"source_sheet": "Sheet1", "target_sheet": "续费GMV达成率"}},
    {"name": "转介绍益智业绩播报_LP维度_末次渠道", "url": "https://bi.61info.cn/smartbi/vision/openresource.jsp?resid=I2c928087019033b933b9918901905286967a0d71", "mode": "date_single", "merge": {"source_sheet": "Sheet1", "target_sheet": "后端转介绍达成"}},
]


def slugify_task_name(value: str) -> str:
    slug = re.sub(r"[^0-9A-Za-z_]+", "_", value).strip("_").lower()
    return slug or "smartbi_report"


def cli_output_dir(task_name: str) -> Path:
    return DOWNLOAD_DIR / "cli_exports" / task_name / "{run_date}" / "{run_id}"


def run_smartbi_cli(args: list[str]) -> dict:
    if not SMARTBI_CLI_SCRIPT.exists():
        raise FileNotFoundError(f"未找到 SmartBI CLI: {SMARTBI_CLI_SCRIPT}")

    cmd = [sys.executable, str(SMARTBI_CLI_SCRIPT), *args, "--json"]
    env = os.environ.copy()
    env["PYTHONIOENCODING"] = "utf-8"
    completed = subprocess.run(
        cmd,
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        env=env,
    )
    stdout = (completed.stdout or "").strip()
    stderr = (completed.stderr or "").strip()
    if completed.returncode != 0:
        raise RuntimeError(
            f"SmartBI CLI 执行失败: {' '.join(cmd)}\nstdout:\n{stdout}\nstderr:\n{stderr}"
        )
    if not stdout:
        raise RuntimeError(f"SmartBI CLI 未返回 JSON: {' '.join(cmd)}")
    return json.loads(stdout)


def get_report_id(report: dict) -> str:
    url = report["url"]
    if "resid=" not in url:
        raise RuntimeError(f"报表链接缺少 resid: {url}")
    return url.split("resid=", 1)[1]


def parameter_matches(param: dict, candidate: str) -> bool:
    values = [
        str(param.get("id") or ""),
        str(param.get("name") or ""),
        str(param.get("alias") or ""),
        str(param.get("key") or ""),
    ]
    candidate = candidate.strip()
    if not candidate:
        return False
    lowered = candidate.lower()
    for value in values:
        if not value:
            continue
        if candidate == value:
            return True
        if lowered in value.lower() or value.lower() in lowered:
            return True
    return False


def resolve_cli_param_key(parameters: list[dict], candidates: list[str], fallback: str) -> str:
    for candidate in candidates:
        for param in parameters:
            if parameter_matches(param, candidate):
                return str(param.get("alias") or param.get("name") or param.get("id") or candidate)
    return fallback


def find_param_by_candidates(parameters: list[dict], candidates: list[str]) -> dict | None:
    for candidate in candidates:
        for param in parameters:
            if parameter_matches(param, candidate):
                return param
    return None


POOL_VALUE_MAP = {
    "一续池": "1",
    "二续池": "2",
    "三续池": "3",
    "四续池": "4",
    "五续池": "5",
    "六续池": "6",
}


def normalize_pool_values(pools: list[str]) -> tuple[str, str]:
    labels: list[str] = []
    values: list[str] = []
    for item in pools:
        clean = str(item).strip()
        if not clean:
            continue
        labels.append(clean)
        values.append(POOL_VALUE_MAP.get(clean, clean))
    return ",".join(values), ",".join(labels)


def build_cli_task(report: dict, start_date: str, end_date: str) -> tuple[str, dict, Path]:
    task_name = slugify_task_name(report["name"])
    report_id = get_report_id(report)
    inspect_result = run_smartbi_cli(
        [
            "inspect-report",
            "--username",
            os.environ["SMARTBI_USERNAME"],
            "--password",
            os.environ["SMARTBI_PASSWORD"],
            "--report-id",
            report_id,
            "--report-path",
            report["url"].split("openresource.jsp?", 1)[-1],
        ]
    )
    parameters = inspect_result.get("parameters") or []
    if not isinstance(parameters, list):
        parameters = []

    out_dir = cli_output_dir(task_name)
    mode = report.get("mode")
    overrides: list[dict[str, str]] = []
    if mode == "date_only":
        overrides = [
            {
                "key": resolve_cli_param_key(parameters, ["开始日期", "开始日"], "开始日期"),
                "value": start_date,
                "displayValue": start_date,
            },
            {
                "key": resolve_cli_param_key(parameters, ["快照日期", "结束日期", "结束日"], "快照日期"),
                "value": end_date,
                "displayValue": end_date,
            },
        ]
    elif mode == "date_and_refund":
        overrides = [
            {
                "key": resolve_cli_param_key(parameters, ["日期", "开始日期", "开始月份"], "日期"),
                "value": end_date,
                "displayValue": end_date,
            },
            {
                "key": resolve_cli_param_key(parameters, ["退费结束时间", "退款结束时间", "结束日期", "结束月份"], "退费结束时间"),
                "value": start_date,
                "displayValue": start_date,
            },
        ]
    elif mode == "date_refund_and_pools":
        pool_param = find_param_by_candidates(parameters, ["思维续费池", "续费池", "pools"])
        pool_values, pool_labels = normalize_pool_values(report.get("pools") or [])
        pool_key = str(pool_param.get("alias") or pool_param.get("name") or pool_param.get("id")) if pool_param else "思维续费池"
        overrides = [
            {
                "key": resolve_cli_param_key(parameters, ["日期", "开始日期", "开始月份"], "日期"),
                "value": end_date,
                "displayValue": end_date,
            },
            {
                "key": resolve_cli_param_key(parameters, ["退费结束时间", "退款结束时间", "结束日期", "结束月份"], "退费结束时间"),
                "value": start_date,
                "displayValue": start_date,
            },
            {"key": pool_key, "value": pool_values, "displayValue": pool_labels},
        ]
    elif mode == "date_single":
        overrides = [
            {
                "key": resolve_cli_param_key(parameters, ["q_date_-15min", "日期", "结束日期", "结束月份"], "q_date_-15min"),
                "value": end_date,
                "displayValue": end_date,
            },
        ]

    task = {
        "version": 1,
        "base_url": "https://bi.61info.cn/smartbi/vision",
        "tasks": {
            task_name: {
                "enabled": True,
                "description": f"{report['name']} CLI 导出任务",
                "report": {
                    "id": report_id,
                    "path": "",
                    "type": "SPREADSHEET_REPORT",
                },
                "filters": {
                    "overrides": overrides,
                },
                "output": {
                    "type": "file",
                    "dir": str(out_dir),
                },
            }
        },
    }
    return task_name, task, out_dir


def run_cli_export(report: dict, perf_month_raw: str, start_date: str, end_date: str) -> Path:
    task_name, task, _ = build_cli_task(report, start_date, end_date)
    with tempfile.TemporaryDirectory(prefix=f"smartbi_{task_name}_", dir=str(DOWNLOAD_DIR)) as tmp_dir:
        config_path = Path(tmp_dir) / "smartbi_tasks.json"
        config_path.write_text(json.dumps(task, ensure_ascii=False, indent=2), encoding="utf-8")
        print(f"\n[CLI] 预演导出: {report['name']}（{perf_month_raw}）")
        dry_run = run_smartbi_cli([
            "run",
            "--config",
            str(config_path),
            "--task",
            task_name,
            "--dry-run",
            "--username",
            os.environ["SMARTBI_USERNAME"],
            "--password",
            os.environ["SMARTBI_PASSWORD"],
        ])
        print(f"[CLI] dry-run 完成: {dry_run.get('status', 'unknown')}")
        result = run_smartbi_cli([
            "run",
            "--config",
            str(config_path),
            "--task",
            task_name,
            "--username",
            os.environ["SMARTBI_USERNAME"],
            "--password",
            os.environ["SMARTBI_PASSWORD"],
        ])
        output = result.get("output")
        if not isinstance(output, str) or not output:
            raise RuntimeError(f"CLI 未返回导出文件路径: {result}")
        path = Path(output)
        if not path.exists():
            raise RuntimeError(f"CLI 返回的导出文件不存在: {path}")
        print(f"[SUCCESS] CLI 导出完成: {path.name}")
        return path


def find_latest_cli_export(report: dict) -> Path | None:
    task_name = slugify_task_name(report["name"])
    cli_root = DOWNLOAD_DIR / "cli_exports" / task_name
    if not cli_root.exists():
        return None
    candidates = [path for path in cli_root.rglob("*.xlsx") if path.is_file()]
    if not candidates:
        return None
    candidates.sort(key=lambda path: path.stat().st_mtime, reverse=True)
    return candidates[0]


def find_cli_export_by_run_json(report: dict) -> Path | None:
    report_id = get_report_id(report)
    task_name = slugify_task_name(report["name"])
    cli_root = DOWNLOAD_DIR / "cli_exports" / task_name
    if not cli_root.exists():
        return None
    run_logs = sorted((path for path in cli_root.rglob("run.json") if path.is_file()), key=lambda path: path.stat().st_mtime, reverse=True)
    for run_log in run_logs:
        try:
            payload = json.loads(run_log.read_text(encoding="utf-8"))
        except Exception:
            continue
        if str(payload.get("report_id") or "") != report_id:
            continue
        output = payload.get("output")
        if isinstance(output, str) and output and Path(output).exists():
            return Path(output)
        default_filename = payload.get("default_filename")
        if isinstance(default_filename, str) and default_filename:
            candidate = run_log.parent / default_filename
            if candidate.exists():
                return candidate
    return None


def resolve_report_input_path(report: dict) -> Path | None:
    path = find_cli_export_by_run_json(report)
    if path is not None:
        return path
    path = find_latest_cli_export(report)
    if path is not None:
        return path
    pattern = str(DOWNLOAD_DIR / f"{report['name']}_*.xlsx")
    files = glob.glob(pattern)
    if not files:
        return None
    files.sort(key=lambda x: os.path.getmtime(x), reverse=True)
    return Path(files[0])

# ==================== 绩效更新配置 ====================
RATE_INTERVALS = [
    {"range": (-float('inf'), 0.5), "value": 0.60},
    {"range": (0.5, 0.65), "value": 0.70},
    {"range": (0.65, 0.8), "value": 0.80},
    {"range": (0.8, 0.95), "value": 0.90},
    {"range": (0.95, 1.05), "value": 1.00},
    {"range": (1.05, 1.1), "value": 1.05},
    {"range": (1.1, 1.2), "value": 1.20},
    {"range": (1.2, float('inf')), "value": 1.50},
]

# ==================== 二次加工配置 ====================
# 样式定义
RED_BOLD_FONT = Font(bold=True, color="FF0000")  # 红色加粗
YELLOW_FILL = PatternFill(start_color="FFFFFF00", end_color="FFFFFF00", fill_type="solid")  # 黄色高亮
THIN_BORDER = Border(left=Side(style='thin'),
                     right=Side(style='thin'),
                     top=Side(style='thin'),
                     bottom=Side(style='thin'))
MS_YAHEI_FONT = Font(name='微软雅黑', size=11)  # 微软雅黑字体
MS_YAHEI_BOLD_FONT = Font(name='微软雅黑', bold=True, color="FF0000", size=11)  # 微软雅黑红色加粗

# 各报表的保留列配置
KEEP_COLUMNS_CONFIG = {
    "非手推GMV": [],
    "港澳商务GMV|ROI": ["A-E", "DJ", "DK", "ED"],
    "台湾 滚转|例子到课率": [],
    "思维整体GMV": ["A-C", "E-Z"],
    "一续升舱": ["A-K"],
    "统合升舱": ["A-K"],
    "统合早鸟": ["A-K"],
    "一续结课": ["A-M"],
    "统合结课": ["A-M"],
    "续费GMV达成率": ["A-U"],
    "后端转介绍达成": ["A-E", "M-U", "AJ-AL"],
}

# ==================== 辅助函数 ====================
def get_rate_value(score):
    if score is None:
        return None
    for interval in RATE_INTERVALS:
        low, high = interval["range"]
        if low <= score < high:
            return interval["value"]
    return None

def find_month_col(ws, month_str, header_rows=15, start_row=1):
    year = month_str[:4]
    month = month_str[-2:]
    month_patterns = [month_str, month_str.replace('-', ''), f"{year}年{month}月", f"{month}月", f"20{month}", f"{year}.{month}", month]
    end_row = start_row + header_rows - 1
    for row in range(start_row, end_row + 1):
        for col in range(1, ws.max_column + 1):
            val = str(ws.cell(row=row, column=col).value or "")
            for pattern in month_patterns:
                if pattern in val:
                    return col
    return None

def convert_to_number(val):
    if val is None:
        return None
    if isinstance(val, (int, float)):
        return float(val)
    if isinstance(val, str):
        try:
            return float(val.strip().replace(',', ''))
        except ValueError:
            return None
    return None

def get_output_filename(base_name, date_str):
    output_dir = OUTPUT_DIR
    output_dir.mkdir(exist_ok=True)
    base_filename = f'{base_name}-{date_str}'
    full_path = output_dir / f'{base_filename}.xlsx'
    if not full_path.exists():
        return full_path
    version = 1
    while True:
        versioned_path = output_dir / f'{base_filename}v{version}.xlsx'
        if not versioned_path.exists():
            return versioned_path
        version += 1

def sanitize_sheet_title(title):
    safe = title.replace("|", "｜")
    safe = re.sub(r"[:\\/?*\[\]]", "_", safe)
    return safe[:31]

def copy_sheet_with_style(src_path, src_sheet_name, dst_wb, dst_sheet_name):
    src_wb = load_workbook(src_path, data_only=False)
    if src_sheet_name not in src_wb.sheetnames:
        for name in src_wb.sheetnames:
            if src_sheet_name.lower() in name.lower():
                src_sheet_name = name
                break
    src_ws = src_wb[src_sheet_name]
    
    title = sanitize_sheet_title(dst_sheet_name)
    if title in dst_wb.sheetnames:
        i = 1
        base = title
        while f"{base}_{i}" in dst_wb.sheetnames:
            i += 1
        title = f"{base}_{i}"[:31]
    
    dst_ws = dst_wb.create_sheet(title=title)
    
    for r in range(1, src_ws.max_row + 1):
        for c in range(1, src_ws.max_column + 1):
            s = src_ws.cell(r, c)
            d = dst_ws.cell(r, c)
            d.value = s.value
            if s.has_style:
                d.font = copy(s.font)
                d.fill = copy(s.fill)
                d.border = copy(s.border)
                d.alignment = copy(s.alignment)
                d.number_format = s.number_format
                d.protection = copy(s.protection)
            if s.comment:
                d.comment = copy(s.comment)
            if s.hyperlink:
                d._hyperlink = copy(s.hyperlink)
    
    # 复制合并单元格
    for merged in src_ws.merged_cells.ranges:
        dst_ws.merge_cells(str(merged))
    
    for ridx, rdim in src_ws.row_dimensions.items():
        dst_ws.row_dimensions[ridx].height = rdim.height
        dst_ws.row_dimensions[ridx].hidden = rdim.hidden
        dst_ws.row_dimensions[ridx].outlineLevel = rdim.outlineLevel
    
    for ckey, cdim in src_ws.column_dimensions.items():
        dst = dst_ws.column_dimensions[ckey]
        dst.width = cdim.width
        dst.hidden = cdim.hidden
        dst.outlineLevel = cdim.outlineLevel
        dst.bestFit = cdim.bestFit
    
    dst_ws.freeze_panes = src_ws.freeze_panes
    try:
        dst_ws.sheet_view.showGridLines = src_ws.sheet_view.showGridLines
        dst_ws.sheet_view.zoomScale = src_ws.sheet_view.zoomScale
        dst_ws.sheet_view.zoomScaleNormal = src_ws.sheet_view.zoomScaleNormal
        dst_ws.sheet_view.zoomScalePageLayoutView = src_ws.sheet_view.zoomScalePageLayoutView
        dst_ws.sheet_view.zoomScaleSheetLayoutView = src_ws.sheet_view.zoomScaleSheetLayoutView
        dst_ws.sheet_view.tabSelected = src_ws.sheet_view.tabSelected
        dst_ws.sheet_view.topLeftCell = src_ws.sheet_view.topLeftCell
        dst_ws.sheet_view.view = src_ws.sheet_view.view
    except Exception:
        pass
    dst_ws.page_margins = copy(src_ws.page_margins)
    dst_ws.page_setup = copy(src_ws.page_setup)
    dst_ws.print_options = copy(src_ws.print_options)
    try:
        dst_ws.sheet_properties = copy(src_ws.sheet_properties)
    except AttributeError:
        pass
    dst_ws.print_title_cols = src_ws.print_title_cols
    dst_ws.print_title_rows = src_ws.print_title_rows
    if src_ws.auto_filter and src_ws.auto_filter.ref:
        dst_ws.auto_filter.ref = src_ws.auto_filter.ref

def make_export_target(report_name):
    date_tag = datetime.date.today().strftime("%y%m%d")
    base = DOWNLOAD_DIR / f"{report_name}_{date_tag}.xlsx"
    if not base.exists():
        return base
    i = 1
    while True:
        p = DOWNLOAD_DIR / f"{report_name}_{date_tag}v{i}.xlsx"
        if not p.exists():
            return p
        i += 1

def make_final_output_path(perf_month):
    date_tag = datetime.date.today().strftime("%y%m%d")
    base = OUTPUT_DIR / f"【{perf_month}】管理者绩效明细_加工版-{date_tag}.xlsx"
    if not base.exists():
        return base
    i = 1
    while True:
        p = OUTPUT_DIR / f"【{perf_month}】管理者绩效明细_加工版-{date_tag}v{i}.xlsx"
        if not p.exists():
            return p
        i += 1

def all_frames(page):
    frames = [page.main_frame]
    for f in page.frames:
        if f not in frames:
            frames.append(f)
    return frames

# ==================== 二次加工辅助函数 ====================
def column_letter_to_num(col_letter):
    """将列字母转换为数字"""
    col_letter = col_letter.upper()
    num = 0
    for char in col_letter:
        num = num * 26 + (ord(char) - ord('A') + 1)
    return num

def parse_column_range(range_str):
    """解析列范围字符串，返回列字母集合"""
    result = set()
    if '-' in range_str:
        start, end = range_str.split('-')
        start_num = column_letter_to_num(start)
        end_num = column_letter_to_num(end)
        for i in range(start_num, end_num + 1):
            result.add(get_column_letter(i))
    else:
        result.add(range_str.upper())
    return result

def mark_cell(ws, row: int, col: int):
    """标记指标单元格：红色加粗"""
    cell = ws.cell(row=row, column=col)
    cell.font = RED_BOLD_FONT

def highlight_row(ws, row: int):
    """整行黄色高亮"""
    yellow_fill_copy = copy(YELLOW_FILL)
    
    for col in range(1, ws.max_column + 1):
        cell = ws.cell(row=row, column=col)
        cell.fill = yellow_fill_copy
    
    for col_letter in ws.column_dimensions:
        col_num = column_letter_to_num(col_letter)
        if col_num <= ws.max_column:
            cell = ws.cell(row=row, column=col_num)
            cell.fill = copy(YELLOW_FILL)

def column_letter_to_num(col_letter):
    """将列字母转换为数字（支持双字母列如AA、AB等）"""
    col_letter = col_letter.upper()
    num = 0
    for char in col_letter:
        num = num * 26 + (ord(char) - ord('A') + 1)
    return num

def auto_adjust_column_width(ws):
    """自动调整列宽以适应内容"""
    from openpyxl.utils import get_column_letter
    
    for col in range(1, ws.max_column + 1):
        max_length = 0
        col_letter = get_column_letter(col)
        has_number = False
        
        for row in range(1, ws.max_row + 1):
            cell = ws.cell(row=row, column=col)
            cell_value = str(cell.value) if cell.value else ""
            if any(char.isdigit() for char in cell_value):
                has_number = True
            length = sum(1 if '\u4e00' <= char <= '\u9fff' else 0.5 for char in cell_value)
            max_length = max(max_length, length)
        
        min_width = 14 if has_number else 8
        if max_length > 0:
            ws.column_dimensions[col_letter].width = max(min_width, min(max_length + 2, 50))
        else:
            ws.column_dimensions[col_letter].width = min_width

def hide_columns(ws, sheet_name: str):
    """根据配置隐藏列（保留指定列）"""
    keep_columns = KEEP_COLUMNS_CONFIG.get(sheet_name, [])
    if not keep_columns:
        normalized_name = sheet_name.replace('｜', '|')
        keep_columns = KEEP_COLUMNS_CONFIG.get(normalized_name, [])
    
    if not keep_columns:
        return
    
    keep_set = set()
    for col_spec in keep_columns:
        keep_set.update(parse_column_range(col_spec))
    
    max_col_num = ws.max_column
    for col_num in range(1, max_col_num + 1):
        col_letter = get_column_letter(col_num)
        if col_letter not in keep_set:
            ws.column_dimensions[col_letter].hidden = True

def filter_taiwan_rows(ws):
    """台湾报表行过滤：保留1-6行及滚动转化率、例子到课率表格"""
    keep_rows = set(range(1, 7))
    in_scroll_table = False
    in_attendance_table = False
    
    for row in range(1, ws.max_row + 1):
        b_value = str(ws.cell(row=row, column=2).value or "")
        d_value = str(ws.cell(row=row, column=4).value or "")
        
        if "滚动转化率" in d_value:
            in_scroll_table = True
            in_attendance_table = False
        elif "例子到课率" in d_value and "当月" in d_value:
            in_scroll_table = False
            in_attendance_table = True
        elif in_scroll_table and "例子到课率" in d_value:
            in_scroll_table = False
        
        if in_scroll_table or in_attendance_table:
            keep_rows.add(row)
        
        if "滚动转化率" in b_value or ("例子到课率" in b_value and "当月" in b_value):
            keep_rows.add(row)
    
    for row in range(1, ws.max_row + 1):
        if row not in keep_rows:
            ws.row_dimensions[row].hidden = True

def process_non_hand_push_gmv(ws, perf_month: str):
    """4.1 非手推GMV"""
    print("  [加工] 非手推GMV")
    
    table_start = None
    for row in range(1, ws.max_row + 1):
        cell_value = str(ws.cell(row=row, column=2).value or "")
        if "滚动GMV" in cell_value:
            table_start = row
            break
    
    if not table_start:
        print("    [WARN] 未找到'滚动GMV'表格")
        return
    
    perf_month_col = None
    for col in range(1, ws.max_column + 1):
        header_value = str(ws.cell(row=table_start, column=col).value or "")
        if perf_month in header_value:
            perf_month_col = col
            break
    
    if not perf_month_col:
        print(f"    [WARN] 未找到绩效月份 '{perf_month}' 对应的列")
        return
    
    target_row = None
    for row in range(table_start, min(table_start + 50, ws.max_row + 1)):
        cell_value = str(ws.cell(row=row, column=2).value or "")
        if "非手推" in cell_value:
            target_row = row
            break
    
    if not target_row:
        print("    [WARN] 未找到'非手推'所在行")
        return
    
    mark_cell(ws, target_row, perf_month_col)
    highlight_row(ws, target_row)
    print(f"    [DEBUG] 非手推GMV: 行={target_row}, 绩效月份列={perf_month_col}")

def process_hk_macao_gmv_roi(ws, perf_month: str):
    """4.2 港澳商务GMV|ROI"""
    print("  [加工] 港澳商务GMV|ROI")
    
    header_row = 5
    main_subject_col = None
    gmv_col = None
    roi_col = None
    
    for col in range(1, ws.max_column + 1):
        cell_value = str(ws.cell(row=header_row, column=col).value or "")
        if "主投" in cell_value and "滚动" not in cell_value and main_subject_col is None:
            main_subject_col = col
        if "主投滚动GMV" in cell_value:
            gmv_col = col
        if "主投滚动ROI" in cell_value:
            roi_col = col
    
    if not main_subject_col:
        print("    [WARN] 未找到'主投'列")
        return
    if not gmv_col:
        print("    [WARN] 未找到'主投滚动GMV'列")
        return
    if not roi_col:
        print("    [WARN] 未找到'主投滚动ROI'列")
        return
    
    target_row = None
    for row in range(header_row + 1, ws.max_row + 1):
        cell_value = str(ws.cell(row=row, column=main_subject_col).value or "")
        if "总计" in cell_value:
            target_row = row
            break
    
    if not target_row:
        print("    [WARN] 未找到【主投】='总计'所在行")
        return
    
    mark_cell(ws, target_row, gmv_col)
    mark_cell(ws, target_row, roi_col)
    highlight_row(ws, target_row)
    print(f"    [DEBUG] 港澳商务GMV|ROI: 行={target_row}, GMV列={gmv_col}, ROI列={roi_col}")

def process_taiwan_conversion(ws, perf_month: str):
    """4.3 台湾 滚转|例子到课率"""
    print("  [加工] 台湾滚转|例子到课率")
    
    table_start = None
    for row in range(1, ws.max_row + 1):
        cell_value = str(ws.cell(row=row, column=2).value or "")
        if "滚动转化率" in cell_value:
            table_start = row
            break
    
    if table_start:
        perf_month_col = None
        for col in range(1, ws.max_column + 1):
            header_value = str(ws.cell(row=table_start, column=col).value or "")
            if perf_month in header_value:
                perf_month_col = col
                break
        
        if perf_month_col:
            for row in range(table_start, min(table_start + 30, ws.max_row + 1)):
                col2_value = str(ws.cell(row=row, column=2).value or "")
                if "汇总" in col2_value:
                    mark_cell(ws, row, perf_month_col)
                    highlight_row(ws, row)
                    print(f"    [DEBUG] 滚动转化率汇总: 行={row}, 绩效月份列={perf_month_col}")
                    break
    
    table_start = None
    for row in range(1, ws.max_row + 1):
        cell_value = str(ws.cell(row=row, column=2).value or "")
        if "例子到课率" in cell_value and "当月" in cell_value:
            table_start = row
            break
    
    if table_start:
        perf_month_col = None
        for col in range(1, ws.max_column + 1):
            header_value = str(ws.cell(row=table_start, column=col).value or "")
            if perf_month in header_value:
                perf_month_col = col
                break
        
        if perf_month_col:
            search_end = min(table_start + 50, ws.max_row + 1)
            target_row = None
            for row in range(table_start, search_end):
                col2_value = str(ws.cell(row=row, column=2).value or "")
                if "汇总" in col2_value:
                    target_row = row
                    break
            
            if target_row:
                mark_cell(ws, target_row, perf_month_col)
                highlight_row(ws, target_row)
                print(f"    [DEBUG] 例子到课率汇总: 行={target_row}, 绩效月份列={perf_month_col}")
            else:
                print(f"    [WARN] 例子到课率（当月）未找到汇总行")

def process_overall_gmv(ws, perf_month: str):
    """4.4 思维整体GMV"""
    print("  [加工] 思维整体GMV")
    
    table_start = None
    for row in range(1, ws.max_row + 1):
        cell_value = str(ws.cell(row=row, column=2).value or "")
        if "滚动GMV" in cell_value:
            table_start = row
            break
    
    if not table_start:
        print("    [WARN] 未找到'滚动GMV'表格")
        return
    
    perf_month_col = None
    for col in range(1, ws.max_column + 1):
        header_value = str(ws.cell(row=table_start, column=col).value or "")
        if perf_month in header_value:
            perf_month_col = col
            break
    
    if not perf_month_col:
        print(f"    [WARN] 未找到绩效月份 '{perf_month}' 对应的列")
        return
    
    target_row = None
    for row in range(table_start, min(table_start + 50, ws.max_row + 1)):
        col2_value = str(ws.cell(row=row, column=2).value or "")
        col3_value = str(ws.cell(row=row, column=3).value or "")
        if "汇总" in col2_value and "汇总" in col3_value:
            target_row = row
            break
    
    if not target_row:
        print("    [WARN] 未找到【滚动GMV】='汇总'且【渠道】='汇总'所在行")
        return
    
    mark_cell(ws, target_row, perf_month_col)
    highlight_row(ws, target_row)
    print(f"    [DEBUG] 思维整体GMV: 行={target_row}, 绩效月份列={perf_month_col}")

def process_hk_macao_renewal_rate(ws, sheet_name: str, perf_month: str):
    """处理港澳团队升舱类指标（一续升舱、统合升舱、统合早鸟）"""
    print(f"  [加工] {sheet_name} - 港澳团队指标")
    pool_total = 0
    renewal_total = 0
    
    for row in range(1, ws.max_row + 1):
        b_value = str(ws.cell(row=row, column=2).value or "")
        c_value = str(ws.cell(row=row, column=3).value or "")
        
        if "港澳" in b_value and c_value == "总计":
            d_value = ws.cell(row=row, column=4).value
            f_value = ws.cell(row=row, column=6).value
            
            if isinstance(d_value, (int, float)):
                pool_total += d_value
            if isinstance(f_value, (int, float)):
                renewal_total += f_value
            
            highlight_row(ws, row)
    
    if pool_total > 0:
        renewal_rate = (renewal_total / pool_total) * 100
    else:
        renewal_rate = 0
    
    last_col = ws.max_column
    write_col = last_col + 2
    
    ws.cell(row=1, column=write_col, value="x月")
    ws.cell(row=1, column=write_col + 1, value="池子数")
    ws.cell(row=1, column=write_col + 2, value="累计续费人数")
    ws.cell(row=1, column=write_col + 3, value="续费率")
    
    data_row = 2
    ws.cell(row=data_row, column=write_col, value="港澳团队")
    ws.cell(row=data_row, column=write_col + 1, value=pool_total)
    ws.cell(row=data_row, column=write_col + 2, value=renewal_total)
    ws.cell(row=data_row, column=write_col + 3, value=f"{renewal_rate:.2f}%")
    
    for row in [1, data_row]:
        for col in range(write_col, write_col + 4):
            cell = ws.cell(row=row, column=col)
            cell.font = MS_YAHEI_FONT
    
    rate_cell = ws.cell(row=data_row, column=write_col + 3)
    rate_cell.font = MS_YAHEI_BOLD_FONT
    highlight_row(ws, data_row)

def process_hk_macao_renewal_rate_class_end(ws, sheet_name: str, perf_month: str):
    """处理港澳团队结课类指标（一续结课、统合结课）"""
    print(f"  [加工] {sheet_name} - 港澳团队指标")
    pool_total = 0
    renewal_total = 0
    
    for row in range(1, ws.max_row + 1):
        b_value = str(ws.cell(row=row, column=2).value or "")
        d_value = str(ws.cell(row=row, column=4).value or "")
        
        if "港澳" in b_value and d_value == "总计":
            e_value = ws.cell(row=row, column=5).value
            g_value = ws.cell(row=row, column=7).value
            
            if isinstance(e_value, (int, float)):
                pool_total += e_value
            if isinstance(g_value, (int, float)):
                renewal_total += g_value
            
            highlight_row(ws, row)
    
    if pool_total > 0:
        renewal_rate = (renewal_total / pool_total) * 100
    else:
        renewal_rate = 0
    
    last_col = ws.max_column
    write_col = last_col + 2
    
    ws.cell(row=1, column=write_col, value="x月")
    ws.cell(row=1, column=write_col + 1, value="池子数")
    ws.cell(row=1, column=write_col + 2, value="累计续费人数")
    ws.cell(row=1, column=write_col + 3, value="续费率")
    
    data_row = 2
    ws.cell(row=data_row, column=write_col, value="港澳团队")
    ws.cell(row=data_row, column=write_col + 1, value=pool_total)
    ws.cell(row=data_row, column=write_col + 2, value=renewal_total)
    ws.cell(row=data_row, column=write_col + 3, value=f"{renewal_rate:.2f}%")
    
    for row in [1, data_row]:
        for col in range(write_col, write_col + 4):
            cell = ws.cell(row=row, column=col)
            cell.font = MS_YAHEI_FONT
    
    rate_cell = ws.cell(row=data_row, column=write_col + 3)
    rate_cell.font = MS_YAHEI_BOLD_FONT
    highlight_row(ws, data_row)

def process_hk_macao_gmv_rate(ws, sheet_name: str, perf_month: str):
    """处理港澳团队续费GMV达成率"""
    print(f"  [加工] {sheet_name} - 港澳团队指标")
    target_row = None
    target_col = None
    
    search_end = min(21, ws.max_row + 1)
    for row in range(1, search_end):
        a_value = str(ws.cell(row=row, column=1).value or "")
        if "港澳益智教学服务区" in a_value:
            target_row = row
            for col in range(1, ws.max_column + 1):
                header_value = str(ws.cell(row=2, column=col).value or "")
                if "月累计达成率" in header_value:
                    target_col = col
                    break
            break
    
    if target_row and target_col:
        raw_value = ws.cell(row=target_row, column=target_col).value
        gmv_rate_value = None
        
        if isinstance(raw_value, (int, float)):
            gmv_rate_value = raw_value
        elif isinstance(raw_value, str):
            raw_value = raw_value.replace('%', '').strip()
            try:
                gmv_rate_value = float(raw_value)
            except ValueError:
                pass
        
        if gmv_rate_value is None:
            refund_col = None
            for row in range(1, 6):
                for col in range(1, ws.max_column + 1):
                    header = str(ws.cell(row=row, column=col).value or "").strip()
                    if "退款" in header:
                        refund_col = col
                        break
            
            e_col = 5
            k_col = 11
            
            k_val = convert_to_number(ws.cell(row=target_row, column=k_col).value)
            e_val = convert_to_number(ws.cell(row=target_row, column=e_col).value)
            u_val = None
            if refund_col:
                u_val = convert_to_number(ws.cell(row=target_row, column=refund_col).value)
            
            if k_val is not None and e_val is not None and e_val != 0:
                gmv_rate_value = ((k_val - (u_val or 0)) / e_val) * 100
        
        highlight_row(ws, target_row)
        mark_cell(ws, target_row, target_col)
        
        last_col = ws.max_column
        write_col = last_col + 2
        
        ws.cell(row=1, column=write_col, value="港澳")
        ws.cell(row=1, column=write_col + 1, value="月累计达成率")
        
        data_row = 2
        ws.cell(row=data_row, column=write_col, value="港澳益智教学服务区")
        if gmv_rate_value is not None:
            rate_display = f"{gmv_rate_value:.2f}%"
        else:
            rate_display = "-"
        ws.cell(row=data_row, column=write_col + 1, value=rate_display)
        
        for row in [1, data_row]:
            for col in [write_col, write_col + 1]:
                cell = ws.cell(row=row, column=col)
                cell.font = MS_YAHEI_FONT
        
        data_cell2 = ws.cell(row=data_row, column=write_col + 1)
        data_cell2.font = MS_YAHEI_BOLD_FONT

def process_hk_macao_conversion(ws, sheet_name: str, perf_month: str):
    """处理港澳团队后端转介绍达成"""
    print(f"  [加工] {sheet_name} - 港澳团队指标")
    total_cases = 0
    total_target = 0
    total_gmv = 0
    total_gmv_target = 0
    
    cases_col = None
    target_col = None
    gmv_col = None
    gmv_target_col = None
    
    for header_row in range(4, 7):
        for col in range(1, ws.max_column + 1):
            header_value = str(ws.cell(row=header_row, column=col).value or "")
            if cases_col is None and "全体带海外例子数" in header_value:
                cases_col = col
            if target_col is None and "海外转介绍例子目标" in header_value:
                target_col = col
            if gmv_col is None and "滚动GMV" in header_value and "目标" not in header_value and "完成率" not in header_value:
                gmv_col = col
            if gmv_target_col is None and "滚动GMV目标" in header_value:
                gmv_target_col = col
    
    overseas_start = None
    overseas_end = None
    
    for row in range(1, ws.max_row + 1):
        b_value = str(ws.cell(row=row, column=2).value or "")
        if "海外-小组" in b_value:
            overseas_start = row
            for next_row in range(row + 1, ws.max_row + 1):
                next_b_value = str(ws.cell(row=next_row, column=2).value or "")
                if next_b_value and next_b_value != "None":
                    overseas_end = next_row - 1
                    break
            if overseas_end is None:
                overseas_end = ws.max_row
            break
    
    if overseas_start and overseas_end:
        for row in range(overseas_start, overseas_end + 1):
            c_value = str(ws.cell(row=row, column=3).value or "")
            
            if "港澳" in c_value:
                if cases_col:
                    val_num = convert_to_number(ws.cell(row=row, column=cases_col).value)
                    if val_num is not None:
                        total_cases += val_num
                if target_col:
                    val_num = convert_to_number(ws.cell(row=row, column=target_col).value)
                    if val_num is not None:
                        total_target += val_num
                if gmv_col:
                    val_num = convert_to_number(ws.cell(row=row, column=gmv_col).value)
                    if val_num is not None:
                        total_gmv += val_num
                if gmv_target_col:
                    val_num = convert_to_number(ws.cell(row=row, column=gmv_target_col).value)
                    if val_num is not None:
                        total_gmv_target += val_num
                
                highlight_row(ws, row)
    
    if total_target > 0:
        case_rate = (total_cases / total_target) * 100
    else:
        case_rate = 0
    
    if total_gmv_target > 0:
        gmv_rate = (total_gmv / total_gmv_target) * 100
    else:
        gmv_rate = 0
    
    combined_rate = case_rate * 0.6 + gmv_rate * 0.4
    
    last_col = ws.max_column
    write_col = last_col + 2
    
    ws.cell(row=1, column=write_col, value="港澳")
    ws.cell(row=1, column=write_col + 1, value="全体带海外例子数")
    ws.cell(row=1, column=write_col + 2, value="海外转介绍例子目标")
    ws.cell(row=1, column=write_col + 3, value="例子达成率-月度")
    ws.cell(row=1, column=write_col + 4, value="滚动GMV")
    ws.cell(row=1, column=write_col + 5, value="滚动GMV目标")
    ws.cell(row=1, column=write_col + 6, value="滚动GMV完成率")
    ws.cell(row=1, column=write_col + 7, value="转介绍综合达成率")
    
    data_row = 2
    ws.cell(row=data_row, column=write_col, value="港澳")
    ws.cell(row=data_row, column=write_col + 1, value=total_cases)
    ws.cell(row=data_row, column=write_col + 2, value=total_target)
    ws.cell(row=data_row, column=write_col + 3, value=f"{case_rate:.2f}%")
    ws.cell(row=data_row, column=write_col + 4, value=total_gmv)
    ws.cell(row=data_row, column=write_col + 5, value=total_gmv_target)
    ws.cell(row=data_row, column=write_col + 6, value=f"{gmv_rate:.2f}%")
    ws.cell(row=data_row, column=write_col + 7, value=f"{combined_rate:.2f}%")
    
    for row in [1, data_row]:
        for col in range(write_col, write_col + 8):
            cell = ws.cell(row=row, column=col)
            cell.font = MS_YAHEI_FONT
    
    combined_cell = ws.cell(row=data_row, column=write_col + 7)
    combined_cell.font = MS_YAHEI_BOLD_FONT
    highlight_row(ws, data_row)

def apply_secondary_processing(wb, perf_month):
    """对合并后的工作簿应用二次加工"""
    print("\n" + "=" * 50)
    print("【阶段2.5】应用二次加工")
    print("=" * 50)
    
    for sheet_name in wb.sheetnames:
        ws = wb[sheet_name]
        print(f"\n  [Sheet] {sheet_name}")
        
        # 列过滤
        hide_columns(ws, sheet_name)
        
        # 统一转换为半角竖线进行比较
        normalized_name = sheet_name.replace('｜', '|')
        
        # 关键sheet处理（含高亮、标记、列宽自适应）
        if normalized_name == "非手推GMV":
            process_non_hand_push_gmv(ws, perf_month)
            auto_adjust_column_width(ws)
        elif normalized_name == "港澳商务GMV|ROI":
            process_hk_macao_gmv_roi(ws, perf_month)
        elif normalized_name == "台湾 滚转|例子到课率":
            process_taiwan_conversion(ws, perf_month)
            filter_taiwan_rows(ws)
            auto_adjust_column_width(ws)
        elif normalized_name == "思维整体GMV":
            process_overall_gmv(ws, perf_month)
            auto_adjust_column_width(ws)
        elif normalized_name in ["一续升舱", "统合升舱", "统合早鸟"]:
            process_hk_macao_renewal_rate(ws, normalized_name, perf_month)
        elif normalized_name in ["一续结课", "统合结课"]:
            process_hk_macao_renewal_rate_class_end(ws, normalized_name, perf_month)
        elif normalized_name == "续费GMV达成率":
            process_hk_macao_gmv_rate(ws, normalized_name, perf_month)
        elif normalized_name == "后端转介绍达成":
            process_hk_macao_conversion(ws, normalized_name, perf_month)

# ==================== BI操作函数 ====================
async def login(page, cfg):
    await page.goto(cfg["base_url"], wait_until="networkidle")
    await page.wait_for_selector('input[bofid="username"]', timeout=20000)
    await page.fill('input[bofid="username"]', cfg["username"])
    await page.fill('input[bofid="password"]', cfg["password"])
    await page.click('input[bofid="login"]')
    await page.wait_for_load_state("networkidle", timeout=40000)

async def open_report(page, url, name):
    print(f"\n[步骤1] 打开报表: {name}")
    await page.goto(url, wait_until="domcontentloaded", timeout=90000)
    try:
        await page.wait_for_load_state("load", timeout=30000)
    except Exception:
        pass
    await asyncio.sleep(3)
    await wait_month_inputs_ready(page)

async def get_month_inputs_values(page):
    vals = []
    for fr in all_frames(page):
        month_inputs = fr.locator("input.multicalendar-nobackground-edit")
        cnt = await month_inputs.count()
        for i in range(cnt):
            try:
                vals.append((await month_inputs.nth(i).input_value()).strip())
            except Exception:
                vals.append("")
    return vals[0] if len(vals) >= 1 else "", vals[1] if len(vals) >= 2 else ""

async def wait_month_inputs_ready(page, timeout_ms=30000):
    start = asyncio.get_event_loop().time()
    while True:
        s, e = await get_month_inputs_values(page)
        if s and e:
            return
        if (asyncio.get_event_loop().time() - start) * 1000 > timeout_ms:
            return
        await asyncio.sleep(0.5)

async def wait_month_values(page, timeout_ms: int = 8000) -> tuple[str, str]:
    start = asyncio.get_event_loop().time()
    last_s, last_e = "", ""
    while True:
        s, e = await get_month_inputs_values(page)
        last_s, last_e = s, e
        if s and e:
            return s, e
        if (asyncio.get_event_loop().time() - start) * 1000 > timeout_ms:
            return last_s, last_e
        await asyncio.sleep(0.3)

async def set_input_by_row_label(page, label: str, value: str) -> bool:
    for fr in all_frames(page):
        label_cell = fr.locator(f'td:has-text("{label}")').first
        count = await label_cell.count()
        if count == 0:
            print(f"  [DEBUG] 在frame '{fr.name}' 未找到标签 '{label}'，跳过")
            continue
        print(f"  [DEBUG] 在frame '{fr.name}' 找到标签 '{label}'")
        tr = label_cell.locator("xpath=ancestor::tr[1]")
        inputs = tr.locator("input.combobox-edit, input.multicalendar-nobackground-edit, input[type='text']")
        input_count = await inputs.count()
        print(f"  [DEBUG] 在同一行找到 {input_count} 个输入框")
        if input_count == 0:
            print(f"  [DEBUG] 未找到可见输入框，跳过")
            continue
        for i in range(input_count):
            inp = inputs.nth(i)
            if not await inp.is_visible():
                continue
            try:
                await inp.evaluate("el => el.removeAttribute('readonly')")
            except Exception:
                pass
            await inp.click(timeout=4000, force=True)
            try:
                await inp.fill("")
            except Exception:
                await inp.press("Control+a")
                await inp.press("Backspace")
            await inp.fill(value)
            await inp.dispatch_event("change")
            await inp.dispatch_event("blur")
            await inp.press("Enter")
            await asyncio.sleep(0.2)
            print(f"  [DEBUG] 成功设置 {label} = {value}")
            return True
    print(f"  [WARN] 设置 '{label}' 失败：未找到可用的输入框")
    return False

async def set_renewal_pools(page, pools: list[str]) -> None:
    """设置【思维续费池】多选参数。按索引定位：从左到右第3个输入框（索引为2）。"""
    print(f"[INFO] 设置思维续费池: {pools}")
    
    pool_input = None
    
    # 按索引定位：第3个输入框（索引为2）
    inputs = page.locator('input.combobox-edit')
    input_count = await inputs.count()
    print(f"[DEBUG] 找到 {input_count} 个 combobox-edit 输入框")
    
    if input_count >= 3:
        pool_input = inputs.nth(2)
        if await pool_input.is_visible():
            print(f"[DEBUG] 按索引定位到思维续费池输入框(第3个，索引2)")
        else:
            pool_input = None
    
    # 兜底：按标签定位
    if not pool_input:
        pool_input_xpath = page.locator(
            'xpath=//td[contains(normalize-space(.),"思维续费池")]/following-sibling::td//input[contains(@class,"combobox-edit")]'
        )
        xpath_count = await pool_input_xpath.count()
        print(f"[DEBUG] 思维续费池 XPath 命中输入框数量: {xpath_count}")
        for i in range(xpath_count):
            cand = pool_input_xpath.nth(i)
            if await cand.is_visible():
                pool_input = cand
                print(f"[DEBUG] 命中思维续费池输入框(xpath) index={i}")
                break
    
    if not pool_input:
        pool_label = page.locator('td:has-text("思维续费池")').first
        if await pool_label.count() > 0:
            tr = pool_label.locator("xpath=ancestor::tr[1]")
            nearby = tr.locator("input.combobox-edit")
            near_count = await nearby.count()
            print(f"[DEBUG] 思维续费池同行找到 {near_count} 个输入框")
            for i in range(near_count):
                cand = nearby.nth(i)
                if await cand.is_visible():
                    pool_input = cand
                    print(f"[DEBUG] 命中思维续费池输入框(tr) index={i}")
                    break
    
    if not pool_input:
        raise RuntimeError("未找到思维续费池输入框")
    
    pools_text = ",".join(pools)
    
    # 移除readonly属性
    await pool_input.evaluate('el => { el.removeAttribute("readonly"); el.readOnly = false; }')
    
    await pool_input.click(timeout=5000, force=True)
    try:
        await pool_input.fill("")
    except Exception:
        await pool_input.press("Control+a")
        await pool_input.press("Backspace")
    await pool_input.type(pools_text, delay=50)
    await pool_input.press("Enter")
    await page.click("body", position={"x": 50, "y": 50}, timeout=3000)
    await asyncio.sleep(1.5)

async def get_input_value_by_row_label(page, label: str) -> str:
    for fr in all_frames(page):
        label_cell = fr.locator(f'td:has-text("{label}")').first
        if await label_cell.count() == 0:
            continue
        tr = label_cell.locator("xpath=ancestor::tr[1]")
        inputs = tr.locator("input.combobox-edit, input.multicalendar-nobackground-edit, input[type='text']")
        count = await inputs.count()
        for i in range(count):
            inp = inputs.nth(i)
            if not await inp.is_visible():
                continue
            try:
                return (await inp.input_value()).strip()
            except Exception:
                continue
    return ""

async def wait_until_month_in_table(page, month_token: str, timeout_ms: int = 45000) -> bool:
    start = asyncio.get_event_loop().time()
    while True:
        try:
            for fr in all_frames(page):
                try:
                    txt = await fr.locator("body").inner_text(timeout=2000)
                except Exception:
                    continue
                if month_token in txt:
                    print(f"[DEBUG] 检测到目标月份已出现在报表中: {month_token}")
                    return True
        except Exception:
            pass
        if (asyncio.get_event_loop().time() - start) * 1000 > timeout_ms:
            print(f"[WARNING] 等待报表出现目标月份超时: {month_token}")
            return False
        await asyncio.sleep(1.0)

async def ensure_month_ready_with_retry(page, month_token: str) -> None:
    ok = await wait_until_month_in_table(page, month_token, timeout_ms=45000)
    if ok:
        return
    print(f"[INFO] 第一次未检测到目标月份 {month_token}，执行二次刷新")
    await refresh_report(page)
    ok2 = await wait_until_month_in_table(page, month_token, timeout_ms=45000)
    if not ok2:
        raise RuntimeError(f"刷新两次后仍未检测到目标月份: {month_token}")

async def wait_refresh_visual_cycle(page, timeout_ms: int = 45000) -> None:
    start = asyncio.get_event_loop().time()
    seen_loading = False
    while True:
        txt_all = ""
        for fr in all_frames(page):
            try:
                txt_all += " " + (await fr.locator("body").inner_text(timeout=1200))
            except Exception:
                continue
        if ("点击图标取消查询" in txt_all) or ("取消查询" in txt_all):
            seen_loading = True
        if seen_loading and ("点击图标取消查询" not in txt_all) and ("取消查询" not in txt_all):
            return
        if (asyncio.get_event_loop().time() - start) * 1000 > timeout_ms:
            return
        await asyncio.sleep(0.8)

async def force_set_month_inputs(page, start_value: str, end_value: str) -> bool:
    for fr in all_frames(page):
        try:
            ok = await fr.evaluate(
                """([startValue, endValue]) => {
                    const nodes = Array.from(document.querySelectorAll('input.multicalendar-nobackground-edit'));
                    if (nodes.length < 2) return false;
                    const start = nodes[0];
                    const end = nodes[1];
                    for (const el of [start, end]) {
                        el.removeAttribute('readonly');
                        el.readOnly = false;
                    }
                    start.value = startValue;
                    end.value = endValue;
                    for (const el of [start, end]) {
                        el.dispatchEvent(new Event('input', { bubbles: true }));
                        el.dispatchEvent(new Event('change', { bubbles: true }));
                        el.dispatchEvent(new Event('blur', { bubbles: true }));
                    }
                    return true;
                }""",
                [start_value, end_value],
            )
            if ok:
                return True
        except Exception:
            pass

    all_month_inputs = []
    for fr in all_frames(page):
        month_inputs = fr.locator("input.multicalendar-nobackground-edit")
        cnt = await month_inputs.count()
        for i in range(cnt):
            all_month_inputs.append(month_inputs.nth(i))
    if len(all_month_inputs) < 2:
        return False
    edited = 0
    for inp, val in [(all_month_inputs[0], start_value), (all_month_inputs[1], end_value)]:
        try:
            await inp.evaluate("el => { el.removeAttribute('readonly'); el.readOnly = false; }")
            await inp.click(timeout=4000, force=True)
            await inp.fill("")
            await inp.type(val, delay=20)
            await inp.dispatch_event("change")
            await inp.dispatch_event("blur")
            edited += 1
        except Exception:
            pass
    if edited >= 2:
        return True
    return False

async def set_and_verify(page, label: str, value: str, required: bool = True) -> None:
    ok = await set_input_by_row_label(page, label, value)
    actual = await get_input_value_by_row_label(page, label)
    print(f"[DEBUG] 参数[{label}] 目标='{value}' 设置结果={ok} 回读='{actual}'")
    if required and (not ok or value not in actual):
        raise RuntimeError(f"参数未生效: {label} 期望包含 '{value}'，实际 '{actual}'")

import re

def parse_yyyymm(text: str) -> int | None:
    if not text:
        return None
    text = text.strip()
    m = re.search(r"(\d{4})\D?(\d{1,2})", text)
    if not m:
        return None
    y = int(m.group(1))
    mm = int(m.group(2))
    if mm < 1 or mm > 12:
        return None
    return y * 100 + mm

async def ensure_month_range(page, perf_month_raw: str, perf_month_cn: str) -> None:
    await wait_month_inputs_ready(page)
    target = parse_yyyymm(perf_month_raw)
    start_val, end_val = await wait_month_values(page)
    start_m = parse_yyyymm(start_val)
    end_m = parse_yyyymm(end_val)

    print(f"[DEBUG] 月份区间检查: 开始='{start_val}' 结束='{end_val}' 目标='{perf_month_raw}'")

    if target and start_m and end_m and start_m <= target <= end_m:
        print(f"[INFO] 绩效月份 {perf_month_raw} 已在区间内，不调整月份参数")
        return

    print(f"[INFO] 绩效月份 {perf_month_raw} 不在区间内，开始调整月份参数")
    year = int(perf_month_raw.split("-")[0])
    start_cn = f"{year:04d}年01月"
    end_cn = f"{year:04d}年12月"
    start_iso = f"{year:04d}-01"
    end_iso = f"{year:04d}-12"
    ok = await force_set_month_inputs(page, start_iso, end_iso)
    if not ok:
        raise RuntimeError("月份参数未生效：无法定位开始/结束月份输入框")
    await asyncio.sleep(0.6)
    s_chk, e_chk = await wait_month_values(page, timeout_ms=3000)
    if parse_yyyymm(s_chk) != year * 100 + 1 or parse_yyyymm(e_chk) != year * 100 + 12:
        await force_set_month_inputs(page, start_cn, end_cn)
    print(f"[DEBUG] 已写入月份参数: 开始='{start_iso}'(兜底{start_cn}) 结束='{end_iso}'(兜底{end_cn})")
    await refresh_report(page)
    await wait_refresh_visual_cycle(page, timeout_ms=45000)
    await wait_month_inputs_ready(page, timeout_ms=15000)
    await wait_until_month_in_table(page, perf_month_raw, timeout_ms=45000)
    print("[DEBUG] 月份参数写入后已执行刷新")

    await asyncio.sleep(1.0)
    start_val2, end_val2 = await wait_month_values(page, timeout_ms=12000)
    start_m2 = parse_yyyymm(start_val2)
    end_m2 = parse_yyyymm(end_val2)
    if not (target and start_m2 and end_m2 and start_m2 <= target <= end_m2):
        raise RuntimeError(
            f"月份参数未覆盖目标月份: 开始='{start_val2}' 结束='{end_val2}' 目标='{perf_month_raw}'"
        )
    print(f"[INFO] 月份参数已调整为全年区间并覆盖绩效月份: {start_cn} ~ {end_cn}")

async def set_date_range_like_roi(page, start_date: str, end_date: str) -> None:
    print(f"[INFO] 设置日期筛选: {start_date} 至 {end_date}")

    inputs = page.locator('input.combobox-edit')
    input_count = await inputs.count()
    print(f"[DEBUG] 找到 {input_count} 个 combobox-edit 输入框")

    if input_count >= 2:
        end_input = inputs.nth(0)
        start_input = inputs.nth(1)

        await end_input.evaluate('el => { el.removeAttribute("readonly"); el.readOnly = false; }')
        await end_input.fill(end_date)
        await end_input.dispatch_event("change")
        await end_input.dispatch_event("blur")
        print(f"[DEBUG] 已设置结束日期(输入框0): {end_date}")

        await start_input.evaluate('el => { el.removeAttribute("readonly"); el.readOnly = false; }')
        await start_input.fill(start_date)
        await start_input.dispatch_event("change")
        await start_input.dispatch_event("blur")
        print(f"[DEBUG] 已设置开始日期(输入框1): {start_date}")
    else:
        for fr in all_frames(page):
            start_input = fr.locator('td:has-text("开始日期")').locator('xpath=ancestor::tr[1]//input.combobox-edit').first
            if await start_input.count() > 0:
                await start_input.evaluate('el => el.removeAttribute("readonly")')
                await start_input.fill(start_date)
                await start_input.dispatch_event("change")
                await start_input.dispatch_event("blur")
                print(f"[DEBUG] 已设置开始日期: {start_date}")

            end_input = fr.locator('td:has-text("结束日期")').locator('xpath=ancestor::tr[1]//input.combobox-edit').first
            if await end_input.count() > 0:
                await end_input.evaluate('el => el.removeAttribute("readonly")')
                await end_input.fill(end_date)
                await end_input.dispatch_event("change")
                await end_input.dispatch_event("blur")
                print(f"[DEBUG] 已设置结束日期: {end_date}")

async def set_single_date(page, date_value: str) -> None:
    print(f"[INFO] 设置单日期参数: {date_value}")

    date_input = None

    # 遍历所有frames，寻找可见的输入框
    for fr in all_frames(page):
        inputs = fr.locator('input.combobox-edit')
        input_count = await inputs.count()
        print(f"[DEBUG] 在frame '{fr.name}' 找到 {input_count} 个 combobox-edit 输入框")

        if input_count >= 1:
            candidate_input = inputs.nth(0)
            # 检查可见性
            try:
                is_visible = await candidate_input.is_visible(timeout=2000)
            except Exception:
                is_visible = False
            
            if is_visible:
                date_input = candidate_input
                print(f"[DEBUG] 在frame '{fr.name}' 定位到可见的日期输入框(0)")
                break
            else:
                print(f"[DEBUG] 在frame '{fr.name}' 输入框不可见，继续查找")

    if date_input:
        await date_input.evaluate('el => { el.removeAttribute("readonly"); el.readOnly = false; }')
        await date_input.click(timeout=4000, force=True)
        await date_input.fill(date_value)
        await date_input.dispatch_event("input")
        await date_input.dispatch_event("change")
        await date_input.dispatch_event("blur")
        await date_input.press("Enter")
        print(f"[DEBUG] 已设置日期(输入框0): {date_value}")

        await asyncio.sleep(1.5)

        actual_date = (await date_input.input_value() or "").strip()
        print(f"[DEBUG] 日期参数设置结果: 日期='{actual_date}'")

        if actual_date != date_value:
            print(f"[WARN] 日期设置失败，期望 '{date_value}'，实际 '{actual_date}'")
            await date_input.click(timeout=4000, force=True)
            await date_input.fill("")
            await date_input.type(date_value, delay=50)
            await date_input.dispatch_event("change")
            await asyncio.sleep(0.5)
            actual_date = (await date_input.input_value() or "").strip()
            print(f"[DEBUG] 日期重试后: '{actual_date}'")

        return

    for fr in all_frames(page):
        date_input = fr.locator('td:has-text("日期")').locator('xpath=ancestor::tr[1]//input.combobox-edit').first
        if await date_input.count() > 0:
            await date_input.evaluate('el => { el.removeAttribute("readonly"); el.readOnly = false; }')
            await date_input.click(timeout=4000, force=True)
            await date_input.fill(date_value)
            await date_input.dispatch_event("change")
            await date_input.dispatch_event("blur")
            print(f"[DEBUG] 已设置日期(按标签): {date_value}")

    await asyncio.sleep(1.0)

    actual_date = await get_input_value_by_row_label(page, "日期")
    print(f"[DEBUG] 日期参数设置结果: 日期='{actual_date}'")

async def set_date_and_refund(page, date_value: str, refund_start_date: str) -> None:
    print(f"[INFO] 设置日期参数: 日期={date_value}, 退费结束时间={refund_start_date}")

    date_input = None
    refund_input = None

    # 遍历所有frames，寻找可见的输入框
    for fr in all_frames(page):
        inputs = fr.locator('input.combobox-edit')
        input_count = await inputs.count()
        print(f"[DEBUG] 在frame '{fr.name}' 找到 {input_count} 个 combobox-edit 输入框")

        if input_count >= 2:
            # 检查输入框是否可见
            date_input = inputs.nth(0)
            refund_input = inputs.nth(1)
            
            # 检查可见性
            try:
                date_visible = await date_input.is_visible(timeout=2000)
                refund_visible = await refund_input.is_visible(timeout=2000)
            except Exception:
                date_visible = False
                refund_visible = False
            
            if date_visible and refund_visible:
                print(f"[DEBUG] 在frame '{fr.name}' 定位到可见的日期输入框(0)和退费输入框(1)")
                break
            else:
                print(f"[DEBUG] 在frame '{fr.name}' 输入框不可见，继续查找")
                date_input = None
                refund_input = None

    if date_input and refund_input:
        await date_input.evaluate('el => { el.removeAttribute("readonly"); el.readOnly = false; }')
        await date_input.click(timeout=4000, force=True)
        await date_input.fill(date_value)
        await date_input.dispatch_event("input")
        await date_input.dispatch_event("change")
        await date_input.dispatch_event("blur")
        await date_input.press("Enter")
        print(f"[DEBUG] 已设置日期(输入框0): {date_value}")

        await refund_input.evaluate('el => { el.removeAttribute("readonly"); el.readOnly = false; }')
        await refund_input.click(timeout=4000, force=True)
        await refund_input.fill(refund_start_date)
        await refund_input.dispatch_event("input")
        await refund_input.dispatch_event("change")
        await refund_input.dispatch_event("blur")
        await refund_input.press("Enter")
        print(f"[DEBUG] 已设置退费结束时间(输入框1): {refund_start_date}")

        await asyncio.sleep(1.5)

        actual_date = (await date_input.input_value() or "").strip()
        actual_refund = (await refund_input.input_value() or "").strip()
        print(f"[DEBUG] 日期参数设置结果: 日期='{actual_date}', 退费结束时间='{actual_refund}'")

        if actual_date != date_value:
            print(f"[WARN] 日期设置失败，期望 '{date_value}'，实际 '{actual_date}'")
            await date_input.click(timeout=4000, force=True)
            await date_input.fill("")
            await date_input.type(date_value, delay=50)
            await date_input.dispatch_event("change")
            await asyncio.sleep(0.5)
            actual_date = (await date_input.input_value() or "").strip()
            print(f"[DEBUG] 日期重试后: '{actual_date}'")

        if actual_refund != refund_start_date:
            print(f"[WARN] 退费结束时间设置失败，期望 '{refund_start_date}'，实际 '{actual_refund}'")
            await refund_input.click(timeout=4000, force=True)
            await refund_input.fill("")
            await refund_input.type(refund_start_date, delay=50)
            await refund_input.dispatch_event("change")
            await asyncio.sleep(0.5)
            actual_refund = (await refund_input.input_value() or "").strip()
            print(f"[DEBUG] 退费结束时间重试后: '{actual_refund}'")

        return

    print("[DEBUG] 未按索引找到输入框，尝试按标签查找")
    for fr in all_frames(page):
        date_input = fr.locator('td:has-text("日期")').locator('xpath=ancestor::tr[1]//input.combobox-edit').first
        if await date_input.count() > 0:
            await date_input.evaluate('el => { el.removeAttribute("readonly"); el.readOnly = false; }')
            await date_input.click(timeout=4000, force=True)
            await date_input.fill(date_value)
            await date_input.dispatch_event("change")
            await date_input.dispatch_event("blur")
            print(f"[DEBUG] 已设置日期(按标签): {date_value}")

        refund_input = fr.locator('td:has-text("退费结束时间")').locator('xpath=ancestor::tr[1]//input.combobox-edit').first
        if await refund_input.count() > 0:
            await refund_input.evaluate('el => { el.removeAttribute("readonly"); el.readOnly = false; }')
            await refund_input.click(timeout=4000, force=True)
            await refund_input.fill(refund_start_date)
            await refund_input.dispatch_event("change")
            await refund_input.dispatch_event("blur")
            print(f"[DEBUG] 已设置退费结束时间(按标签): {refund_start_date}")

    await asyncio.sleep(1.0)

    actual_date = await get_input_value_by_row_label(page, "日期")
    actual_refund = await get_input_value_by_row_label(page, "退费结束时间")
    print(f"[DEBUG] 日期参数设置结果: 日期='{actual_date}', 退费结束时间='{actual_refund}'")

async def refresh_report(page) -> None:
    query_selectors = [
        'input[title="查询"]',
        'button:has-text("查询")',
        'span:has-text("查询")',
        '[class*="query"]',
    ]
    for s in query_selectors:
        loc = page.locator(s).first
        if await loc.count() > 0:
            try:
                await loc.click(timeout=3000)
                print(f"[DEBUG] 点击查询按钮: {s}")
                await asyncio.sleep(1.5)
                break
            except Exception:
                continue

    selectors = [
        'input.bof_button.btnRefresh.queryview-toolbar-button.queryview-toolbar-refresh',
        'input[bofid="_btnRefresh"][type="button"]',
        'input.btnRefresh',
        'button.btnRefresh',
        'input[title="刷新"]',
        'span:has-text("刷新")',
        '[class*="refresh"]',
    ]
    for s in selectors:
        loc = page.locator(s).first
        if await loc.count() > 0:
            try:
                await loc.click(timeout=5000)
                print(f"[DEBUG] 点击刷新按钮: {s}")
                try:
                    await loc.dblclick(timeout=3000)
                    print(f"[DEBUG] 对刷新按钮执行双击兜底: {s}")
                except Exception:
                    pass
                await asyncio.sleep(8)
                return
            except Exception:
                continue
    raise RuntimeError("未找到刷新按钮")

async def click_first(page, selectors: list[str], desc: str) -> None:
    for s in selectors:
        loc = page.locator(s)
        if await loc.count() > 0:
            try:
                await loc.first.click(timeout=5000)
                return
            except Exception:
                continue
    raise RuntimeError(f"未找到元素: {desc}")

async def click_export_type_b(page) -> None:
    await click_first(page, ['input[value="导出"]', 'span:has-text("导出")', 'button:has-text("导出")', '[class*="export"]'], "导出按钮")
    await asyncio.sleep(0.5)
    await click_first(page, ['span:has-text("Excel")', 'div[caption="Excel"]', 'div[id^="EXCEL"]'], "Excel选项")
    await asyncio.sleep(0.5)
    await click_first(page, ['input[value="在线导出"]', 'div:has-text("在线导出")', 'text=在线导出'], "在线导出按钮")

async def export_report(page, report: dict) -> Path:
    target_path = make_export_target(report["name"])
    async with page.expect_download(timeout=180000) as dl_info:
        await click_export_type_b(page)
    download = await dl_info.value
    await download.save_as(str(target_path))
    print(f"[SUCCESS] 导出完成: {target_path.name}")
    return target_path

async def apply_filters(page, report: dict, perf_month_raw: str, perf_month_cn: str, start_date: str, end_date: str) -> None:
    mode = report["mode"]
    if mode == "no_filters":
        print("[INFO] 当前报表无需调整参数，直接导出")
    elif mode == "month_trend":
        await ensure_month_range(page, perf_month_raw, perf_month_cn)
        await ensure_month_ready_with_retry(page, perf_month_raw)
    elif mode == "region_and_month":
        await set_and_verify(page, "区域等级", report["region"], required=True)
        await ensure_month_range(page, perf_month_raw, perf_month_cn)
        await ensure_month_ready_with_retry(page, perf_month_raw)
    elif mode == "date_only":
        await set_date_range_like_roi(page, start_date, end_date)
        await refresh_report(page)
        await wait_refresh_visual_cycle(page, timeout_ms=45000)
    elif mode == "date_and_subject":
        await set_date_range_like_roi(page, start_date, end_date)
        await set_input_by_row_label(page, "主投学科", "思维")
        await refresh_report(page)
        await wait_refresh_visual_cycle(page, timeout_ms=45000)
    elif mode == "region_only":
        await set_input_by_row_label(page, "区域等级", report["region"])
        await refresh_report(page)
        await wait_refresh_visual_cycle(page, timeout_ms=45000)
    elif mode == "date_and_refund":
        await set_date_and_refund(page, end_date, start_date)
        await refresh_report(page)
        await wait_refresh_visual_cycle(page, timeout_ms=45000)
    elif mode == "date_refund_and_pools":
        await set_date_and_refund(page, end_date, start_date)
        if "pools" in report:
            await set_renewal_pools(page, report["pools"])
        await refresh_report(page)
        await wait_refresh_visual_cycle(page, timeout_ms=45000)
    elif mode == "date_single":
        await set_single_date(page, end_date)
        await refresh_report(page)
        await wait_refresh_visual_cycle(page, timeout_ms=45000)
    else:
        raise RuntimeError(f"未知报表模式: {mode}")

# ==================== 数据更新函数 ====================
def update_manager_kpi(wb_out, wb_processed, perf_month):
    ws_kh = wb_out["管理者绩效考核方案"]
    
    # 行10列4: 非手推GMV
    ws_fst = wb_processed["非手推GMV"]
    month_col = find_month_col(ws_fst, perf_month)
    if month_col:
        total = 0
        for row in range(6, 25):
            b_val = str(ws_fst.cell(row=row, column=2).value or "")
            if "新带新" in b_val or "前端转介绍" in b_val or "后端非手推" in b_val:
                num_val = convert_to_number(ws_fst.cell(row=row, column=month_col).value)
                if num_val:
                    total += num_val
        if total > 0:
            ws_kh.cell(row=10, column=4, value=total)
            print(f"  ✓ 行10列4 - 非手推GMV: {total:,.0f}")
    
    # 行11列4: 主投滚动GMV 和 行11列7: 主投滚动ROI2达成
    # 与分阶段脚本一致：表头在第5行，查找列2="总计"的行
    ws_gmv_roi = None
    for sheet_name in wb_processed.sheetnames:
        normalized = sheet_name.replace('｜', '|')
        if "港澳商务GMV|ROI" in normalized:
            ws_gmv_roi = wb_processed[sheet_name]
            break
    
    if ws_gmv_roi:
        gmv_value = None
        roi_value = None
        # 表头在第5行，查找列2="总计"的行
        for row in range(1, ws_gmv_roi.max_row + 1):
            val = str(ws_gmv_roi.cell(row=row, column=2).value or "")
            if "总计" in val:
                for col in range(1, ws_gmv_roi.max_column + 1):
                    header = str(ws_gmv_roi.cell(row=5, column=col).value or "")
                    if "主投滚动GMV" in header:
                        gmv_value = ws_gmv_roi.cell(row=row, column=col).value
                    if "主投滚动ROI2达成" in header:
                        roi_value = ws_gmv_roi.cell(row=row, column=col).value
                break
        if gmv_value:
            ws_kh.cell(row=11, column=4, value=gmv_value)
            print(f"  ✓ 行11列4 - 主投滚动GMV: {gmv_value:,.0f}")
        if roi_value:
            ws_kh.cell(row=11, column=7, value=roi_value)
            print(f"  ✓ 行11列7 - 主投滚动ROI2达成: {roi_value:.4f}")
    
    # 行23列4: 例子到课率
    ws_tw = None
    for sheet_name in wb_processed.sheetnames:
        normalized = sheet_name.replace('｜', '|')
        if "台湾" in normalized and ("滚转" in normalized or "滚轉" in normalized):
            ws_tw = wb_processed[sheet_name]
            break
    
    if ws_tw:
        # 跳过前6行参数区域
        month_col_tw = find_month_col(ws_tw, perf_month, start_row=7)
        print(f"[DEBUG] 台湾滚转 sheet find_month_col返回列: {month_col_tw}")
        if month_col_tw:
            # 打印前几行的月份标签位置，调试用
            for debug_row in range(1, 10):
                debug_val = ws_tw.cell(row=debug_row, column=month_col_tw).value
                print(f"[DEBUG] 行{debug_row}列{month_col_tw}: {debug_val}")
            # 打印第9列（I列）前10行作为对比
            print(f"[DEBUG] 对比: 列9前10行:")
            for debug_row in range(1, 10):
                debug_val = ws_tw.cell(row=debug_row, column=9).value
                print(f"[DEBUG] 行{debug_row}列9: {debug_val}")
            
            for row in range(180, 220):
                b_val = str(ws_tw.cell(row=row, column=2).value or "")
                if b_val == "汇总" and str(ws_tw.cell(row=row-1, column=2).value or "") == "例子到课率（当月）":
                    # 打印该行数据，调试用
                    print(f"[DEBUG] 例子到课率行{row}的数据:")
                    for c in range(1, 15):
                        print(f"       列{c}: {ws_tw.cell(row=row, column=c).value}")
                    cell_val = ws_tw.cell(row=row, column=month_col_tw).value
                    ws_kh.cell(row=23, column=4, value=cell_val)
                    try:
                        num_val = float(str(cell_val).strip('%')) / 100 if '%' in str(cell_val) else float(cell_val)
                        print(f"  ✓ 行23列4 - 例子到课率: {num_val:.4f}")
                    except (ValueError, TypeError):
                        print(f"  ✓ 行23列4 - 例子到课率: {cell_val}")
                    break
    
            # 行24列4: 滚动转化率
            for row in range(70, 100):
                val = str(ws_tw.cell(row=row, column=4).value or "")
                if val == "滚动转化率":
                    for r in range(row, min(row+10, ws_tw.max_row + 1)):
                        b_val = str(ws_tw.cell(row=r, column=2).value or "")
                        c_val = str(ws_tw.cell(row=r, column=3).value or "")
                        if b_val == "汇总" and c_val == "汇总":
                            cell_val = ws_tw.cell(row=r, column=month_col_tw).value
                            ws_kh.cell(row=24, column=4, value=cell_val)
                            try:
                                num_val = float(str(cell_val).strip('%')) / 100 if '%' in str(cell_val) else float(cell_val)
                                print(f"  ✓ 行24列4 - 滚动转化率: {num_val:.6f}")
                            except (ValueError, TypeError):
                                print(f"  ✓ 行24列4 - 滚动转化率: {cell_val}")
                            break
                    break
    else:
        print("  [WARN] 未找到台湾滚转 sheet")
    
    # 行25列4: 思维整体GMV（从思维整体GMV sheet读取，与分阶段脚本一致）
    ws_siwei = wb_processed["思维整体GMV"]
    # 跳过前6行参数区域
    month_col_sw = find_month_col(ws_siwei, perf_month, start_row=7)
    if month_col_sw:
        for row in range(1, ws_siwei.max_row + 1):
            col2_val = str(ws_siwei.cell(row=row, column=2).value or "")
            col3_val = str(ws_siwei.cell(row=row, column=3).value or "")
            if col2_val == "汇总" and col3_val == "汇总":
                siwei_value = ws_siwei.cell(row=row, column=month_col_sw).value
                ws_kh.cell(row=25, column=4, value=siwei_value)
                try:
                    num_val = float(siwei_value)
                    print(f"  ✓ 行25列4 - 思维整体GMV: {num_val:,.0f}")
                except (ValueError, TypeError):
                    print(f"  ✓ 行25列4 - 思维整体GMV: {siwei_value}")
                break

def update_col6_rates(wb_out):
    ws_kh = wb_out["管理者绩效考核方案"]

    def read_number(cell_ref: str):
        return convert_to_number(ws_kh[cell_ref].value)

    c52 = read_number("C52")
    c50 = read_number("C50")
    c51 = read_number("C51")
    discount = c52 if c52 is not None else ((c51 / c50) if (c50 and c51) else None)

    c10_base = read_number("N10")
    c11_base = read_number("K10")
    c25_base = read_number("K24")
    c10_formula = c10_base * discount if (c10_base is not None and discount is not None) else None
    c11_formula = c11_base * discount if (c11_base is not None and discount is not None) else None
    c25_formula = c25_base * discount if (c25_base is not None and discount is not None) else None

    d10 = read_number("D10")
    c10 = c10_formula if c10_formula is not None else read_number("C10")
    val_row4 = d10 / c10 if (d10 and c10) else None

    d11 = read_number("D11")
    c11 = c11_formula if c11_formula is not None else read_number("C11")
    g11 = read_number("G11")
    f11 = read_number("F11")
    val_row5 = (d11 / c11) * (g11 / f11) if (d11 and c11 and g11 and f11) else None

    d23 = read_number("D23")
    c23 = read_number("C23")
    val_row16 = d23 / c23 if (d23 and c23) else None

    d24 = read_number("D24")
    c24 = read_number("C24")
    val_row17 = d24 / c24 if (d24 and c24) else None

    d25 = read_number("D25")
    c25 = c25_formula if c25_formula is not None else read_number("C25")
    val_row18 = d25 / c25 if (d25 and c25) else None

    print(f"\n【绩效系数计算调试】")
    print(f"  非手推GMV: 实际={d10}, 目标={c10}, base={c10_base}, 折扣={discount}, 达成率={val_row4}")
    print(f"  港澳商务GMV: 实际={d11}, 目标={c11}, base={c11_base}, 折扣={discount}, ROI达成={g11}, ROI目标={f11}, 达成率={val_row5}")
    print(f"  例子到课率: 实际={d23}, 目标={c23}, 达成率={val_row16}")
    print(f"  滚动转化率: 实际={d24}, 目标={c24}, 达成率={val_row17}")
    print(f"  思维新签GMV: 实际={d25}, 目标={c25}, base={c25_base}, 折扣={discount}, 达成率={val_row18}")

    ws_kh.cell(row=4, column=6, value=get_rate_value(val_row4))
    ws_kh.cell(row=5, column=6, value=get_rate_value(val_row5))
    ws_kh.cell(row=16, column=6, value=get_rate_value(val_row16))
    ws_kh.cell(row=17, column=6, value=get_rate_value(val_row17))
    ws_kh.cell(row=18, column=6, value=get_rate_value(val_row18))

    print(f"\n【绩效系数】")
    if val_row4: print(f"  行4列6: {val_row4:.2%} → {get_rate_value(val_row4)}")
    if val_row5: print(f"  行5列6: {val_row5:.2%} → {get_rate_value(val_row5)}")
    if val_row16: print(f"  行16列6: {val_row16:.2%} → {get_rate_value(val_row16)}")
    if val_row17: print(f"  行17列6: {val_row17:.2%} → {get_rate_value(val_row17)}")
    if val_row18: print(f"  行18列6: {val_row18:.2%} → {get_rate_value(val_row18)}")


def update_operation_director(wb_out, wb_processed, perf_month):
    ws_director = wb_out["运营总监-孙昊天"]
    
    # ========== 从二次加工好的结果中读取 ==========
    
    # 一续升舱续费率：sheet最右方，第2行，续费率列
    ws_yixu_shengcang = wb_processed["一续升舱"]
    yixu_shengcang_rate = None
    last_col = ws_yixu_shengcang.max_column
    for col in range(last_col, 0, -1):
        header_val = str(ws_yixu_shengcang.cell(row=1, column=col).value or "")
        if "续费率" in header_val:
            rate_str = str(ws_yixu_shengcang.cell(row=2, column=col).value or "")
            if "%" in rate_str:
                yixu_shengcang_rate = float(rate_str.strip("%")) / 100
            else:
                yixu_shengcang_rate = convert_to_number(ws_yixu_shengcang.cell(row=2, column=col).value)
            break
    
    # 统合早鸟续费率：sheet最右方，第2行，续费率列
    ws_tonghe_zaoniao = wb_processed["统合早鸟"]
    tonghe_zaoniao_rate = None
    last_col = ws_tonghe_zaoniao.max_column
    for col in range(last_col, 0, -1):
        header_val = str(ws_tonghe_zaoniao.cell(row=1, column=col).value or "")
        if "续费率" in header_val:
            rate_str = str(ws_tonghe_zaoniao.cell(row=2, column=col).value or "")
            if "%" in rate_str:
                tonghe_zaoniao_rate = float(rate_str.strip("%")) / 100
            else:
                tonghe_zaoniao_rate = convert_to_number(ws_tonghe_zaoniao.cell(row=2, column=col).value)
            break
    
    # 一续结课续费率：sheet最右方，第2行，续费率列
    ws_yixu_jieke = wb_processed["一续结课"]
    yixu_jieke_rate = None
    last_col = ws_yixu_jieke.max_column
    for col in range(last_col, 0, -1):
        header_val = str(ws_yixu_jieke.cell(row=1, column=col).value or "")
        if "续费率" in header_val:
            rate_str = str(ws_yixu_jieke.cell(row=2, column=col).value or "")
            if "%" in rate_str:
                yixu_jieke_rate = float(rate_str.strip("%")) / 100
            else:
                yixu_jieke_rate = convert_to_number(ws_yixu_jieke.cell(row=2, column=col).value)
            break
    
    # 统合结课续费率：sheet最右方，第2行，续费率列
    ws_tonghe_jieke = wb_processed["统合结课"]
    tonghe_jieke_rate = None
    last_col = ws_tonghe_jieke.max_column
    for col in range(last_col, 0, -1):
        header_val = str(ws_tonghe_jieke.cell(row=1, column=col).value or "")
        if "续费率" in header_val:
            rate_str = str(ws_tonghe_jieke.cell(row=2, column=col).value or "")
            if "%" in rate_str:
                tonghe_jieke_rate = float(rate_str.strip("%")) / 100
            else:
                tonghe_jieke_rate = convert_to_number(ws_tonghe_jieke.cell(row=2, column=col).value)
            break
    
    # 续费GMV达成率：从sheet最右方查找港澳益智教学服务区对应的达成率值（二次加工结果）
    # 港澳益智教学服务区的汇总在第2行，第56列是标签'港澳益智教学服务区'，第57列是值'113.12%'
    ws_xufei_gmv = wb_processed["续费GMV达成率"]
    xufei_gmv_rate = None
    last_col = ws_xufei_gmv.max_column
    for col in range(last_col, 0, -1):
        val = str(ws_xufei_gmv.cell(row=2, column=col).value or "")
        if "港澳益智教学服务区" in val:
            rate_val = ws_xufei_gmv.cell(row=2, column=col + 1).value
            if rate_val:
                rate_str = str(rate_val)
                if "%" in rate_str:
                    xufei_gmv_rate = float(rate_str.strip("%")) / 100
                else:
                    xufei_gmv_rate = convert_to_number(rate_val)
            break
    
    # 转介绍综合达成率：sheet最右方，第2行，转介绍综合达成率列
    zhuanjieshao_rate = None
    if "后端转介绍达成" in wb_processed.sheetnames:
        ws_zhuanjieshao = wb_processed["后端转介绍达成"]
        last_col = ws_zhuanjieshao.max_column
        for col in range(last_col, 0, -1):
            header_val = str(ws_zhuanjieshao.cell(row=1, column=col).value or "")
            if "转介绍综合达成率" in header_val:
                rate_str = str(ws_zhuanjieshao.cell(row=2, column=col).value or "")
                if "%" in rate_str:
                    zhuanjieshao_rate = float(rate_str.strip("%")) / 100
                else:
                    zhuanjieshao_rate = convert_to_number(ws_zhuanjieshao.cell(row=2, column=col).value)
                break
    else:
        print("[WARNING] 加工版中缺少 [后端转介绍达成]，跳过运营总监-孙昊天的转介绍指标更新")
    
    # 更新运营总监sheet
    ws_director.cell(row=4, column=8, value=yixu_shengcang_rate)
    ws_director.cell(row=5, column=8, value=tonghe_zaoniao_rate)
    ws_director.cell(row=6, column=8, value=yixu_jieke_rate)
    ws_director.cell(row=7, column=8, value=tonghe_jieke_rate)
    ws_director.cell(row=8, column=8, value=xufei_gmv_rate)
    ws_director.cell(row=9, column=8, value=zhuanjieshao_rate)
    
    for row in range(4, 10):
        ws_director.cell(row=row, column=8).number_format = '0.00%'
    
    print(f"\n【运营总监-孙昊天】")
    if yixu_shengcang_rate: print(f"  行4列8 - 一续升舱续费率: {yixu_shengcang_rate:.2%}")
    if tonghe_zaoniao_rate: print(f"  行5列8 - 统合早鸟续费率: {tonghe_zaoniao_rate:.2%}")
    if yixu_jieke_rate: print(f"  行6列8 - 一续结课续费率: {yixu_jieke_rate:.2%}")
    if tonghe_jieke_rate: print(f"  行7列8 - 统合结课续费率: {tonghe_jieke_rate:.2%}")
    if xufei_gmv_rate: print(f"  行8列8 - 续费GMV达成率: {xufei_gmv_rate:.2%}")
    if zhuanjieshao_rate: print(f"  行9列8 - 转介绍综合达成率: {zhuanjieshao_rate:.2%}")

# ==================== 主函数 ====================
def load_env():
    env_path = BASE_DIR / ".env"
    if env_path.exists():
        for line in env_path.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                k, v = line.split("=", 1)
                os.environ[k.strip()] = v.strip().strip('"').strip("'")
    username = os.getenv("SMARTBI_USERNAME")
    password = os.getenv("SMARTBI_PASSWORD")
    base_url = os.getenv("SMARTBI_BASE_URL", "https://bi.61info.cn/smartbi/vision/index.jsp")
    if not username:
        username = input("请输入 SmartBI 用户名: ").strip()
    if not password:
        password = getpass("请输入 SmartBI 密码: ").strip()
    return {"username": username, "password": password, "base_url": base_url}

def parse_perf_month():
    raw = input("请输入绩效月份(YYYY-MM): ").strip()
    if not re.fullmatch(r"\d{4}-\d{2}", raw):
        raise ValueError("格式错误，请输入 YYYY-MM")
    y, m = raw.split("-")
    year, month = int(y), int(m)
    start_date = f"{year:04d}-{month:02d}-01"
    last_day = calendar.monthrange(year, month)[1]
    end_date = f"{year:04d}-{month:02d}-{last_day:02d}"
    cn_format = f"{year % 100}年{int(m)}月"
    return raw, cn_format, start_date, end_date

def merge_exports(exported, perf_month):
    wb = Workbook()
    wb.remove(wb.active)
    for report, path in exported:
        src_sheet = report["merge"]["source_sheet"]
        dst_sheet = report["merge"]["target_sheet"]
        copy_sheet_with_style(path, src_sheet, wb, dst_sheet)
    
    # 应用二次加工
    apply_secondary_processing(wb, perf_month)
    
    out = make_final_output_path(perf_month)
    wb.save(out)
    return out

async def main():
    print("=" * 70)
    print("管理者绩效完整流程")
    print("BI导出 → 生成加工版（含二次加工）→ 更新终版绩效文档")
    print("=" * 70)
    
    # 步骤1: 解析绩效月份
    perf_month_raw, perf_month_cn, start_date, end_date = parse_perf_month()
    print(f"\n绩效月份: {perf_month_cn}")
    print(f"日期范围: {start_date} 至 {end_date}")
    
    # 步骤2: 询问是否跳过BI导出
    skip_bi = input("是否跳过BI导出（使用已下载的报表）？(y/N): ").strip().lower() == 'y'
    
    # 如果不跳过BI导出，询问是否导出全部报表或指定报表
    selected_reports = REPORTS
    if not skip_bi:
        export_all = input("是否导出全部报表？(Y/n，默认导出全部): ").strip().lower() != 'n'
        if not export_all:
            print("\n可用的报表（输入序号，多个用逗号分隔）:")
            for i, report in enumerate(REPORTS, 1):
                print(f"  {i}. {report['name']}")
            selected_indices = input("请输入要导出的报表序号: ").strip()
            if selected_indices:
                indices = [int(x.strip()) - 1 for x in selected_indices.split(",")]
                selected_reports = [REPORTS[i] for i in indices if 0 <= i < len(REPORTS)]
            else:
                selected_reports = REPORTS
            print(f"\n将导出 {len(selected_reports)} 个报表")
    
    exported = []
    
    if not skip_bi:
        load_env()
        print("\n" + "=" * 50)
        print("【阶段1】通过 SmartBI CLI 导出报表")
        print("=" * 50)

        failed_reports = []
        for report in selected_reports:
            try:
                path = run_cli_export(report, perf_month_raw, start_date, end_date)
                exported.append((report, path))
            except Exception as e:
                print(f"[ERROR] 报表失败: {report['name']} -> {e}")
                failed_reports.append(report["name"])

        if not exported:
            raise RuntimeError("本次没有任何报表导出成功")

        if failed_reports:
            print(f"\n[WARNING] 以下报表导出失败，请手动补回:")
            for name in failed_reports:
                print(f"  - {name}")
    else:
        print("\n" + "=" * 50)
        print("【阶段1】跳过BI导出，使用CLI最新结果")
        print("=" * 50)

        for report in selected_reports:
            path = resolve_report_input_path(report)
            if path is not None:
                exported.append((report, path))
                print(f"[INFO] 找到可用报表: {path.name}")
            else:
                print(f"[WARNING] 未找到对应报表: {report['name']}")

        if not exported:
            raise RuntimeError("downloads/cli_exports 目录中没有找到任何报表文件")
    
    # 步骤4: 合并报表生成加工版（含二次加工）
    print("\n" + "=" * 50)
    print("【阶段2】合并报表生成管理者绩效明细加工版")
    print("=" * 50)
    processed_path = merge_exports(exported, perf_month_raw)
    print(f"[SUCCESS] 加工版生成: {processed_path.name}")
    
    # 步骤5: 更新终版绩效文档
    print("\n" + "=" * 50)
    print("【阶段3】更新终版绩效文档")
    print("=" * 50)
    
    input_file = None

    exact_path = INPUT_DIR / f"【{perf_month_cn}】管理者绩效-20260409-终版.xlsx"
    if exact_path.exists():
        input_file = exact_path
    else:
        pattern = str(INPUT_DIR / f"【{perf_month_cn}】管理者绩效*终版*.xlsx")
        files = glob.glob(pattern)
        if files:
            files.sort(key=lambda x: os.path.getmtime(x), reverse=True)
            input_file = Path(files[0])
            print(f"  [INFO] 找到输入文件: {input_file.name}")
    
    if not input_file or not input_file.exists():
        print(f"[ERROR] 输入文件不存在: {INPUT_DIR / f'【{perf_month_cn}】管理者绩效-20260409-终版.xlsx'}")
        print(f"[ERROR] 请将绩效终版文件放入 {INPUT_DIR} 目录")
        print("\n" + "=" * 70)
        print("[SUCCESS] 流程完成")
        print(f"加工版文件: {processed_path}")
        print("注意: 终版绩效文档输入文件不存在，请手动复制并更新")
        print("=" * 70)
        return
    
    wb_out = load_workbook(str(input_file), data_only=False)
    wb_processed = load_workbook(processed_path, data_only=True)
    
    update_manager_kpi(wb_out, wb_processed, perf_month_raw)
    update_col6_rates(wb_out)
    update_operation_director(wb_out, wb_processed, perf_month_raw)
    
    update_date = datetime.date.today().strftime("%Y%m%d")
    output_file = get_output_filename(f"【{perf_month_cn}】管理者绩效", update_date)
    
    # 确保目录存在
    output_file.parent.mkdir(parents=True, exist_ok=True)
    wb_out.save(str(output_file))
    
    print("\n" + "=" * 70)
    print("[SUCCESS] 流程完成")
    print(f"阶段1 - 加工版文件: {processed_path}")
    print(f"阶段3 - 终版绩效文档: {output_file}")
    print("=" * 70)

if __name__ == "__main__":
    asyncio.run(main())
