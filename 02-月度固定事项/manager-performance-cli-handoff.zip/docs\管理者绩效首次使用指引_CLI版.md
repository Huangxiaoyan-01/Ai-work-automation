# 管理者绩效首次使用指引 - CLI版

这份指引给首次接手同事使用，目标是让他在自己的机器上尽快跑通管理者绩效流程。

## 一、能不能直接打包后改机器路径就跑

**可以，但不只是改一个路径就够了。**

当前这套脚本里，除了项目目录路径以外，还存在几类需要同步修改的固定配置：

1. `SmartBI CLI` 的本机路径
2. 项目目录的绝对路径
3. `.env` 里的 BI 登录信息
4. 终版模板、加工版、输出目录的固定路径

如果同事想最快跑通，建议：

- 把整个 `test_week` 文件夹放到他自己的机器上
- 保持项目目录结构不变
- 修改脚本里写死的绝对路径
- 准备好 `.env`

## 二、首次使用前要准备什么

### 1. 项目文件

至少要有这些内容：

- `管理者绩效完整流程_CLI版.py`
- `管理者绩效_BI批量导出合并_CLI版.py`
- `管理者绩效_明细加工_CLI版.py`
- `管理者绩效_最终输出.py`
- `管理者绩效操作指引_CLI版.md`
- `input/`
- `output/`
- `downloads/`
- `需求说明/`

### 2. Python 环境

需要能运行脚本依赖，至少要确保这些库可用：

- `openpyxl`
- `playwright`

如果同事机器上还没有这些库，需要先安装。

### 3. SmartBI CLI

脚本不是直接打开浏览器登录，而是调用本地的 SmartBI CLI。

所以要确认同事机器上也有对应的 `smartbi_cli.py`，并且脚本里配置的路径是正确的。

### 4. `.env`

项目根目录要有 `.env`，内容示例：

```env
SMARTBI_USERNAME=你的用户名
SMARTBI_PASSWORD=你的密码
SMARTBI_BASE_URL=https://bi.61info.cn/smartbi/vision/index.jsp
```

## 三、需要改哪些路径

下面这些地方最关键。

### 1. SmartBI CLI 路径

这两个脚本里都写死了 CLI 路径：

- [管理者绩效完整流程_CLI版.py](/C:/Users/huangxiaoyan/Documents/trae_projects/test_week/管理者绩效完整流程_CLI版.py)
- [管理者绩效_BI批量导出合并_CLI版.py](/C:/Users/huangxiaoyan/Documents/trae_projects/test_week/管理者绩效_BI批量导出合并_CLI版.py)

要把下面这段改成同事机器上的实际路径：

```text
C:\Users\huangxiaoyan\Documents\Codex\smartBICLI_code_only_20260603_104613\smartBICLI\active\python-cli\scripts\smartbi_cli.py
```

### 2. 项目目录绝对路径

这几个脚本里还存在写死的项目路径：

- [管理者绩效_BI批量导出合并_CLI版.py](/C:/Users/huangxiaoyan/Documents/trae_projects/test_week/管理者绩效_BI批量导出合并_CLI版.py)
- [管理者绩效_明细加工_CLI版.py](/C:/Users/huangxiaoyan/Documents/trae_projects/test_week/管理者绩效_明细加工_CLI版.py)
- [管理者绩效_最终输出.py](/C:/Users/huangxiaoyan/Documents/trae_projects/test_week/管理者绩效_最终输出.py)

这些地方通常要一起改成同事自己的 `test_week` 实际路径。

### 3. 输入输出目录

确保下面目录都存在：

- `input/`
- `output/`
- `downloads/`

如果没有，先建出来再跑。

## 四、首次使用步骤

### 步骤 1：确认目录

把项目放到同事机器上的某个固定目录，比如：

```text
C:\Users\xxx\Documents\trae_projects\test_week
```

然后确认里面有：

- `input`
- `output`
- `downloads`
- `需求说明`

### 步骤 2：修改脚本中的固定路径

重点修改：

- `SMARTBI_CLI_SCRIPT`
- `DOWNLOAD_DIR`
- `OUTPUT_DIR`
- `INPUT_FILE`
- `PROCESSED_FILE`

如果想省事，最稳的方式是保持目录结构和原来一致，只改用户名和上层路径。

### 步骤 3：配置 `.env`

在 `test_week` 根目录放好 `.env`，填入自己的 BI 账号密码。

### 步骤 4：准备终版模板

把终版绩效模板放到 `input/` 目录下。

文件名一般类似：

```text
【26年5月】管理者绩效 -20260518-终版.xlsx
```

### 步骤 5：先跑一键脚本

首次建议直接跑：

```bash
python 管理者绩效完整流程_CLI版.py
```

运行后会：

1. 询问绩效月份
2. 调用 SmartBI CLI 导出报表
3. 合并生成加工版
4. 更新终版绩效文档

## 五、如果一键脚本失败，怎么拆开跑

### 方案 A：先只跑阶段1

```bash
python 管理者绩效_BI批量导出合并_CLI版.py
```

适合先验证：

- BI 登录是否正常
- CLI 是否能导出
- 下载目录是否可写

### 方案 B：只做明细加工

```bash
python 管理者绩效_明细加工_CLI版.py
```

适合已经有导出结果，只想验证加工逻辑。

### 方案 C：只更新终版

```bash
python 管理者绩效_最终输出.py
```

适合已经有加工版文件，只想生成最终绩效文档。

## 六、常见问题

### 1. 找不到 SmartBI CLI

检查：

- `SMARTBI_CLI_SCRIPT` 是否改成了同事机器上的真实路径
- 文件是否真的存在

### 2. 提示没有 `.env`

检查：

- `.env` 是否放在 `test_week` 根目录
- 用户名、密码是否写对

### 3. 找不到输入文件

检查：

- `input/` 里是否放了终版模板
- 文件名是否符合脚本匹配规则

### 4. 输出没生成

检查：

- `output/` 是否存在
- 当前账号是否有目录写权限
- 导出报表是否全部成功

## 七、交接时最推荐的做法

如果是给同事正式接手，我建议这样交：

1. 把整个 `test_week` 文件夹打包给他
2. 给他这份 `[管理者绩效操作指引_CLI版.md](/C:/Users/huangxiaoyan/Documents/trae_projects/test_week/管理者绩效操作指引_CLI版.md)`
3. 再给他这份首次使用指引
4. 告诉他先改 `SmartBI CLI` 路径，再改项目路径，再放 `.env`
5. 第一次先跑一键脚本，不行再拆阶段排查

如果你愿意，我还可以继续帮你做一份“同事照着复制就能改的路径替换清单”，把每个脚本里该改哪一行列出来。
