管理者绩效 CLI 交接包

这是给同事接手用的完整交接包。拿到后按下面顺序处理即可：

1. 解压整个压缩包
2. 打开 docs\管理者绩效首次使用指引_CLI版.md
3. 按指引修改脚本里的固定路径
4. 配置根目录下的 .env
5. 确认 input\ 里有终版模板文件
6. 先运行 scripts\管理者绩效完整流程_CLI版.py

需要重点修改的内容：

- SmartBI CLI 路径
- 项目绝对路径
- INPUT_DIR / OUTPUT_DIR / DOWNLOAD_DIR
- .env 里的 SMARTBI_USERNAME / SMARTBI_PASSWORD / SMARTBI_BASE_URL

建议先看：

- docs\管理者绩效首次使用指引_CLI版.md
- docs\管理者绩效操作指引_CLI版.md

skill 目录的作用：

- 这是可选的 Codex 技能包
- 如果你要把它安装到 Codex 里，复制 skill\manager-performance-cli 到你的技能目录即可

目录说明：

- scripts\ 里放可运行脚本
- docs\ 里放交接文档
- skill\ 里放可复用技能

如果一键脚本失败，改用分阶段脚本排查：

- scripts\管理者绩效_BI批量导出合并_CLI版.py
- scripts\管理者绩效_明细加工_CLI版.py
- scripts\管理者绩效_最终输出.py

默认会使用 output\ 和 downloads\ 作为中间目录。

